/**
 * DexScreener API Client
 * 
 * Handles all interactions with DexScreener API
 * Implements rate limiting, caching, and error handling
 */

import axios, { AxiosInstance, AxiosError } from 'axios';
import { DexScreenerResponse, DexScreenerToken, TokenMetrics } from '../types';
import { getEnv, getStrategy } from '../config';
import { Logger } from '../utils/logger';
import { tokenCache } from '../utils/cache';
import { parseTokenAge, retry } from '../utils/helpers';

const logger = new Logger('DexScreenerAPI');

export class DexScreenerClient {
  private client: AxiosInstance;
  private lastRequestTime: number = 0;
  private requestQueue: Promise<any> = Promise.resolve();
  private errorCount: number = 0;
  private successCount: number = 0;

  constructor() {
    const env = getEnv();
    
    this.client = axios.create({
      baseURL: env.DEXSCREENER_API_URL,
      timeout: 10000,
      headers: {
        'Accept': 'application/json',
        'User-Agent': 'DexScreener-Intelligence-System/1.0',
      },
    });

    // Response interceptor for logging
    this.client.interceptors.response.use(
      (response) => {
        this.successCount++;
        this.errorCount = Math.max(0, this.errorCount - 1);
        return response;
      },
      (error: AxiosError) => {
        this.errorCount++;
        logger.error('API request failed:', error.message);
        throw error;
      }
    );
  }

  /**
   * Get error rate for self-defense monitoring
   */
  public getErrorRate(): number {
    const total = this.successCount + this.errorCount;
    return total > 0 ? this.errorCount / total : 0;
  }

  /**
   * Reset error counters
   */
  public resetErrorCounters(): void {
    this.errorCount = 0;
    this.successCount = 0;
  }

  /**
   * Rate-limited request wrapper
   */
  private async rateLimitedRequest<T>(requestFn: () => Promise<T>): Promise<T> {
    const env = getEnv();
    const minInterval = env.DEXSCREENER_RATE_LIMIT_MS;

    this.requestQueue = this.requestQueue.then(async () => {
      const now = Date.now();
      const timeSinceLastRequest = now - this.lastRequestTime;
      
      if (timeSinceLastRequest < minInterval) {
        await new Promise(resolve => 
          setTimeout(resolve, minInterval - timeSinceLastRequest)
        );
      }
      
      this.lastRequestTime = Date.now();
      return requestFn();
    });

    return this.requestQueue;
  }

  /**
   * Fetch token profiles by search query
   */
  public async searchTokens(query: string): Promise<DexScreenerToken[]> {
    const cacheKey = `search:${query}`;
    const cached = tokenCache.get(cacheKey);
    
    if (cached) {
      logger.debug(`Cache hit for search: ${query}`);
      return cached;
    }

    try {
      const response = await this.rateLimitedRequest(() =>
        retry(() => 
          this.client.get<DexScreenerResponse>('/search', {
            params: { q: query },
          })
        )
      );

      const tokens = response.data.pairs || [];
      tokenCache.set(cacheKey, tokens, 30000);
      
      logger.info(`Fetched ${tokens.length} tokens for query: ${query}`);
      return tokens;
    } catch (error) {
      logger.error(`Failed to search tokens: ${query}`, error);
      throw error;
    }
  }

  /**
   * Fetch token by address
   */
  public async getTokenByAddress(
    chainId: string, 
    tokenAddress: string
  ): Promise<DexScreenerToken | null> {
    const cacheKey = `token:${chainId}:${tokenAddress}`;
    const cached = tokenCache.get(cacheKey);
    
    if (cached) {
      logger.debug(`Cache hit for token: ${tokenAddress}`);
      return cached;
    }

    try {
      const response = await this.rateLimitedRequest(() =>
        retry(() =>
          this.client.get<DexScreenerResponse>(`/tokens/${tokenAddress}`)
        )
      );

      const tokens = response.data.pairs || [];
      const token = tokens.find(t => t.chainId === chainId) || tokens[0] || null;
      
      if (token) {
        tokenCache.set(cacheKey, token, 15000);
      }
      
      return token;
    } catch (error) {
      logger.error(`Failed to fetch token: ${tokenAddress}`, error);
      throw error;
    }
  }

  /**
   * Fetch newly created pairs
   */
  public async getNewPairs(): Promise<DexScreenerToken[]> {
    const cacheKey = 'new_pairs';
    const cached = tokenCache.get(cacheKey);
    
    if (cached) {
      logger.debug('Cache hit for new pairs');
      return cached;
    }

    try {
      // DexScreener doesn't have a direct "new pairs" endpoint
      // We'll use a combination of approaches
      const response = await this.rateLimitedRequest(() =>
        retry(() =>
          this.client.get<DexScreenerResponse>('/profiles/latest/1')
        )
      );

      const tokens = response.data.pairs || [];
      
      // Filter for recently created tokens
      const now = Date.now();
      const strategy = getStrategy();
      const maxAgeHours = strategy.filters.age.max_token_age_hours;
      const minAgeMinutes = strategy.filters.age.min_token_age_minutes;
      
      const newTokens = tokens.filter(token => {
        if (!token.pairCreatedAt) return false;
        const ageMs = now - token.pairCreatedAt;
        const ageHours = ageMs / 3600000;
        const ageMinutes = ageMs / 60000;
        
        return ageHours <= maxAgeHours && ageMinutes >= minAgeMinutes;
      });

      tokenCache.set(cacheKey, newTokens, 15000);
      
      logger.info(`Fetched ${newTokens.length} new pairs (from ${tokens.length} total)`);
      return newTokens;
    } catch (error) {
      logger.error('Failed to fetch new pairs', error);
      throw error;
    }
  }

  /**
   * Fetch trending tokens
   */
  public async getTrendingTokens(): Promise<DexScreenerToken[]> {
    const cacheKey = 'trending';
    const cached = tokenCache.get(cacheKey);
    
    if (cached) {
      logger.debug('Cache hit for trending tokens');
      return cached;
    }

    try {
      const response = await this.rateLimitedRequest(() =>
        retry(() =>
          this.client.get<DexScreenerResponse>('/profiles/trending/1')
        )
      );

      const tokens = response.data.pairs || [];
      tokenCache.set(cacheKey, tokens, 30000);
      
      logger.info(`Fetched ${tokens.length} trending tokens`);
      return tokens;
    } catch (error) {
      logger.error('Failed to fetch trending tokens', error);
      throw error;
    }
  }

  /**
   * Convert DexScreener token to internal TokenMetrics
   */
  public static toTokenMetrics(token: DexScreenerToken): TokenMetrics {
    const age = parseTokenAge(token.pairCreatedAt);
    
    return {
      address: token.baseToken.address,
      symbol: token.baseToken.symbol,
      name: token.baseToken.name,
      chainId: token.chainId,
      
      priceUsd: parseFloat(token.priceUsd) || 0,
      priceChange5m: token.priceChange?.m5 || 0,
      priceChange1h: token.priceChange?.h1 || 0,
      priceChange24h: token.priceChange?.h24 || 0,
      
      volume5m: token.volume?.m5 || 0,
      volume1h: token.volume?.h1 || 0,
      volume24h: token.volume?.h24 || 0,
      
      liquidityUsd: token.liquidityUsd || 0,
      marketCap: token.marketCap || 0,
      fdv: token.fdv || 0,
      
      buys5m: token.txns?.m5?.buys || 0,
      sells5m: token.txns?.m5?.sells || 0,
      buys1h: token.txns?.h1?.buys || 0,
      sells1h: token.txns?.h1?.sells || 0,
      buys24h: token.txns?.h24?.buys || 0,
      sells24h: token.txns?.h24?.sells || 0,
      
      pairCreatedAt: token.pairCreatedAt,
      ageMinutes: age.minutes,
      ageHours: age.hours,
    };
  }

  /**
   * Apply filtering strategy to tokens
   */
  public filterTokens(tokens: DexScreenerToken[]): DexScreenerToken[] {
    const strategy = getStrategy();
    const filters = strategy.filters;
    
    return tokens.filter(token => {
      const metrics = DexScreenerClient.toTokenMetrics(token);
      
      // Liquidity filter
      if (metrics.liquidityUsd < filters.liquidity.min_usd || 
          metrics.liquidityUsd > filters.liquidity.max_usd) {
        return false;
      }
      
      // Market cap filter
      if (metrics.marketCap < filters.market_cap.min_usd || 
          metrics.marketCap > filters.market_cap.max_usd) {
        return false;
      }
      
      // Volume filter
      if (metrics.volume24h < filters.volume.min_24h_usd || 
          metrics.volume1h < filters.volume.min_1h_usd) {
        return false;
      }
      
      // Age filter
      if (metrics.ageHours > filters.age.max_token_age_hours || 
          metrics.ageMinutes < filters.age.min_token_age_minutes) {
        return false;
      }
      
      // Price change filter
      if (metrics.priceChange5m < filters.price_change.min_positive_change_5m ||
          metrics.priceChange1h < filters.price_change.max_negative_change_1h) {
        return false;
      }
      
      return true;
    });
  }

  /**
   * Get API health status
   */
  public async healthCheck(): Promise<{ 
    healthy: boolean; 
    latency: number; 
    error?: string 
  }> {
    const start = Date.now();
    
    try {
      await this.rateLimitedRequest(() =>
        this.client.get('/search', { params: { q: 'SOL' }, timeout: 5000 })
      );
      
      return {
        healthy: true,
        latency: Date.now() - start,
      };
    } catch (error) {
      return {
        healthy: false,
        latency: Date.now() - start,
        error: (error as Error).message,
      };
    }
  }
}

// Export singleton instance
export const dexScreenerClient = new DexScreenerClient();
