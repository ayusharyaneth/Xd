/**
 * Configuration Module
 * 
 * Implements hybrid configuration model:
 * - strategy.yaml → All thresholds + weights
 * - .env → Secrets + runtime overrides
 * 
 * Environment variables override YAML if both defined.
 */

import * as fs from 'fs';
import * as path from 'path';
import * as yaml from 'js-yaml';
import * as dotenv from 'dotenv';
import { Logger } from '../utils/logger';

const logger = new Logger('Config');

// ========================================================
// TYPE DEFINITIONS
// ========================================================

export interface SystemConfig {
  polling: {
    interval_ms: number;
    watch_mode_interval_ms: number;
    max_concurrent_requests: number;
  };
  buffering: {
    rolling_window_seconds: number;
    max_alerts_per_window: number;
    min_alert_interval_ms: number;
  };
  cooldowns: {
    exit_signal_seconds: number;
    whale_alert_seconds: number;
    token_alert_seconds: number;
  };
}

export interface FilterConfig {
  liquidity: {
    min_usd: number;
    max_usd: number;
  };
  market_cap: {
    min_usd: number;
    max_usd: number;
  };
  volume: {
    min_24h_usd: number;
    min_1h_usd: number;
  };
  age: {
    max_token_age_hours: number;
    min_token_age_minutes: number;
  };
  holders: {
    min_count: number;
    min_growth_rate_1h: number;
  };
  price_change: {
    min_positive_change_5m: number;
    max_negative_change_1h: number;
  };
}

export interface RiskEngineConfig {
  weights: {
    liquidity_concentration: number;
    holder_distribution: number;
    price_volatility: number;
    contract_risk: number;
    developer_risk: number;
  };
  thresholds: {
    high_risk_score: number;
    medium_risk_score: number;
    low_risk_score: number;
  };
  indicators: {
    max_liquidity_owner_percentage: number;
    max_top_10_holder_percentage: number;
    max_price_dump_5m: number;
    max_volatility_index: number;
  };
}

export interface AuthenticityEngineConfig {
  weights: {
    liquidity_locked: number;
    contract_verified: number;
    social_presence: number;
    website_quality: number;
    team_doxxed: number;
  };
  thresholds: {
    high_authenticity: number;
    medium_authenticity: number;
    low_authenticity: number;
  };
  requirements: {
    min_social_followers: number;
    min_website_sections: number;
    liquidity_lock_min_days: number;
  };
}

export interface DeveloperEngineConfig {
  weights: {
    previous_success_rate: number;
    rug_history: number;
    project_longevity: number;
    community_engagement: number;
  };
  thresholds: {
    excellent_reputation: number;
    good_reputation: number;
    suspicious_reputation: number;
    blacklist_reputation: number;
  };
  historical_analysis: {
    min_projects_to_analyze: number;
    lookback_days: number;
  };
}

export interface BuyQualityEngineConfig {
  weights: {
    trade_size_distribution: number;
    buy_sell_ratio: number;
    unique_buyers_growth: number;
    transaction_consistency: number;
  };
  thresholds: {
    excellent_quality: number;
    good_quality: number;
    poor_quality: number;
  };
  indicators: {
    min_buy_sell_ratio: number;
    min_unique_buyers_1h: number;
    max_whale_concentration: number;
  };
}

export interface WhaleDetectionConfig {
  thresholds: {
    trade_size_usd: number;
    wallet_portfolio_usd: number;
    wallet_historical_volume_usd: number;
  };
  badges: {
    mega_whale_usd: number;
    large_whale_usd: number;
    medium_whale_usd: number;
  };
  behavior: {
    exit_detection_threshold: number;
    accumulation_detection_threshold: number;
    min_trades_for_pattern: number;
  };
}

export interface ProbabilityEngineConfig {
  weights: {
    risk_score: number;
    authenticity_score: number;
    developer_score: number;
    buy_quality_score: number;
    whale_confidence: number;
    market_timing: number;
  };
  output: {
    high_probability_threshold: number;
    medium_probability_threshold: number;
    low_probability_threshold: number;
  };
  confidence: {
    min_data_points: number;
    confidence_decay_hours: number;
  };
}

export interface ExitAssistantConfig {
  triggers: {
    liquidity_drop_percentage: number;
    whale_exit_detected: boolean;
    creator_selling_detected: boolean;
    volume_decay_percentage: number;
    rug_probability_threshold: number;
  };
  thresholds: {
    min_profit_to_consider_exit: number;
    max_loss_before_force_exit: number;
    trailing_stop_percentage: number;
  };
  cooldown_seconds: number;
}

export interface RankingEngineConfig {
  composite_score_weights: {
    probability_score: number;
    risk_adjusted_return: number;
    momentum_score: number;
    whale_confidence: number;
    time_sensitivity: number;
  };
  output: {
    top_n_alerts: number;
    min_score_to_alert: number;
    suppression_threshold: number;
  };
  time_decay: {
    half_life_minutes: number;
    urgency_boost_factor: number;
  };
}

export interface MarketRegimeConfig {
  indicators: {
    rug_rate_24h_threshold_high: number;
    rug_rate_24h_threshold_low: number;
    avg_survival_time_hours: number;
    launch_frequency_threshold_high: number;
    launch_frequency_threshold_low: number;
  };
  regimes: {
    BULL_LAUNCH_SEASON: {
      rug_rate_max: number;
      survival_time_min_hours: number;
      whale_participation_min: number;
    };
    NORMAL: {
      rug_rate_max: number;
      survival_time_min_hours: number;
      whale_participation_min: number;
    };
    HIGH_RUG_ACTIVITY: {
      rug_rate_min: number;
      survival_time_max_hours: number;
      whale_participation_max: number;
    };
    LOW_ACTIVITY: {
      launch_frequency_max: number;
      volume_threshold_usd: number;
    };
  };
  adaptations: {
    BULL_LAUNCH_SEASON: {
      filter_multiplier: number;
      risk_tolerance_boost: number;
      ranking_aggressiveness: number;
    };
    HIGH_RUG_ACTIVITY: {
      filter_multiplier: number;
      risk_tolerance_reduction: number;
      ranking_conservatism: number;
    };
  };
}

export interface WatchModeConfig {
  default_duration_minutes: number;
  max_duration_minutes: number;
  update_interval_seconds: number;
  significant_change_thresholds: {
    price_change_percent: number;
    volume_change_percent: number;
    liquidity_change_percent: number;
    holder_change_percent: number;
  };
  escalation: {
    profit_target_percent: number;
    stop_loss_percent: number;
    auto_exit_enabled: boolean;
  };
}

export interface SelfDefenseConfig {
  monitoring: {
    check_interval_seconds: number;
  };
  thresholds: {
    api_error_rate_max: number;
    rpc_error_rate_max: number;
    latency_ms_max: number;
    memory_usage_percent_max: number;
    cpu_usage_percent_max: number;
  };
  safe_mode: {
    polling_interval_multiplier: number;
    suppress_non_critical_alerts: boolean;
    reduce_concurrent_requests: boolean;
    alert_cooldown_seconds: number;
  };
  recovery: {
    auto_recovery_enabled: boolean;
    recovery_check_interval_seconds: number;
    consecutive_success_threshold: number;
  };
}

export interface HealthMonitorConfig {
  ping: {
    response_timeout_ms: number;
    check_interval_seconds: number;
  };
  metrics: {
    retention_hours: number;
    alert_on_anomaly: boolean;
  };
  status: {
    healthy_latency_ms: number;
    degraded_latency_ms: number;
  };
}

export interface StrategyConfig {
  system: SystemConfig;
  filters: FilterConfig;
  risk_engine: RiskEngineConfig;
  authenticity_engine: AuthenticityEngineConfig;
  developer_engine: DeveloperEngineConfig;
  buy_quality_engine: BuyQualityEngineConfig;
  whale_detection: WhaleDetectionConfig;
  probability_engine: ProbabilityEngineConfig;
  exit_assistant: ExitAssistantConfig;
  ranking_engine: RankingEngineConfig;
  market_regime: MarketRegimeConfig;
  watch_mode: WatchModeConfig;
  self_defense: SelfDefenseConfig;
  health_monitor: HealthMonitorConfig;
}

export interface EnvConfig {
  // Telegram
  SIGNAL_BOT_TOKEN: string;
  ALERT_BOT_TOKEN: string;
  SIGNAL_CHAT_ID: string;
  ALERT_CHAT_ID: string;
  
  // API
  DEXSCREENER_API_URL: string;
  DEXSCREENER_RATE_LIMIT_MS: number;
  RPC_ENDPOINT?: string;
  RPC_BACKUP_ENDPOINT?: string;
  
  // System
  NODE_ENV: string;
  LOG_LEVEL: string;
  STRATEGY_CONFIG_PATH: string;
  
  // Polling overrides
  POLLING_INTERVAL_MS?: number;
  WATCH_MODE_INTERVAL_MS?: number;
  
  // Metrics
  METRICS_ENABLED: boolean;
  METRICS_PORT: number;
  
  // Security
  ADMIN_USER_IDS: string[];
  
  // Feature flags
  WHALE_DETECTION_ENABLED: boolean;
  EXIT_ASSISTANT_ENABLED: boolean;
  SELF_DEFENSE_ENABLED: boolean;
  MARKET_REGIME_ANALYSIS_ENABLED: boolean;
}

// ========================================================
// CONFIGURATION LOADER
// ========================================================

class ConfigurationManager {
  private strategyConfig: StrategyConfig | null = null;
  private envConfig: EnvConfig | null = null;

  constructor() {
    this.loadEnv();
    this.loadStrategy();
  }

  private loadEnv(): void {
    dotenv.config();

    this.envConfig = {
      SIGNAL_BOT_TOKEN: process.env.SIGNAL_BOT_TOKEN || '',
      ALERT_BOT_TOKEN: process.env.ALERT_BOT_TOKEN || '',
      SIGNAL_CHAT_ID: process.env.SIGNAL_CHAT_ID || '',
      ALERT_CHAT_ID: process.env.ALERT_CHAT_ID || '',
      
      DEXSCREENER_API_URL: process.env.DEXSCREENER_API_URL || 'https://api.dexscreener.com/latest/dex/tokens',
      DEXSCREENER_RATE_LIMIT_MS: parseInt(process.env.DEXSCREENER_RATE_LIMIT_MS || '1000'),
      RPC_ENDPOINT: process.env.RPC_ENDPOINT,
      RPC_BACKUP_ENDPOINT: process.env.RPC_BACKUP_ENDPOINT,
      
      NODE_ENV: process.env.NODE_ENV || 'development',
      LOG_LEVEL: process.env.LOG_LEVEL || 'info',
      STRATEGY_CONFIG_PATH: process.env.STRATEGY_CONFIG_PATH || './strategy.yaml',
      
      POLLING_INTERVAL_MS: process.env.POLLING_INTERVAL_MS ? parseInt(process.env.POLLING_INTERVAL_MS) : undefined,
      WATCH_MODE_INTERVAL_MS: process.env.WATCH_MODE_INTERVAL_MS ? parseInt(process.env.WATCH_MODE_INTERVAL_MS) : undefined,
      
      METRICS_ENABLED: process.env.METRICS_ENABLED === 'true',
      METRICS_PORT: parseInt(process.env.METRICS_PORT || '9090'),
      
      ADMIN_USER_IDS: process.env.ADMIN_USER_IDS ? process.env.ADMIN_USER_IDS.split(',') : [],
      
      WHALE_DETECTION_ENABLED: process.env.WHALE_DETECTION_ENABLED !== 'false',
      EXIT_ASSISTANT_ENABLED: process.env.EXIT_ASSISTANT_ENABLED !== 'false',
      SELF_DEFENSE_ENABLED: process.env.SELF_DEFENSE_ENABLED !== 'false',
      MARKET_REGIME_ANALYSIS_ENABLED: process.env.MARKET_REGIME_ANALYSIS_ENABLED !== 'false',
    };

    logger.info('Environment configuration loaded');
  }

  private loadStrategy(): void {
    try {
      const configPath = path.resolve(this.envConfig?.STRATEGY_CONFIG_PATH || './strategy.yaml');
      
      if (!fs.existsSync(configPath)) {
        logger.error(`Strategy configuration file not found: ${configPath}`);
        throw new Error(`Strategy configuration file not found: ${configPath}`);
      }

      const fileContents = fs.readFileSync(configPath, 'utf8');
      this.strategyConfig = yaml.load(fileContents) as StrategyConfig;

      // Apply environment overrides
      this.applyEnvironmentOverrides();

      logger.info('Strategy configuration loaded and parsed');
    } catch (error) {
      logger.error('Failed to load strategy configuration:', error);
      throw error;
    }
  }

  private applyEnvironmentOverrides(): void {
    if (!this.strategyConfig || !this.envConfig) return;

    // Override polling intervals if specified in env
    if (this.envConfig.POLLING_INTERVAL_MS) {
      this.strategyConfig.system.polling.interval_ms = this.envConfig.POLLING_INTERVAL_MS;
      logger.info(`Overriding polling interval from env: ${this.envConfig.POLLING_INTERVAL_MS}ms`);
    }

    if (this.envConfig.WATCH_MODE_INTERVAL_MS) {
      this.strategyConfig.system.polling.watch_mode_interval_ms = this.envConfig.WATCH_MODE_INTERVAL_MS;
      logger.info(`Overriding watch mode interval from env: ${this.envConfig.WATCH_MODE_INTERVAL_MS}ms`);
    }
  }

  public getStrategy(): StrategyConfig {
    if (!this.strategyConfig) {
      throw new Error('Strategy configuration not loaded');
    }
    return this.strategyConfig;
  }

  public getEnv(): EnvConfig {
    if (!this.envConfig) {
      throw new Error('Environment configuration not loaded');
    }
    return this.envConfig;
  }

  public reload(): void {
    logger.info('Reloading configuration...');
    this.loadEnv();
    this.loadStrategy();
  }

  public validate(): boolean {
    const env = this.getEnv();
    const strategy = this.getStrategy();

    // Validate required env variables
    const requiredEnvVars = ['SIGNAL_BOT_TOKEN', 'ALERT_BOT_TOKEN'];
    for (const varName of requiredEnvVars) {
      if (!env[varName as keyof EnvConfig]) {
        logger.error(`Required environment variable missing: ${varName}`);
        return false;
      }
    }

    // Validate strategy weights sum to approximately 1.0
    const validateWeights = (weights: Record<string, number>, name: string): boolean => {
      const sum = Object.values(weights).reduce((a, b) => a + b, 0);
      if (Math.abs(sum - 1.0) > 0.01) {
        logger.warn(`${name} weights sum to ${sum}, expected ~1.0`);
        return false;
      }
      return true;
    };

    validateWeights(strategy.risk_engine.weights, 'Risk Engine');
    validateWeights(strategy.authenticity_engine.weights, 'Authenticity Engine');
    validateWeights(strategy.developer_engine.weights, 'Developer Engine');
    validateWeights(strategy.buy_quality_engine.weights, 'Buy Quality Engine');
    validateWeights(strategy.probability_engine.weights, 'Probability Engine');
    validateWeights(strategy.ranking_engine.composite_score_weights, 'Ranking Engine');

    logger.info('Configuration validation passed');
    return true;
  }
}

// ========================================================
// EXPORT SINGLETON INSTANCE
// ========================================================

export const config = new ConfigurationManager();

// Convenience exports
export const getStrategy = (): StrategyConfig => config.getStrategy();
export const getEnv = (): EnvConfig => config.getEnv();
export const reloadConfig = (): void => config.reload();
export const validateConfig = (): boolean => config.validate();
