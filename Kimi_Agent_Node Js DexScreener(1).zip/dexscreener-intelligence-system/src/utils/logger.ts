/**
 * Logging Utility
 * 
 * Production-grade logging using Pino with structured output
 */

import pino from 'pino';
import { getEnv } from '../config';

export class Logger {
  private logger: pino.Logger;
  private context: string;

  constructor(context: string) {
    this.context = context;
    const env = getEnv();
    
    this.logger = pino({
      level: env.LOG_LEVEL || 'info',
      transport: env.NODE_ENV === 'development' 
        ? { target: 'pino-pretty', options: { colorize: true } }
        : undefined,
      base: {
        pid: process.pid,
        context: this.context,
      },
      timestamp: pino.stdTimeFunctions.isoTime,
    });
  }

  public debug(message: string, ...args: any[]): void {
    this.logger.debug({ args }, message);
  }

  public info(message: string, ...args: any[]): void {
    this.logger.info({ args }, message);
  }

  public warn(message: string, ...args: any[]): void {
    this.logger.warn({ args }, message);
  }

  public error(message: string, ...args: any[]): void {
    this.logger.error({ args }, message);
  }

  public fatal(message: string, ...args: any[]): void {
    this.logger.fatal({ args }, message);
  }

  public child(bindings: Record<string, any>): Logger {
    const childLogger = new Logger(`${this.context}:${bindings.subContext || 'child'}`);
    return childLogger;
  }
}

// Global logger instance
export const globalLogger = new Logger('Global');
