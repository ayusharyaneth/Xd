/**
 * Cache Utility
 * 
 * Simple in-memory cache with TTL support
 */

import { CachedData } from '../types';

export class Cache<T> {
  private cache: Map<string, CachedData<T>> = new Map();
  private defaultTtl: number;

  constructor(defaultTtlMs: number = 60000) {
    this.defaultTtl = defaultTtlMs;
  }

  public set(key: string, data: T, ttlMs?: number): void {
    const now = Date.now();
    const ttl = ttlMs || this.defaultTtl;
    
    this.cache.set(key, {
      data,
      cachedAt: now,
      expiresAt: now + ttl,
      ttl,
    });
  }

  public get(key: string): T | undefined {
    const cached = this.cache.get(key);
    
    if (!cached) {
      return undefined;
    }

    if (Date.now() > cached.expiresAt) {
      this.cache.delete(key);
      return undefined;
    }

    return cached.data;
  }

  public has(key: string): boolean {
    return this.get(key) !== undefined;
  }

  public delete(key: string): boolean {
    return this.cache.delete(key);
  }

  public clear(): void {
    this.cache.clear();
  }

  public getSize(): number {
    return this.cache.size;
  }

  public cleanup(): number {
    const now = Date.now();
    let cleaned = 0;
    
    for (const [key, cached] of this.cache.entries()) {
      if (now > cached.expiresAt) {
        this.cache.delete(key);
        cleaned++;
      }
    }
    
    return cleaned;
  }

  public keys(): string[] {
    return Array.from(this.cache.keys());
  }

  public values(): T[] {
    const values: T[] = [];
    for (const key of this.cache.keys()) {
      const value = this.get(key);
      if (value !== undefined) {
        values.push(value);
      }
    }
    return values;
  }
}

// Global cache instances
export const tokenCache = new Cache<any>(30000);
export const analysisCache = new Cache<any>(60000);
export const whaleCache = new Cache<any>(120000);
