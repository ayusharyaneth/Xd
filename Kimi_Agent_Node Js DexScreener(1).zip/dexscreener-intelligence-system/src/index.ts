/**
 * DexScreener Intelligence System
 * 
 * Main entry point for the production-grade token monitoring system.
 * 
 * Features:
 * - Multi-engine token analysis (Risk, Authenticity, Developer, Buy Quality, Whale, Probability)
 * - Smart Exit Assistant
 * - Alert Ranking Engine
 * - Market Regime Analyzer
 * - Watch Mode with interactive Telegram features
 * - Self-Defense protection mode
 * - Health monitoring with /ping command
 * - Dual Telegram bots (Signal + Alert)
 */

import { config, validateConfig } from './config';
import { Logger } from './utils/logger';
import { dexScreenerClient } from './api/dexscreener';
import { riskEngine } from './engines/risk';
import { authenticityEngine } from './engines/authenticity';
import { developerEngine } from './engines/developer';
import { buyQualityEngine } from './engines/buyQuality';
import { whaleEngine } from './engines/whale';
import { probabilityEngine } from './engines/probability';
import { exitEngine } from './engines/exit';
import { rankingEngine } from './engines/ranking';
import { regimeAnalyzer } from './engines/regime';
import { selfDefenseManager } from './system/selfDefense';
import { healthMonitor } from './system/health';
import { watchManager } from './watch/manager';
import { metricsCollector } from './system/metrics';
import { initializeSignalBot, signalBot } from './bots/signalBot';
import { initializeAlertBot, alertBot } from './bots/alertBot';
import { 
  DexScreenerToken, 
  TokenAlert, 
  TokenMetrics, 
  WatchUpdate,
  MarketRegime 
} from './types';
import { DexScreenerClient } from './api/dexscreener';
import { generateId, sleep } from './utils/helpers';

const logger = new Logger('Main');

class DexScreenerIntelligenceSystem {
  private running: boolean = false;
  private pollingInterval?: NodeJS.Timeout;
  private cleanupInterval?: NodeJS.Timeout;
  private lastPollTime: number = 0;

  constructor() {
    // Validate configuration on startup
    if (!validateConfig()) {
      logger.error('Configuration validation failed');
      process.exit(1);
    }
  }

  /**
   * Start the system
   */
  public async start(): Promise<void> {
    if (this.running) {
      logger.warn('System is already running');
      return;
    }

    logger.info('============================================');
    logger.info('DexScreener Intelligence System Starting...');
    logger.info('============================================');

    try {
      // Initialize Telegram bots
      await this.initializeBots();

      // Initialize system components
      this.initializeComponents();

      // Send startup notification
      await alertBot.sendStartup();

      // Start main processing loop
      this.startPolling();

      // Start cleanup tasks
      this.startCleanupTasks();

      this.running = true;
      logger.info('============================================');
      logger.info('System started successfully');
      logger.info('============================================');
    } catch (error) {
      logger.error('Failed to start system:', error);
      await alertBot.sendError(error as Error, 'System startup');
      process.exit(1);
    }
  }

  /**
   * Initialize Telegram bots
   */
  private async initializeBots(): Promise<void> {
    logger.info('Initializing Telegram bots...');

    // Initialize alert bot first (simpler)
    initializeAlertBot();

    // Initialize signal bot with interactive features
    initializeSignalBot();

    logger.info('Telegram bots initialized');
  }

  /**
   * Initialize system components
   */
  private initializeComponents(): void {
    logger.info('Initializing system components...');

    // Start health monitoring
    healthMonitor.start();

    // Start self-defense monitoring
    selfDefenseManager.start();

    // Start watch manager
    watchManager.start();
    watchManager.setCallbacks({
      onSignificantChange: this.handleWatchSignificantChange.bind(this),
      onEscalation: this.handleWatchEscalation.bind(this),
      onExitSignal: this.handleWatchExitSignal.bind(this),
      onExpired: this.handleWatchExpired.bind(this),
    });

    logger.info('System components initialized');
  }

  /**
   * Start main polling loop
   */
  private startPolling(): void {
    const strategy = config.getStrategy();
    const intervalMs = strategy.system.polling.interval_ms;

    logger.info(`Starting polling loop (${intervalMs}ms interval)`);

    // Immediate first poll
    this.poll();

    // Schedule recurring polls
    this.pollingInterval = setInterval(() => {
      this.poll();
    }, intervalMs);
  }

  /**
   * Main polling function
   */
  private async poll(): Promise<void> {
    const startTime = Date.now();
    this.lastPollTime = startTime;

    try {
      // Check if we should skip this poll (safe mode)
      if (selfDefenseManager.shouldSuppressAlerts()) {
        logger.debug('Skipping poll - safe mode active');
        return;
      }

      // Get adjusted polling interval
      const baseInterval = config.getStrategy().system.polling.interval_ms;
      const adjustedInterval = selfDefenseManager.getAdjustedPollingInterval(baseInterval);

      if (Date.now() - startTime < adjustedInterval - baseInterval) {
        logger.debug('Adjusted polling interval - waiting...');
        return;
      }

      logger.debug('Polling for new tokens...');

      // Fetch new pairs from DexScreener
      const tokens = await dexScreenerClient.getNewPairs();

      // Filter tokens
      const filteredTokens = dexScreenerClient.filterTokens(tokens);

      logger.info(`Fetched ${tokens.length} tokens, ${filteredTokens.length} passed filters`);

      // Process tokens through engines
      await this.processTokens(filteredTokens);

      // Record metrics
      metricsCollector.record({
        tokensProcessed: tokens.length,
        tokensFiltered: filteredTokens.length,
      });

      // Update market regime
      const alerts = rankingEngine.processBuffer();
      if (alerts.length > 0) {
        regimeAnalyzer.analyze(alerts);
      }

      // Flush metrics
      metricsCollector.flush();

    } catch (error) {
      logger.error('Error in poll cycle:', error);
      await alertBot.sendError(error as Error, 'Polling cycle');
    }
  }

  /**
   * Process tokens through all engines
   */
  private async processTokens(tokens: DexScreenerToken[]): Promise<void> {
    for (const token of tokens) {
      try {
        await this.processToken(token);
      } catch (error) {
        logger.error(`Error processing token ${token.baseToken.symbol}:`, error);
      }
    }
  }

  /**
   * Process single token through all engines
   */
  private async processToken(dexToken: DexScreenerToken): Promise<void> {
    const metrics = DexScreenerClient.toTokenMetrics(dexToken);

    // Run all engines
    const risk = riskEngine.assess(metrics);
    
    // Skip high-risk tokens early
    if (risk.level === 'CRITICAL') {
      logger.debug(`Skipping ${metrics.symbol} - critical risk`);
      return;
    }

    const authenticity = authenticityEngine.assess(metrics, dexToken.info);
    const developer = developerEngine.assess(metrics);
    const buyQuality = buyQualityEngine.assess(metrics);
    
    // Whale detection (if enabled)
    let whale = whaleEngine.createEmptyActivity ? { detected: false, badge: 'NONE', activities: [], confidence: 0, summary: { totalWhaleBuys: 0, totalWhaleSells: 0, netWhaleFlow: 0, uniqueWhales: 0 } } : { detected: false, badge: 'NONE', activities: [], confidence: 0, summary: { totalWhaleBuys: 0, totalWhaleSells: 0, netWhaleFlow: 0, uniqueWhales: 0 } };
    if (config.getEnv().WHALE_DETECTION_ENABLED) {
      whale = whaleEngine.detect(metrics);
    }

    // Get current regime
    const regime = regimeAnalyzer.getCurrentRegime();

    // Calculate probability
    const probability = probabilityEngine.calculate(metrics, {
      risk,
      authenticity,
      developer,
      buyQuality,
      whale,
      regime,
    });

    // Check exit conditions (if we have a watch session)
    const watchSession = watchManager.getSessionByToken(metrics.address);
    if (watchSession && config.getEnv().EXIT_ASSISTANT_ENABLED) {
      const exitSignal = exitEngine.analyze(metrics, risk, whale);
      if (exitSignal.shouldExit) {
        await signalBot.sendExitAlert({
          id: generateId(),
          timestamp: Date.now(),
          originalAlertId: '',
          token: metrics,
          exitSignal,
          currentPrice: metrics.priceUsd,
          priceChangeSinceAlert: (metrics.priceUsd - watchSession.baselinePrice) / watchSession.baselinePrice,
          sent: false,
        });
      }
    }

    // Create rankable token for ranking engine
    const rankableToken = {
      address: metrics.address,
      symbol: metrics.symbol,
      metrics,
      probability,
      risk,
      whale,
      timestamp: Date.now(),
    };

    // Add to ranking buffer
    rankingEngine.bufferToken(rankableToken);

    // Record engine latencies
    metricsCollector.record({
      engineLatencies: {
        risk: 0, // Would measure actual latency
        authenticity: 0,
        developer: 0,
        buyQuality: 0,
        whale: 0,
        probability: 0,
        ranking: 0,
      },
    });
  }

  /**
   * Send ranked alerts
   */
  private async sendAlerts(alerts: TokenAlert[]): Promise<void> {
    for (const alert of alerts) {
      if (alert.suppressed) {
        logger.debug(`Alert for ${alert.token.symbol} suppressed: ${alert.suppressionReason}`);
        continue;
      }

      await signalBot.sendTokenAlert(alert);
      alert.sent = true;

      // Record in metrics
      metricsCollector.record({
        alertsSent: (metricsCollector.getLatest()?.alertsSent || 0) + 1,
      });
    }
  }

  /**
   * Start cleanup tasks
   */
  private startCleanupTasks(): void {
    // Run cleanup every 5 minutes
    this.cleanupInterval = setInterval(() => {
      this.cleanup();
    }, 5 * 60 * 1000);
  }

  /**
   * Cleanup old data
   */
  private cleanup(): void {
    logger.debug('Running cleanup tasks...');

    // Cleanup engines
    whaleEngine.cleanupOldAlerts?.();
    exitEngine.cleanup?.();
    rankingEngine.cleanup?.();

    // Cleanup caches
    // tokenCache.cleanup();
    // analysisCache.cleanup();

    // Cleanup watch manager
    watchManager.cleanup();

    // Reset API error counters periodically
    dexScreenerClient.resetErrorCounters();

    logger.debug('Cleanup completed');
  }

  /**
   * Handle significant change in watch mode
   */
  private async handleWatchSignificantChange(update: WatchUpdate): Promise<void> {
    logger.info(`Significant change detected for ${update.session.tokenSymbol}`);
    
    await signalBot.sendWatchUpdate(
      update.session,
      update.changes,
      true
    );

    metricsCollector.record({
      watchUpdatesSent: (metricsCollector.getLatest()?.watchUpdatesSent || 0) + 1,
    });
  }

  /**
   * Handle escalation in watch mode
   */
  private async handleWatchEscalation(update: WatchUpdate): Promise<void> {
    logger.info(`Escalation detected for ${update.session.tokenSymbol}`);
    
    const changeEmoji = update.changes.priceChangePercent >= 0 ? '🟢' : '🔴';
    const message = `
🚨 *ESCALATION ALERT: ${update.session.tokenSymbol}*

*Price Change:* ${changeEmoji} ${(update.changes.priceChangePercent * 100).toFixed(2)}%
*Current Price:* $${update.session.lastPrice.toFixed(6)}

This token requires immediate attention!
    `.trim();

    await signalBot.sendMessage(message);
  }

  /**
   * Handle exit signal in watch mode
   */
  private async handleWatchExitSignal(update: WatchUpdate): Promise<void> {
    logger.info(`Exit signal for ${update.session.tokenSymbol}`);
    
    if (update.exitSignal) {
      await signalBot.sendExitAlert({
        id: generateId(),
        timestamp: Date.now(),
        originalAlertId: '',
        token: update.currentMetrics,
        exitSignal: update.exitSignal,
        currentPrice: update.currentMetrics.priceUsd,
        priceChangeSinceAlert: (update.currentMetrics.priceUsd - update.session.baselinePrice) / update.session.baselinePrice,
        sent: false,
      });
    }
  }

  /**
   * Handle watch session expiration
   */
  private async handleWatchExpired(session: WatchSession): Promise<void> {
    logger.info(`Watch session expired for ${session.tokenSymbol}`);
    
    const finalChange = (session.lastPrice - session.baselinePrice) / session.baselinePrice;
    const changeEmoji = finalChange >= 0 ? '🟢' : '🔴';

    const message = `
⏰ *WATCH SESSION EXPIRED: ${session.tokenSymbol}*

*Final Price:* $${session.lastPrice.toFixed(6)}
*Total Change:* ${changeEmoji} ${(finalChange * 100).toFixed(2)}%
*Peak Price:* $${session.highestPrice.toFixed(6)}
*Lowest Price:* $${session.lowestPrice.toFixed(6)}
*Alerts Sent:* ${session.alertCount}

Session has expired and is no longer being monitored.
    `.trim();

    await signalBot.sendMessage(message);
  }

  /**
   * Stop the system
   */
  public async stop(reason?: string): Promise<void> {
    if (!this.running) return;

    logger.info('============================================');
    logger.info('Stopping DexScreener Intelligence System...');
    logger.info('============================================');

    this.running = false;

    // Stop intervals
    if (this.pollingInterval) {
      clearInterval(this.pollingInterval);
    }
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
    }

    // Stop components
    healthMonitor.stop();
    selfDefenseManager.stop();
    watchManager.stop();
    signalBot.stop();

    // Send shutdown notification
    await alertBot.sendShutdown(reason);

    logger.info('============================================');
    logger.info('System stopped');
    logger.info('============================================');
  }

  /**
   * Get system status
   */
  public getStatus(): {
    running: boolean;
    lastPollTime: number;
    health: ReturnType<typeof healthMonitor.getHealth>;
    regime: MarketRegime;
    watches: ReturnType<typeof watchManager.getStatistics>;
  } {
    return {
      running: this.running,
      lastPollTime: this.lastPollTime,
      health: healthMonitor.getHealth(),
      regime: regimeAnalyzer.getCurrentRegime(),
      watches: watchManager.getStatistics(),
    };
  }
}

// Create and export system instance
const system = new DexScreenerIntelligenceSystem();

// Handle process signals
process.on('SIGINT', async () => {
  logger.info('SIGINT received');
  await system.stop('SIGINT');
  process.exit(0);
});

process.on('SIGTERM', async () => {
  logger.info('SIGTERM received');
  await system.stop('SIGTERM');
  process.exit(0);
});

process.on('uncaughtException', async (error) => {
  logger.error('Uncaught exception:', error);
  await alertBot?.sendError(error, 'Uncaught exception');
  await system.stop('Uncaught exception');
  process.exit(1);
});

process.on('unhandledRejection', async (reason, promise) => {
  logger.error('Unhandled rejection at:', promise, 'reason:', reason);
});

// Start the system
system.start().catch(async (error) => {
  logger.error('Failed to start system:', error);
  await alertBot?.sendError(error, 'System startup failure');
  process.exit(1);
});

export default system;
