/**
 * Signal Bot
 * 
 * Sends intelligence-rich alerts and handles user interactions:
 * - Inline buttons: [🔄 Refresh] [👁 Watch]
 * - Callback handling: refresh:<token>, watch:<token>
 * - /ping health command
 * - Watch mode management
 */

import TelegramBot from 'node-telegram-bot-api';
import { getEnv } from '../config';
import { Logger } from '../utils/logger';
import { TokenAlert, WatchSession, ExitAlert } from '../types';
import { healthMonitor } from '../system/health';
import { watchManager } from '../watch/manager';
import { regimeAnalyzer } from '../engines/regime';
import { selfDefenseManager } from '../system/selfDefense';
import { formatUsd, formatPercent, escapeMarkdown, truncate } from '../utils/helpers';

const logger = new Logger('SignalBot');

export class SignalBot {
  private bot: TelegramBot;
  private chatId: string;
  private connected: boolean = false;
  private messageHandlers: Map<string, (msg: TelegramBot.Message) => void> = new Map();

  constructor() {
    const env = getEnv();
    
    if (!env.SIGNAL_BOT_TOKEN) {
      throw new Error('SIGNAL_BOT_TOKEN not configured');
    }

    this.bot = new TelegramBot(env.SIGNAL_BOT_TOKEN, { polling: true });
    this.chatId = env.SIGNAL_CHAT_ID;

    this.initialize();
    this.setupCommands();
    this.setupCallbacks();
  }

  /**
   * Initialize bot
   */
  private async initialize(): Promise<void> {
    try {
      const me = await this.bot.getMe();
      logger.info(`Signal Bot initialized: @${me.username}`);
      this.connected = true;

      // Set bot commands
      await this.bot.setMyCommands([
        { command: 'ping', description: 'Check system health' },
        { command: 'status', description: 'Get current status' },
        { command: 'regime', description: 'Get market regime' },
        { command: 'watches', description: 'List active watch sessions' },
        { command: 'help', description: 'Show help' },
      ]);
    } catch (error) {
      logger.error('Failed to initialize signal bot:', error);
      this.connected = false;
    }
  }

  /**
   * Setup command handlers
   */
  private setupCommands(): void {
    // /ping command
    this.bot.onText(/\/ping/, async (msg) => {
      await this.handlePing(msg);
    });

    // /status command
    this.bot.onText(/\/status/, async (msg) => {
      await this.handleStatus(msg);
    });

    // /regime command
    this.bot.onText(/\/regime/, async (msg) => {
      await this.handleRegime(msg);
    });

    // /watches command
    this.bot.onText(/\/watches/, async (msg) => {
      await this.handleWatches(msg);
    });

    // /help command
    this.bot.onText(/\/help/, async (msg) => {
      await this.handleHelp(msg);
    });
  }

  /**
   * Setup callback query handlers
   */
  private setupCallbacks(): void {
    this.bot.on('callback_query', async (query) => {
      try {
        const data = query.data;
        if (!data) return;

        logger.debug(`Received callback: ${data}`);

        // Parse callback data: action:params
        const [action, ...params] = data.split(':');

        switch (action) {
          case 'refresh':
            await this.handleRefreshCallback(query, params[0]);
            break;
          case 'watch':
            await this.handleWatchCallback(query, params[0], params[1]);
            break;
          case 'unwatch':
            await this.handleUnwatchCallback(query, params[0]);
            break;
          default:
            logger.warn(`Unknown callback action: ${action}`);
        }

        // Answer callback to remove loading state
        await this.bot.answerCallbackQuery(query.id);
      } catch (error) {
        logger.error('Error handling callback:', error);
        await this.bot.answerCallbackQuery(query.id, { text: 'Error processing request' });
      }
    });
  }

  /**
   * Handle /ping command
   */
  private async handlePing(msg: TelegramBot.Message): Promise<void> {
    const ping = healthMonitor.getPingResponse();
    
    const status = ping.status === 'HEALTHY' ? '🟢' : 
                   ping.status === 'DEGRADED' ? '🟡' : 
                   ping.status === 'SAFE_MODE' ? '🛡️' : '🔴';

    const message = `
${status} *SYSTEM HEALTH CHECK*

*Status:* ${ping.status}
*Latency:* ${ping.latency}ms
*Market Regime:* ${ping.regime}
*Safe Mode:* ${ping.safeMode ? 'Active' : 'Inactive'}
*Error Rate:* ${(ping.errorRate * 100).toFixed(2)}%
*Active Watches:* ${ping.activeWatches}
*Uptime:* ${ping.uptime}
*Version:* ${ping.version}

_Last checked: ${new Date().toISOString()}_
    `.trim();

    await this.sendMessage(message, msg.chat.id);
  }

  /**
   * Handle /status command
   */
  private async handleStatus(msg: TelegramBot.Message): Promise<void> {
    const health = healthMonitor.getHealth();
    const regime = regimeAnalyzer.getCurrentRegime();
    const selfDefense = selfDefenseManager.getStatus();
    const watchStats = watchManager.getStatistics();

    const message = `
📊 *SYSTEM STATUS*

*Health:* ${health.status}
*Market Regime:* ${regime.currentRegime} (${(regime.confidence * 100).toFixed(0)}% confidence)
*Safe Mode:* ${selfDefense.active ? '🛡️ Active' : '✅ Inactive'}

*Watch Sessions:*
• Active: ${watchStats.activeSessions}
• Total: ${watchStats.totalSessions}
• Alerts Sent: ${watchStats.totalAlertsSent}

*Resources:*
• Memory: ${health.resources.memoryUsagePercent.toFixed(1)}%
• Uptime: ${this.formatUptime(health.resources.uptimeSeconds)}

*Components:*
• Dex API: ${health.components.dexApi ? '✅' : '❌'}
• Signal Bot: ${health.components.signalBot ? '✅' : '❌'}
• Alert Bot: ${health.components.alertBot ? '✅' : '❌'}
    `.trim();

    await this.sendMessage(message, msg.chat.id);
  }

  /**
   * Handle /regime command
   */
  private async handleRegime(msg: TelegramBot.Message): Promise<void> {
    const regime = regimeAnalyzer.getCurrentRegime();
    const description = regimeAnalyzer.getRegimeDescription(regime.currentRegime);
    const recommendations = regimeAnalyzer.getRecommendations();

    const message = `
🌊 *MARKET REGIME ANALYSIS*

*Current Regime:* ${regime.currentRegime}
*Confidence:* ${(regime.confidence * 100).toFixed(0)}%
*Since:* ${new Date(regime.since).toISOString()}

*Description:*
${description}

*Current Metrics:*
• Rug Rate (24h): ${(regime.metrics.rugRate24h * 100).toFixed(1)}%
• Avg Authenticity: ${(regime.metrics.averageAuthenticity * 100).toFixed(1)}%
• Whale Participation: ${(regime.metrics.whaleParticipationRate * 100).toFixed(1)}%
• Launch Frequency: ${regime.metrics.launchFrequency}

*Recommendations:*
${recommendations.map(r => `• ${r}`).join('\n')}
    `.trim();

    await this.sendMessage(message, msg.chat.id);
  }

  /**
   * Handle /watches command
   */
  private async handleWatches(msg: TelegramBot.Message): Promise<void> {
    const sessions = watchManager.getActiveSessions();

    if (sessions.length === 0) {
      await this.sendMessage('No active watch sessions.', msg.chat.id);
      return;
    }

    const message = `
👁 *ACTIVE WATCH SESSIONS* (${sessions.length})

${sessions.map(s => `
*${escapeMarkdown(s.tokenSymbol)}*
• Price: $${s.lastPrice.toFixed(6)}
• From Baseline: ${formatPercent((s.lastPrice - s.baselinePrice) / s.baselinePrice)}
• Alerts: ${s.alertCount}
• Expires: ${new Date(s.expiresAt).toLocaleTimeString()}
`).join('\n')}
    `.trim();

    await this.sendMessage(message, msg.chat.id);
  }

  /**
   * Handle /help command
   */
  private async handleHelp(msg: TelegramBot.Message): Promise<void> {
    const message = `
🤖 *DexScreener Intelligence Bot - Help*

*Available Commands:*
/ping - Check system health and status
/status - Get detailed system status
/regime - View current market regime analysis
/watches - List active watch sessions
/help - Show this help message

*Alert Interactions:*
🔄 Refresh - Get updated token analysis
👁 Watch - Start watching token for changes

*Features:*
• Real-time token monitoring
• Multi-engine risk analysis
• Whale detection
• Exit signal alerts
• Market regime adaptation
• Self-defense protection

For support, contact the system administrator.
    `.trim();

    await this.sendMessage(message, msg.chat.id);
  }

  /**
   * Handle refresh callback
   */
  private async handleRefreshCallback(
    query: TelegramBot.CallbackQuery,
    tokenAddress: string
  ): Promise<void> {
    if (!query.message) return;

    // Send "refreshing" message
    await this.bot.sendMessage(
      query.message.chat.id,
      `🔄 Refreshing analysis for token...`,
      { reply_to_message_id: query.message.message_id }
    );

    // The actual refresh would be handled by the main application
    // This is just acknowledging the callback
  }

  /**
   * Handle watch callback
   */
  private async handleWatchCallback(
    query: TelegramBot.CallbackQuery,
    tokenAddress: string,
    tokenSymbol: string
  ): Promise<void> {
    if (!query.message || !query.from) return;

    // Check if already watching
    const existingSession = watchManager.getSessionByToken(tokenAddress);
    if (existingSession) {
      await this.bot.sendMessage(
        query.message.chat.id,
        `⚠️ Already watching ${tokenSymbol}. Session expires at ${new Date(existingSession.expiresAt).toLocaleTimeString()}`,
        { reply_to_message_id: query.message.message_id }
      );
      return;
    }

    // Create watch session
    const session = watchManager.createSession(
      tokenAddress,
      tokenSymbol,
      {} as any, // Would need actual metrics
      query.message.chat.id.toString(),
      query.from.id.toString()
    );

    await this.bot.sendMessage(
      query.message.chat.id,
      `👁 Started watching *${tokenSymbol}*\n\nSession ID: \`${session.id}\`\nExpires: ${new Date(session.expiresAt).toLocaleTimeString()}`,
      { 
        parse_mode: 'Markdown',
        reply_to_message_id: query.message.message_id 
      }
    );
  }

  /**
   * Handle unwatch callback
   */
  private async handleUnwatchCallback(
    query: TelegramBot.CallbackQuery,
    sessionId: string
  ): Promise<void> {
    if (!query.message) return;

    const success = watchManager.endSession(sessionId);
    
    await this.bot.sendMessage(
      query.message.chat.id,
      success ? '✅ Watch session ended.' : '⚠️ Session not found.',
      { reply_to_message_id: query.message.message_id }
    );
  }

  /**
   * Send token alert
   */
  public async sendTokenAlert(alert: TokenAlert): Promise<void> {
    if (!this.connected || !this.chatId) return;

    const token = alert.token;
    const probability = alert.probability;
    const risk = alert.risk;
    const whale = alert.whale;
    const ranking = alert.ranking;

    const whaleBadge = whale.badge === 'MEGA' ? '🐋' : 
                       whale.badge === 'LARGE' ? '🦈' : 
                       whale.badge === 'MEDIUM' ? '🐟' : '';

    const riskEmoji = risk.level === 'LOW' ? '🟢' : 
                      risk.level === 'MEDIUM' ? '🟡' : 
                      risk.level === 'HIGH' ? '🟠' : '🔴';

    const message = `
🎯 *NEW TOKEN ALERT* #${ranking.rank}

*${escapeMarkdown(token.symbol)}* ${whaleBadge}
${escapeMarkdown(token.name)}
\`${token.address}\`

*Price:* $${token.priceUsd.toFixed(6)}
*Market Cap:* ${formatUsd(token.marketCap)}
*Liquidity:* ${formatUsd(token.liquidityUsd)}
*Age:* ${Math.floor(token.ageMinutes)}m

*Price Changes:*
• 5m: ${formatPercent(token.priceChange5m)}
• 1h: ${formatPercent(token.priceChange1h)}
• 24h: ${formatPercent(token.priceChange24h)}

*Probability Score:* ${(probability.score * 100).toFixed(1)}% (${probability.level})
*Confidence:* ${(probability.confidence * 100).toFixed(1)}%

*Risk Assessment:* ${riskEmoji} ${risk.level}
*Risk Score:* ${(risk.score * 100).toFixed(1)}%

*Whale Activity:* ${whale.detected ? `Detected (${whale.badge})` : 'None'}
${whale.detected ? `• Net Flow: ${formatUsd(whale.summary.netWhaleFlow)}` : ''}

*Composite Score:* ${(ranking.compositeScore * 100).toFixed(1)}
*Market Regime:* ${alert.regime.currentRegime}

${risk.warnings.length > 0 ? '*Warnings:*\n' + risk.warnings.map(w => `⚠️ ${w}`).join('\n') : ''}

[View on DexScreener](https://dexscreener.com/${token.chainId}/${token.address})
    `.trim();

    const keyboard = {
      inline_keyboard: [
        [
          { text: '🔄 Refresh', callback_data: `refresh:${token.address}` },
          { text: '👁 Watch', callback_data: `watch:${token.address}:${token.symbol}` },
        ],
      ],
    };

    try {
      await this.bot.sendMessage(this.chatId, message, {
        parse_mode: 'Markdown',
        reply_markup: keyboard,
        disable_web_page_preview: true,
      });
      logger.info(`Sent token alert for ${token.symbol}`);
    } catch (error) {
      logger.error('Failed to send token alert:', error);
    }
  }

  /**
   * Send exit signal alert
   */
  public async sendExitAlert(alert: ExitAlert): Promise<void> {
    if (!this.connected || !this.chatId) return;

    const token = alert.token;
    const exit = alert.exitSignal;

    const urgencyEmoji = exit.urgency === 'IMMEDIATE' ? '🔴' :
                         exit.urgency === 'HIGH' ? '🟠' :
                         exit.urgency === 'MEDIUM' ? '🟡' : '🟢';

    const message = `
🚨 *EXIT SIGNAL* ${urgencyEmoji}

*${escapeMarkdown(token.symbol)}*
\`${token.address}\`

*Current Price:* $${alert.currentPrice.toFixed(6)}
*Price Change:* ${formatPercent(alert.priceChangeSinceAlert)}

*Urgency:* ${exit.urgency}

*Exit Reasons:*
${exit.reasons.map(r => `• ${r}`).join('\n')}

*Metrics:*
• Liquidity Drop: ${(exit.metrics.liquidityDropPercent * 100).toFixed(1)}%
• Volume Decay: ${(exit.metrics.volumeDecayPercent * 100).toFixed(1)}%
• Rug Probability: ${(exit.metrics.rugProbabilityScore * 100).toFixed(1)}%

*Recommended Action:*
${exit.recommendedAction}

[View on DexScreener](https://dexscreener.com/${token.chainId}/${token.address})
    `.trim();

    try {
      await this.bot.sendMessage(this.chatId, message, {
        parse_mode: 'Markdown',
        disable_web_page_preview: true,
      });
      logger.info(`Sent exit alert for ${token.symbol}`);
    } catch (error) {
      logger.error('Failed to send exit alert:', error);
    }
  }

  /**
   * Send watch mode update
   */
  public async sendWatchUpdate(
    session: WatchSession,
    changes: { priceChangePercent: number },
    significant: boolean
  ): Promise<void> {
    if (!this.connected || !this.chatId) return;

    const changeEmoji = changes.priceChangePercent >= 0 ? '🟢' : '🔴';

    const message = `
👁 *WATCH UPDATE: ${escapeMarkdown(session.tokenSymbol)}*

*Current Price:* $${session.lastPrice.toFixed(6)}
*Change:* ${changeEmoji} ${formatPercent(changes.priceChangePercent)}
*From Baseline:* ${formatPercent((session.lastPrice - session.baselinePrice) / session.baselinePrice)}
*Peak:* $${session.highestPrice.toFixed(6)}

*Session:* ${session.id}
*Alerts:* ${session.alertCount}
*Expires:* ${new Date(session.expiresAt).toLocaleTimeString()}
    `.trim();

    try {
      await this.bot.sendMessage(this.chatId, message, {
        parse_mode: 'Markdown',
      });
    } catch (error) {
      logger.error('Failed to send watch update:', error);
    }
  }

  /**
   * Send message
   */
  public async sendMessage(message: string, chatId?: number | string): Promise<void> {
    if (!this.connected) return;

    const targetChatId = chatId || this.chatId;
    if (!targetChatId) {
      logger.warn('No chat ID available for sending message');
      return;
    }

    try {
      await this.bot.sendMessage(targetChatId, message, { parse_mode: 'Markdown' });
    } catch (error) {
      logger.error('Failed to send message:', error);
    }
  }

  /**
   * Format uptime
   */
  private formatUptime(seconds: number): string {
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const mins = Math.floor((seconds % 3600) / 60);

    if (days > 0) return `${days}d ${hours}h ${mins}m`;
    if (hours > 0) return `${hours}h ${mins}m`;
    return `${mins}m`;
  }

  /**
   * Check connection status
   */
  public isConnected(): boolean {
    return this.connected;
  }

  /**
   * Stop bot
   */
  public stop(): void {
    this.bot.stopPolling();
    logger.info('Signal bot stopped');
  }
}

// Export singleton instance
export let signalBot: SignalBot;

export function initializeSignalBot(): SignalBot {
  signalBot = new SignalBot();
  return signalBot;
}
