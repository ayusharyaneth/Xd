/**
 * Alert Bot
 * 
 * Sends operational and runtime alerts
 * Simpler bot focused on system notifications
 */

import TelegramBot from 'node-telegram-bot-api';
import { getEnv } from '../config';
import { Logger } from '../utils/logger';
import { SystemHealth, SelfDefenseStatus } from '../types';

const logger = new Logger('AlertBot');

export class AlertBot {
  private bot: TelegramBot;
  private chatId: string;
  private connected: boolean = false;

  constructor() {
    const env = getEnv();
    
    if (!env.ALERT_BOT_TOKEN) {
      throw new Error('ALERT_BOT_TOKEN not configured');
    }

    this.bot = new TelegramBot(env.ALERT_BOT_TOKEN, { polling: false });
    this.chatId = env.ALERT_CHAT_ID || env.SIGNAL_CHAT_ID;

    this.initialize();
  }

  /**
   * Initialize bot
   */
  private async initialize(): Promise<void> {
    try {
      const me = await this.bot.getMe();
      logger.info(`Alert Bot initialized: @${me.username}`);
      this.connected = true;
    } catch (error) {
      logger.error('Failed to initialize alert bot:', error);
      this.connected = false;
    }
  }

  /**
   * Send system startup notification
   */
  public async sendStartup(): Promise<void> {
    if (!this.connected) return;

    const message = `
🚀 *DexScreener Intelligence System Started*

⏰ Time: ${new Date().toISOString()}
🌐 Environment: ${getEnv().NODE_ENV}
📊 Status: Operational

System is now monitoring for new token launches.
    `.trim();

    await this.sendMessage(message);
  }

  /**
   * Send system shutdown notification
   */
  public async sendShutdown(reason?: string): Promise<void> {
    if (!this.connected) return;

    const message = `
🛑 *DexScreener Intelligence System Stopped*

⏰ Time: ${new Date().toISOString()}
${reason ? `📝 Reason: ${reason}` : ''}

System has been shut down.
    `.trim();

    await this.sendMessage(message);
  }

  /**
   * Send safe mode activation alert
   */
  public async sendSafeModeActivated(status: SelfDefenseStatus): Promise<void> {
    if (!this.connected) return;

    const metrics = status.metrics;
    const message = `
🛡️ *SAFE MODE ACTIVATED*

⚠️ System has entered safe mode due to detected issues.

*Metrics at activation:*
• API Error Rate: ${(metrics.apiErrorRate * 100).toFixed(1)}%
• Latency: ${metrics.averageLatency}ms
• Memory Usage: ${metrics.memoryUsage.toFixed(1)}%
• CPU Usage: ${metrics.cpuUsage.toFixed(1)}%

*Reason:* ${status.reason || 'Unknown'}

System will automatically recover when metrics improve.
    `.trim();

    await this.sendMessage(message);
  }

  /**
   * Send safe mode deactivation notification
   */
  public async sendSafeModeDeactivated(): Promise<void> {
    if (!this.connected) return;

    const message = `
✅ *SAFE MODE DEACTIVATED*

System has recovered and exited safe mode.

All operations are now running normally.
    `.trim();

    await this.sendMessage(message);
  }

  /**
   * Send health degradation alert
   */
  public async sendHealthDegraded(health: SystemHealth): Promise<void> {
    if (!this.connected) return;

    const message = `
⚠️ *HEALTH DEGRADATION DETECTED*

*Status:* ${health.status}
*Latency:* ${health.latency.overall}ms
*Error Rate:* ${(health.errorRates.overall * 100).toFixed(1)}%
*Memory:* ${health.resources.memoryUsagePercent.toFixed(1)}%

*Component Status:*
• Dex API: ${health.components.dexApi ? '✅' : '❌'}
• Signal Bot: ${health.components.signalBot ? '✅' : '❌'}
• Alert Bot: ${health.components.alertBot ? '✅' : '❌'}

Monitoring for recovery...
    `.trim();

    await this.sendMessage(message);
  }

  /**
   * Send error notification
   */
  public async sendError(error: Error, context?: string): Promise<void> {
    if (!this.connected) return;

    const message = `
❌ *SYSTEM ERROR*

*Context:* ${context || 'Unknown'}
*Error:* ${error.message}

*Stack:*
\`\`\`
${error.stack?.substring(0, 500) || 'No stack trace'}
\`\`\`

Please investigate if errors persist.
    `.trim();

    await this.sendMessage(message);
  }

  /**
   * Send API error notification
   */
  public async sendApiError(service: string, error: string): Promise<void> {
    if (!this.connected) return;

    const message = `
🔌 *API ERROR*

*Service:* ${service}
*Error:* ${error}
*Time:* ${new Date().toISOString()}

System will retry automatically.
    `.trim();

    await this.sendMessage(message);
  }

  /**
   * Send daily summary
   */
  public async sendDailySummary(stats: {
    tokensProcessed: number;
    alertsSent: number;
    watchSessions: number;
    regime: string;
  }): Promise<void> {
    if (!this.connected) return;

    const message = `
📊 *DAILY SUMMARY*

*Tokens Processed:* ${stats.tokensProcessed}
*Alerts Sent:* ${stats.alertsSent}
*Active Watch Sessions:* ${stats.watchSessions}
*Market Regime:* ${stats.regime}

*System Status:* ✅ Healthy

Report generated at ${new Date().toISOString()}
    `.trim();

    await this.sendMessage(message);
  }

  /**
   * Send generic alert
   */
  public async sendAlert(title: string, message: string, level: 'INFO' | 'WARN' | 'ERROR' = 'INFO'): Promise<void> {
    if (!this.connected) return;

    const icons = { INFO: 'ℹ️', WARN: '⚠️', ERROR: '❌' };
    
    const formattedMessage = `
${icons[level]} *${title}*

${message}

_Time: ${new Date().toISOString()}_
    `.trim();

    await this.sendMessage(formattedMessage);
  }

  /**
   * Send raw message
   */
  public async sendMessage(message: string, parseMode: 'Markdown' | 'HTML' = 'Markdown'): Promise<void> {
    if (!this.connected || !this.chatId) {
      logger.warn('Cannot send message: bot not connected or chat ID not set');
      return;
    }

    try {
      await this.bot.sendMessage(this.chatId, message, { parse_mode: parseMode });
      logger.debug('Alert message sent');
    } catch (error) {
      logger.error('Failed to send alert message:', error);
    }
  }

  /**
   * Check bot connection status
   */
  public isConnected(): boolean {
    return this.connected;
  }

  /**
   * Test connection
   */
  public async testConnection(): Promise<boolean> {
    try {
      await this.bot.getMe();
      this.connected = true;
      return true;
    } catch (error) {
      this.connected = false;
      return false;
    }
  }
}

// Export singleton instance
export let alertBot: AlertBot;

export function initializeAlertBot(): AlertBot {
  alertBot = new AlertBot();
  return alertBot;
}
