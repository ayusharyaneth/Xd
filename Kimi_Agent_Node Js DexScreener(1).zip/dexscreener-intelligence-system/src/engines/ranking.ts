/**
 * Ranking Engine
 * 
 * Ranks tokens using composite scoring:
 * - Probability score
 * - Risk-adjusted return
 * - Momentum score
 * - Whale confidence
 * - Time sensitivity
 * 
 * Implements buffering and suppression logic
 */

import { TokenAlert, TokenRanking, ProbabilityAssessment, RiskAssessment, WhaleActivity, TokenMetrics } from '../types';
import { getStrategy } from '../config';
import { Logger } from '../utils/logger';
import { clamp, calculateTimeDecay, weightedAverage } from '../utils/helpers';

const logger = new Logger('RankingEngine');

export interface RankableToken {
  address: string;
  symbol: string;
  metrics: TokenMetrics;
  probability: ProbabilityAssessment;
  risk: RiskAssessment;
  whale: WhaleActivity;
  timestamp: number;
}

export class RankingEngine {
  private config = getStrategy().ranking_engine;
  private alertBuffer: Map<string, RankableToken> = new Map();
  private lastAlertTime: Map<string, number> = new Map();

  /**
   * Calculate composite ranking score
   */
  public calculateRanking(
    token: RankableToken
  ): TokenRanking {
    logger.debug(`Calculating ranking for ${token.symbol}`);

    const components = {
      probabilityScore: this.calculateProbabilityComponent(token.probability),
      riskAdjustedReturn: this.calculateRiskAdjustedReturn(token),
      momentumScore: this.calculateMomentumScore(token.metrics),
      whaleConfidence: this.calculateWhaleComponent(token.whale),
      timeSensitivity: this.calculateTimeSensitivity(token),
    };

    const compositeScore = this.calculateCompositeScore(components);
    const decision = this.determineDecision(compositeScore, token);

    return {
      rank: 0, // Will be set after sorting
      compositeScore,
      components,
      decision,
      suppressionReason: decision === 'SUPPRESS' ? this.getSuppressionReason(compositeScore) : undefined,
    };
  }

  /**
   * Calculate probability component
   */
  private calculateProbabilityComponent(
    probability: ProbabilityAssessment
  ): number {
    // Weight by confidence
    return probability.score * (0.5 + probability.confidence * 0.5);
  }

  /**
   * Calculate risk-adjusted return component
   */
  private calculateRiskAdjustedReturn(token: RankableToken): number {
    const expectedReturn = token.probability.score;
    const risk = token.risk.score;
    
    // Sharpe-like ratio: return / risk
    if (risk === 0) return expectedReturn;
    
    return expectedReturn / (1 + risk);
  }

  /**
   * Calculate momentum score
   */
  private calculateMomentumScore(metrics: TokenMetrics): number {
    let score = 0.5;

    // Price momentum
    const priceMomentum = 
      metrics.priceChange5m * 0.4 + 
      metrics.priceChange1h * 0.35 + 
      metrics.priceChange24h * 0.25;
    
    score += Math.min(priceMomentum * 2, 0.3);

    // Volume momentum
    const volume5mRatio = metrics.volume5m / Math.max(metrics.volume1h / 12, 1);
    if (volume5mRatio > 2) {
      score += 0.1;
    } else if (volume5mRatio < 0.5) {
      score -= 0.1;
    }

    // Transaction momentum
    const txnMomentum = (metrics.buys5m - metrics.sells5m) / 
      Math.max(metrics.buys5m + metrics.sells5m, 1);
    score += txnMomentum * 0.1;

    return clamp(score, 0, 1);
  }

  /**
   * Calculate whale confidence component
   */
  private calculateWhaleComponent(whale: WhaleActivity): number {
    if (!whale.detected) {
      return 0.5;
    }

    let score = 0.5;

    // Net flow direction
    if (whale.summary.netWhaleFlow > 0) {
      score += 0.2;
    } else if (whale.summary.netWhaleFlow < 0) {
      score -= 0.2;
    }

    // Whale badge bonus
    const badgeBonus = {
      'NONE': 0,
      'MEDIUM': 0.05,
      'LARGE': 0.1,
      'MEGA': 0.15,
    };
    score += badgeBonus[whale.badge];

    // Confidence factor
    score += whale.confidence * 0.1;

    return clamp(score, 0, 1);
  }

  /**
   * Calculate time sensitivity component
   */
  private calculateTimeSensitivity(token: RankableToken): number {
    const ageHours = token.metrics.ageHours;
    let score = 0.5;

    // Newer tokens have higher time sensitivity
    if (ageHours < 1) {
      score = 0.9;
    } else if (ageHours < 6) {
      score = 0.8;
    } else if (ageHours < 24) {
      score = 0.6;
    } else {
      score = 0.4;
    }

    // Apply time decay since detection
    const decay = calculateTimeDecay(
      token.timestamp,
      this.config.time_decay.half_life_minutes
    );
    score *= decay;

    return clamp(score, 0, 1);
  }

  /**
   * Calculate composite score from components
   */
  private calculateCompositeScore(
    components: TokenRanking['components']
  ): number {
    const weights = this.config.composite_score_weights;

    return weightedAverage(
      [
        components.probabilityScore,
        components.riskAdjustedReturn,
        components.momentumScore,
        components.whaleConfidence,
        components.timeSensitivity,
      ],
      [
        weights.probability_score,
        weights.risk_adjusted_return,
        weights.momentum_score,
        weights.whale_confidence,
        weights.time_sensitivity,
      ]
    );
  }

  /**
   * Determine alert decision
   */
  private determineDecision(
    score: number,
    token: RankableToken
  ): TokenRanking['decision'] {
    // Check minimum score threshold
    if (score < this.config.output.min_score_to_alert) {
      return 'SUPPRESS';
    }

    // Check alert interval
    const lastAlert = this.lastAlertTime.get(token.address);
    if (lastAlert) {
      const minInterval = getStrategy().system.cooldowns.token_alert_seconds * 1000;
      if (Date.now() - lastAlert < minInterval) {
        return 'SUPPRESS';
      }
    }

    // High scores always alert
    if (score >= this.config.output.min_score_to_alert * 1.5) {
      return 'ALERT';
    }

    // Medium scores may be buffered
    if (score >= this.config.output.min_score_to_alert) {
      return 'WATCH';
    }

    return 'SUPPRESS';
  }

  /**
   * Get suppression reason
   */
  private getSuppressionReason(score: number): string {
    if (score < this.config.output.suppression_threshold) {
      return 'Score below suppression threshold';
    }
    if (score < this.config.output.min_score_to_alert) {
      return 'Score below minimum alert threshold';
    }
    return 'Alert cooldown active';
  }

  /**
   * Add token to ranking buffer
   */
  public bufferToken(token: RankableToken): void {
    this.alertBuffer.set(token.address, token);
    logger.debug(`Buffered token: ${token.symbol}`);
  }

  /**
   * Process buffer and return ranked alerts
   */
  public processBuffer(): TokenAlert[] {
    const tokens = Array.from(this.alertBuffer.values());
    
    if (tokens.length === 0) {
      return [];
    }

    // Calculate rankings
    const ranked = tokens.map(token => ({
      token,
      ranking: this.calculateRanking(token),
    }));

    // Sort by composite score descending
    ranked.sort((a, b) => b.ranking.compositeScore - a.ranking.compositeScore);

    // Assign ranks
    ranked.forEach((item, index) => {
      item.ranking.rank = index + 1;
    });

    // Take top N
    const topN = this.config.output.top_n_alerts;
    const selected = ranked.slice(0, topN);

    // Mark suppressed tokens
    const suppressed = ranked.slice(topN);
    suppressed.forEach(item => {
      item.ranking.decision = 'SUPPRESS';
      item.ranking.suppressionReason = 'Lower rank than top N';
    });

    // Clear buffer
    this.alertBuffer.clear();

    // Update last alert times
    selected.forEach(item => {
      this.lastAlertTime.set(item.token.address, Date.now());
    });

    logger.info(`Processed ${tokens.length} tokens, selected top ${selected.length}`);

    // Convert to TokenAlert format (partial)
    return selected.map(item => this.createAlertFromRanked(item.token, item.ranking));
  }

  /**
   * Create alert from ranked token
   */
  private createAlertFromRanked(
    token: RankableToken,
    ranking: TokenRanking
  ): TokenAlert {
    return {
      id: `${token.address}-${Date.now()}`,
      timestamp: Date.now(),
      token: token.metrics,
      risk: token.risk,
      authenticity: { score: 0.5, level: 'MEDIUM', factors: {} as any, checks: {} as any },
      developer: { score: 0.5, level: 'UNKNOWN', history: {} as any, flags: [] },
      buyQuality: { score: 0.5, level: 'FAIR', metrics: {} as any, patterns: {} as any },
      whale: token.whale,
      probability: token.probability,
      ranking,
      regime: { currentRegime: 'NORMAL', confidence: 1, metrics: {} as any, adaptations: {} as any, since: Date.now() },
      priority: this.mapScoreToPriority(ranking.compositeScore),
      sent: false,
      suppressed: ranking.decision === 'SUPPRESS',
      suppressionReason: ranking.suppressionReason,
    };
  }

  /**
   * Map score to priority
   */
  private mapScoreToPriority(score: number): TokenAlert['priority'] {
    if (score >= 0.8) return 'CRITICAL';
    if (score >= 0.6) return 'HIGH';
    if (score >= 0.4) return 'MEDIUM';
    return 'LOW';
  }

  /**
   * Rank multiple tokens and return sorted list
   */
  public rankTokens(tokens: RankableToken[]): Array<{ token: RankableToken; ranking: TokenRanking }> {
    const ranked = tokens.map(token => ({
      token,
      ranking: this.calculateRanking(token),
    }));

    ranked.sort((a, b) => b.ranking.compositeScore - a.ranking.compositeScore);
    ranked.forEach((item, index) => {
      item.ranking.rank = index + 1;
    });

    return ranked;
  }

  /**
   * Get buffer size
   */
  public getBufferSize(): number {
    return this.alertBuffer.size;
  }

  /**
   * Clear buffer
   */
  public clearBuffer(): void {
    this.alertBuffer.clear();
    logger.info('Ranking buffer cleared');
  }

  /**
   * Cleanup old alert times
   */
  public cleanup(): void {
    const maxAge = getStrategy().system.cooldowns.token_alert_seconds * 1000 * 10;
    const now = Date.now();

    for (const [address, timestamp] of this.lastAlertTime.entries()) {
      if (now - timestamp > maxAge) {
        this.lastAlertTime.delete(address);
      }
    }
  }
}

// Export singleton instance
export const rankingEngine = new RankingEngine();
