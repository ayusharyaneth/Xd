/**
 * Probability Engine
 * 
 * Calculates success probability by combining all engine outputs
 * with configurable weights and confidence scoring
 */

import { 
  TokenMetrics, 
  ProbabilityAssessment, 
  RiskAssessment, 
  AuthenticityAssessment,
  DeveloperReputation,
  BuyQualityAssessment,
  WhaleActivity,
  MarketRegime 
} from '../types';
import { getStrategy } from '../config';
import { Logger } from '../utils/logger';
import { clamp, weightedAverage, calculateTimeDecay } from '../utils/helpers';

const logger = new Logger('ProbabilityEngine');

export interface ProbabilityInputs {
  risk: RiskAssessment;
  authenticity: AuthenticityAssessment;
  developer: DeveloperReputation;
  buyQuality: BuyQualityAssessment;
  whale: WhaleActivity;
  regime: MarketRegime;
}

export class ProbabilityEngine {
  private config = getStrategy().probability_engine;

  /**
   * Calculate success probability
   */
  public calculate(
    metrics: TokenMetrics,
    inputs: ProbabilityInputs
  ): ProbabilityAssessment {
    logger.debug(`Calculating probability for ${metrics.symbol}`);

    const weights = this.config.weights;

    // Calculate individual factor scores
    const factors = {
      riskAdjusted: this.calculateRiskAdjustedScore(inputs.risk),
      authenticityBoost: inputs.authenticity.score,
      developerBoost: inputs.developer.score,
      qualityBoost: inputs.buyQuality.score,
      whaleConfidence: this.calculateWhaleConfidence(inputs.whale),
      timingScore: this.calculateTimingScore(metrics, inputs.regime),
    };

    // Calculate weighted probability score
    const rawScore = weightedAverage(
      [
        factors.riskAdjusted,
        factors.authenticityBoost,
        factors.developerBoost,
        factors.qualityBoost,
        factors.whaleConfidence,
        factors.timingScore,
      ],
      [
        weights.risk_score,
        weights.authenticity_score,
        weights.developer_score,
        weights.buy_quality_score,
        weights.whale_confidence,
        weights.market_timing,
      ]
    );

    // Apply market regime adjustment
    const adjustedScore = this.applyRegimeAdjustment(rawScore, inputs.regime);

    // Calculate confidence
    const confidence = this.calculateConfidence(inputs, metrics);

    // Determine level
    const level = this.determineProbabilityLevel(adjustedScore);

    // Calculate timeframe projections
    const timeframe = this.calculateTimeframeProjections(adjustedScore, inputs);

    return {
      score: clamp(adjustedScore, 0, 1),
      confidence,
      level,
      factors,
      timeframe,
    };
  }

  /**
   * Calculate risk-adjusted score (inverse of risk)
   */
  private calculateRiskAdjustedScore(risk: RiskAssessment): number {
    // Invert risk score (lower risk = higher score)
    const invertedRisk = 1 - risk.score;
    
    // Apply non-linear transformation to emphasize low-risk tokens
    return Math.pow(invertedRisk, 0.7);
  }

  /**
   * Calculate whale confidence contribution
   */
  private calculateWhaleConfidence(whale: WhaleActivity): number {
    if (!whale.detected) {
      return 0.5; // Neutral when no whales
    }

    let score = 0.5;

    // Net flow direction
    if (whale.summary.netWhaleFlow > 0) {
      score += 0.2;
    } else if (whale.summary.netWhaleFlow < 0) {
      score -= 0.2;
    }

    // Whale badge level
    const badgeBonus = {
      'NONE': 0,
      'MEDIUM': 0.05,
      'LARGE': 0.1,
      'MEGA': 0.15,
    };
    score += badgeBonus[whale.badge];

    // Confidence factor
    score += whale.confidence * 0.1;

    // Multiple whales is good (if buying)
    if (whale.summary.uniqueWhales >= 3 && whale.summary.netWhaleFlow > 0) {
      score += 0.1;
    }

    return clamp(score, 0, 1);
  }

  /**
   * Calculate timing score based on market regime and token age
   */
  private calculateTimingScore(
    metrics: TokenMetrics,
    regime: MarketRegime
  ): number {
    let score = 0.5;

    // Token age factor
    const ageHours = metrics.ageHours;
    
    if (ageHours < 1) {
      // Very new - higher risk but higher potential
      score += 0.1;
    } else if (ageHours < 6) {
      // Sweet spot for entry
      score += 0.2;
    } else if (ageHours < 24) {
      // Still good
      score += 0.1;
    } else if (ageHours > 48) {
      // Older token, less explosive potential
      score -= 0.1;
    }

    // Market regime factor
    switch (regime.currentRegime) {
      case 'BULL_LAUNCH_SEASON':
        score += 0.2;
        break;
      case 'NORMAL':
        score += 0;
        break;
      case 'HIGH_RUG_ACTIVITY':
        score -= 0.2;
        break;
      case 'LOW_ACTIVITY':
        score -= 0.1;
        break;
    }

    // Volume momentum
    const volume5mRatio = metrics.volume5m / Math.max(metrics.volume1h / 12, 1);
    if (volume5mRatio > 2) {
      score += 0.1;
    } else if (volume5mRatio < 0.5) {
      score -= 0.1;
    }

    return clamp(score, 0, 1);
  }

  /**
   * Apply market regime adjustment to score
   */
  private applyRegimeAdjustment(score: number, regime: MarketRegime): number {
    const adaptations = regime.adaptations;
    
    // Adjust based on regime aggressiveness
    if (adaptations.rankingAggressiveness > 1) {
      // Boost scores in bull season
      return score * (1 + (adaptations.rankingAggressiveness - 1) * 0.1);
    } else if (adaptations.rankingAggressiveness < 1) {
      // Reduce scores in risky periods
      return score * adaptations.rankingAggressiveness;
    }
    
    return score;
  }

  /**
   * Calculate confidence in the probability estimate
   */
  private calculateConfidence(
    inputs: ProbabilityInputs,
    metrics: TokenMetrics
  ): number {
    let confidence = 0.5;

    // More data points = higher confidence
    const dataQuality = this.assessDataQuality(inputs, metrics);
    confidence += dataQuality * 0.3;

    // Consistency across engines increases confidence
    const consistency = this.assessEngineConsistency(inputs);
    confidence += consistency * 0.2;

    // Token age affects confidence (older = more data)
    if (metrics.ageHours > 24) {
      confidence += 0.1;
    } else if (metrics.ageHours < 1) {
      confidence -= 0.1;
    }

    // Volume indicates data reliability
    if (metrics.volume24h > 100000) {
      confidence += 0.1;
    }

    return clamp(confidence, 0, 1);
  }

  /**
   * Assess data quality for confidence calculation
   */
  private assessDataQuality(
    inputs: ProbabilityInputs,
    metrics: TokenMetrics
  ): number {
    let quality = 0.5;

    // Check if we have all engine outputs
    const hasAllEngines = 
      inputs.risk.score !== undefined &&
      inputs.authenticity.score !== undefined &&
      inputs.developer.score !== undefined &&
      inputs.buyQuality.score !== undefined;

    if (hasAllEngines) {
      quality += 0.3;
    }

    // Whale data is bonus
    if (inputs.whale.detected) {
      quality += 0.1;
    }

    // Transaction count indicates data depth
    const totalTxns = metrics.buys24h + metrics.sells24h;
    if (totalTxns > 1000) {
      quality += 0.1;
    } else if (totalTxns < 100) {
      quality -= 0.1;
    }

    return clamp(quality, 0, 1);
  }

  /**
   * Assess consistency across engine outputs
   */
  private assessEngineConsistency(inputs: ProbabilityInputs): number {
    const scores = [
      1 - inputs.risk.score, // Invert risk
      inputs.authenticity.score,
      inputs.developer.score,
      inputs.buyQuality.score,
    ];

    const mean = scores.reduce((a, b) => a + b, 0) / scores.length;
    const variance = scores.reduce((sum, s) => sum + Math.pow(s - mean, 2), 0) / scores.length;
    const stdDev = Math.sqrt(variance);

    // Lower std dev = higher consistency
    return clamp(1 - stdDev * 2, 0, 1);
  }

  /**
   * Determine probability level
   */
  private determineProbabilityLevel(score: number): ProbabilityAssessment['level'] {
    if (score >= this.config.output.high_probability_threshold) {
      return 'VERY_HIGH';
    }
    if (score >= this.config.output.medium_probability_threshold) {
      return 'HIGH';
    }
    if (score >= this.config.output.low_probability_threshold) {
      return 'MEDIUM';
    }
    return 'LOW';
  }

  /**
   * Calculate timeframe projections
   */
  private calculateTimeframeProjections(
    score: number,
    inputs: ProbabilityInputs
  ): ProbabilityAssessment['timeframe'] {
    // Short term (hours)
    const shortTerm = this.calculateShortTerm(score, inputs);
    
    // Medium term (days)
    const mediumTerm = this.calculateMediumTerm(score, inputs);
    
    // Long term (weeks)
    const longTerm = this.calculateLongTerm(score, inputs);

    return {
      shortTerm,
      mediumTerm,
      longTerm,
    };
  }

  /**
   * Calculate short-term probability (hours)
   */
  private calculateShortTerm(
    score: number,
    inputs: ProbabilityInputs
  ): number {
    // Short term heavily influenced by buy quality and whale activity
    let adjusted = score;

    if (inputs.buyQuality.patterns.hasPumpPattern) {
      adjusted += 0.1;
    }

    if (inputs.whale.detected && inputs.whale.summary.netWhaleFlow > 0) {
      adjusted += 0.1;
    }

    if (inputs.buyQuality.patterns.hasBotActivity) {
      adjusted -= 0.1;
    }

    return clamp(adjusted, 0, 1);
  }

  /**
   * Calculate medium-term probability (days)
   */
  private calculateMediumTerm(
    score: number,
    inputs: ProbabilityInputs
  ): number {
    // Medium term influenced by authenticity and developer reputation
    let adjusted = score;

    if (inputs.authenticity.level === 'EXCELLENT') {
      adjusted += 0.1;
    }

    if (inputs.developer.level === 'EXCELLENT') {
      adjusted += 0.1;
    }

    if (inputs.developer.level === 'SUSPICIOUS' || inputs.developer.level === 'BLACKLIST') {
      adjusted -= 0.2;
    }

    return clamp(adjusted, 0, 1);
  }

  /**
   * Calculate long-term probability (weeks)
   */
  private calculateLongTerm(
    score: number,
    inputs: ProbabilityInputs
  ): number {
    // Long term heavily influenced by fundamentals
    let adjusted = score;

    // Authenticity and developer are key for long-term
    adjusted += (inputs.authenticity.score - 0.5) * 0.2;
    adjusted += (inputs.developer.score - 0.5) * 0.2;

    // Risk becomes more important over time
    adjusted -= inputs.risk.score * 0.1;

    return clamp(adjusted, 0, 1);
  }

  /**
   * Quick probability check for filtering
   */
  public quickCheck(
    metrics: TokenMetrics,
    inputs: ProbabilityInputs
  ): boolean {
    const probability = this.calculate(metrics, inputs);
    return probability.score >= this.config.output.low_probability_threshold;
  }

  /**
   * Compare two probability assessments
   */
  public compare(
    a: ProbabilityAssessment,
    b: ProbabilityAssessment
  ): number {
    // Primary: score
    if (a.score !== b.score) {
      return b.score - a.score;
    }
    
    // Secondary: confidence
    if (a.confidence !== b.confidence) {
      return b.confidence - a.confidence;
    }
    
    // Tertiary: short-term projection
    return b.timeframe.shortTerm - a.timeframe.shortTerm;
  }
}

// Export singleton instance
export const probabilityEngine = new ProbabilityEngine();
