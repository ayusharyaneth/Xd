/**
 * Buy Quality Engine
 * 
 * Analyzes buy quality based on:
 * - Trade size distribution
 * - Buy/sell ratio
 * - Unique buyers growth
 * - Transaction consistency
 */

import { TokenMetrics, BuyQualityAssessment } from '../types';
import { getStrategy } from '../config';
import { Logger } from '../utils/logger';
import { clamp, calculateBuySellRatio } from '../utils/helpers';

const logger = new Logger('BuyQualityEngine');

export interface Trade {
  type: 'BUY' | 'SELL';
  amountUsd: number;
  wallet: string;
  timestamp: number;
}

export interface TradeAnalysis {
  trades: Trade[];
  averageTradeSize: number;
  medianTradeSize: number;
  tradeSizeStdDev: number;
  uniqueWallets: Set<string>;
  whaleTrades: Trade[];
}

export class BuyQualityEngine {
  private config = getStrategy().buy_quality_engine;

  /**
   * Perform comprehensive buy quality assessment
   */
  public assess(
    metrics: TokenMetrics,
    tradeAnalysis?: TradeAnalysis
  ): BuyQualityAssessment {
    logger.debug(`Assessing buy quality for ${metrics.symbol}`);

    const metrics_data = {
      buySellRatio: this.calculateBuySellRatio(metrics),
      uniqueBuyersGrowth: this.assessUniqueBuyersGrowth(metrics, tradeAnalysis),
      tradeSizeDistribution: this.assessTradeSizeDistribution(tradeAnalysis),
      transactionConsistency: this.assessTransactionConsistency(metrics, tradeAnalysis),
    };

    const score = this.calculateWeightedScore(metrics_data);
    const level = this.determineQualityLevel(score);
    const patterns = this.detectPatterns(metrics, tradeAnalysis);

    return {
      score: clamp(score, 0, 1),
      level,
      metrics: metrics_data,
      patterns,
    };
  }

  /**
   * Calculate buy/sell ratio
   */
  private calculateBuySellRatio(metrics: TokenMetrics): number {
    const ratio5m = calculateBuySellRatio(metrics.buys5m, metrics.sells5m);
    const ratio1h = calculateBuySellRatio(metrics.buys1h, metrics.sells1h);
    const ratio24h = calculateBuySellRatio(metrics.buys24h, metrics.sells24h);

    // Weight recent activity more heavily
    return ratio5m * 0.5 + ratio1h * 0.3 + ratio24h * 0.2;
  }

  /**
   * Assess unique buyers growth
   */
  private assessUniqueBuyersGrowth(
    metrics: TokenMetrics,
    tradeAnalysis?: TradeAnalysis
  ): number {
    let score = 0.5;

    // Base score on 1h unique buyers
    const uniqueBuyers1h = tradeAnalysis?.uniqueWallets.size || metrics.buys1h;
    
    if (uniqueBuyers1h >= this.config.indicators.min_unique_buyers_1h * 2) {
      score += 0.3;
    } else if (uniqueBuyers1h >= this.config.indicators.min_unique_buyers_1h) {
      score += 0.15;
    } else if (uniqueBuyers1h < 10) {
      score -= 0.2;
    }

    // Check growth trend
    const recentBuys = metrics.buys5m;
    const olderBuys = (metrics.buys1h - metrics.buys5m) / 11; // per 5min average
    
    if (recentBuys > olderBuys * 2) {
      score += 0.2; // Accelerating growth
    } else if (recentBuys < olderBuys * 0.5) {
      score -= 0.2; // Decelerating growth
    }

    return clamp(score, 0, 1);
  }

  /**
   * Assess trade size distribution
   */
  private assessTradeSizeDistribution(tradeAnalysis?: TradeAnalysis): number {
    if (!tradeAnalysis || tradeAnalysis.trades.length === 0) {
      return 0.5;
    }

    let score = 0.5;

    const { averageTradeSize, medianTradeSize, tradeSizeStdDev } = tradeAnalysis;

    // Good distribution: median close to average (not too skewed)
    const skewness = averageTradeSize / Math.max(medianTradeSize, 1);
    
    if (skewness > 1.5) {
      // Highly skewed - possible whale manipulation
      score -= 0.2;
    } else if (skewness < 1.2) {
      // Well distributed
      score += 0.2;
    }

    // Check whale concentration
    const whaleCount = tradeAnalysis.whaleTrades.length;
    const totalTrades = tradeAnalysis.trades.length;
    const whaleConcentration = whaleCount / Math.max(totalTrades, 1);

    if (whaleConcentration > this.config.indicators.max_whale_concentration) {
      score -= 0.3;
    }

    // Standard deviation indicates distribution spread
    const cv = tradeSizeStdDev / Math.max(averageTradeSize, 1);
    if (cv > 2) {
      score -= 0.1; // Very high variance
    }

    return clamp(score, 0, 1);
  }

  /**
   * Assess transaction consistency
   */
  private assessTransactionConsistency(
    metrics: TokenMetrics,
    tradeAnalysis?: TradeAnalysis
  ): number {
    let score = 0.5;

    // Check for consistent transaction flow
    const txns5m = metrics.buys5m + metrics.sells5m;
    const txns1h = metrics.buys1h + metrics.sells1h;
    const txns24h = metrics.buys24h + metrics.sells24h;

    // Ideal: steady flow across time periods
    const rate5m = txns5m;
    const rate1h = txns1h / 12; // per 5min
    const rate24h = txns24h / 288; // per 5min

    // Check consistency
    const rates = [rate5m, rate1h, rate24h].filter(r => r > 0);
    if (rates.length > 1) {
      const avgRate = rates.reduce((a, b) => a + b, 0) / rates.length;
      const variance = rates.reduce((sum, r) => sum + Math.pow(r - avgRate, 2), 0) / rates.length;
      const consistency = 1 - Math.min(variance / Math.pow(avgRate + 1, 2), 1);
      
      score += consistency * 0.3;
    }

    // Penalty for very low activity
    if (txns24h < 50) {
      score -= 0.2;
    }

    // Bonus for healthy activity
    if (txns24h > 1000) {
      score += 0.1;
    }

    return clamp(score, 0, 1);
  }

  /**
   * Calculate weighted quality score
   */
  private calculateWeightedScore(metrics: BuyQualityAssessment['metrics']): number {
    const weights = this.config.weights;

    // Normalize buy/sell ratio (ideal is around 2-3)
    const normalizedRatio = Math.min(metrics.buySellRatio / 3, 1);

    return (
      normalizedRatio * weights.buy_sell_ratio +
      metrics.uniqueBuyersGrowth * weights.unique_buyers_growth +
      metrics.tradeSizeDistribution * weights.trade_size_distribution +
      metrics.transactionConsistency * weights.transaction_consistency
    );
  }

  /**
   * Determine quality level
   */
  private determineQualityLevel(score: number): BuyQualityAssessment['level'] {
    if (score >= this.config.thresholds.excellent_quality) {
      return 'EXCELLENT';
    }
    if (score >= this.config.thresholds.good_quality) {
      return 'GOOD';
    }
    if (score >= this.config.thresholds.poor_quality) {
      return 'FAIR';
    }
    return 'POOR';
  }

  /**
   * Detect trading patterns
   */
  private detectPatterns(
    metrics: TokenMetrics,
    tradeAnalysis?: TradeAnalysis
  ): BuyQualityAssessment['patterns'] {
    return {
      hasOrganicGrowth: this.detectOrganicGrowth(metrics, tradeAnalysis),
      hasWhaleAccumulation: this.detectWhaleAccumulation(tradeAnalysis),
      hasBotActivity: this.detectBotActivity(metrics, tradeAnalysis),
      hasPumpPattern: this.detectPumpPattern(metrics),
    };
  }

  /**
   * Detect organic growth pattern
   */
  private detectOrganicGrowth(
    metrics: TokenMetrics,
    tradeAnalysis?: TradeAnalysis
  ): boolean {
    // Organic growth: steady increase in unique buyers, healthy buy/sell ratio
    const healthyRatio = metrics.buys1h / Math.max(metrics.sells1h, 1) > 1.2;
    const growingUnique = tradeAnalysis ? tradeAnalysis.uniqueWallets.size > 50 : metrics.buys1h > 50;
    const consistentVolume = metrics.volume5m > metrics.volume1h / 12 * 0.5;

    return healthyRatio && growingUnique && consistentVolume;
  }

  /**
   * Detect whale accumulation pattern
   */
  private detectWhaleAccumulation(tradeAnalysis?: TradeAnalysis): boolean {
    if (!tradeAnalysis || tradeAnalysis.whaleTrades.length === 0) {
      return false;
    }

    const whaleBuys = tradeAnalysis.whaleTrades.filter(t => t.type === 'BUY').length;
    const whaleSells = tradeAnalysis.whaleTrades.filter(t => t.type === 'SELL').length;

    return whaleBuys > whaleSells * 2;
  }

  /**
   * Detect bot activity pattern
   */
  private detectBotActivity(
    metrics: TokenMetrics,
    tradeAnalysis?: TradeAnalysis
  ): boolean {
    // Bot indicators: very regular intervals, similar trade sizes, high frequency
    if (!tradeAnalysis || tradeAnalysis.trades.length < 20) {
      return false;
    }

    const trades = tradeAnalysis.trades;
    
    // Check for similar trade sizes (bot pattern)
    const sizes = trades.map(t => t.amountUsd);
    const uniqueSizes = new Set(sizes.map(s => Math.round(s))).size;
    const sizeSimilarity = uniqueSizes / sizes.length;

    // Check for rapid fire trading
    const timestamps = trades.map(t => t.timestamp).sort((a, b) => a - b);
    const intervals: number[] = [];
    for (let i = 1; i < timestamps.length; i++) {
      intervals.push(timestamps[i] - timestamps[i - 1]);
    }
    const avgInterval = intervals.reduce((a, b) => a + b, 0) / intervals.length;

    return sizeSimilarity < 0.3 && avgInterval < 5000; // Very similar sizes, very fast
  }

  /**
   * Detect pump pattern
   */
  private detectPumpPattern(metrics: TokenMetrics): boolean {
    // Pump indicators: rapid price increase, volume spike, high buy ratio
    const rapidPriceIncrease = metrics.priceChange5m > 0.2 || metrics.priceChange1h > 0.5;
    const volumeSpike = metrics.volume5m > metrics.volume1h / 12 * 3;
    const highBuyRatio = metrics.buys5m > Math.max(metrics.sells5m * 3, 1);

    return rapidPriceIncrease && volumeSpike && highBuyRatio;
  }

  /**
   * Analyze trades from raw data
   */
  public analyzeTrades(trades: Trade[]): TradeAnalysis {
    if (trades.length === 0) {
      return {
        trades: [],
        averageTradeSize: 0,
        medianTradeSize: 0,
        tradeSizeStdDev: 0,
        uniqueWallets: new Set(),
        whaleTrades: [],
      };
    }

    const amounts = trades.map(t => t.amountUsd);
    const sorted = [...amounts].sort((a, b) => a - b);
    
    const averageTradeSize = amounts.reduce((a, b) => a + b, 0) / amounts.length;
    const medianTradeSize = sorted[Math.floor(sorted.length / 2)];
    
    const variance = amounts.reduce((sum, a) => sum + Math.pow(a - averageTradeSize, 2), 0) / amounts.length;
    const tradeSizeStdDev = Math.sqrt(variance);

    const uniqueWallets = new Set(trades.map(t => t.wallet));
    
    const whaleThreshold = 10000; // $10k
    const whaleTrades = trades.filter(t => t.amountUsd >= whaleThreshold);

    return {
      trades,
      averageTradeSize,
      medianTradeSize,
      tradeSizeStdDev,
      uniqueWallets,
      whaleTrades,
    };
  }

  /**
   * Quick quality check for filtering
   */
  public quickCheck(metrics: TokenMetrics): boolean {
    const quality = this.assess(metrics);
    return quality.score >= this.config.thresholds.poor_quality;
  }
}

// Export singleton instance
export const buyQualityEngine = new BuyQualityEngine();
