/**
 * Authenticity Engine
 * 
 * Evaluates token authenticity based on:
 * - Liquidity locking status
 * - Contract verification
 * - Social media presence
 * - Website quality
 * - Team doxxing
 */

import { TokenMetrics, AuthenticityAssessment, DexScreenerToken } from '../types';
import { getStrategy } from '../config';
import { Logger } from '../utils/logger';
import { clamp } from '../utils/helpers';

const logger = new Logger('AuthenticityEngine');

export interface SocialMetrics {
  twitter?: {
    followers: number;
    verified: boolean;
    activityScore: number;
  };
  telegram?: {
    members: number;
    activityScore: number;
  };
  discord?: {
    members: number;
    activityScore: number;
  };
}

export interface WebsiteAnalysis {
  hasWebsite: boolean;
  sections: string[];
  qualityScore: number;
  hasWhitepaper: boolean;
  hasRoadmap: boolean;
  hasTeamInfo: boolean;
}

export class AuthenticityEngine {
  private config = getStrategy().authenticity_engine;

  /**
   * Perform comprehensive authenticity assessment
   */
  public assess(
    metrics: TokenMetrics,
    tokenInfo?: DexScreenerToken['info'],
    socialMetrics?: SocialMetrics,
    websiteAnalysis?: WebsiteAnalysis,
    liquidityLocked?: { locked: boolean; durationDays: number; percentage: number }
  ): AuthenticityAssessment {
    logger.debug(`Assessing authenticity for ${metrics.symbol}`);

    const factors = {
      liquidityLocked: this.assessLiquidityLock(liquidityLocked),
      contractVerified: this.assessContractVerification(metrics),
      socialPresence: this.assessSocialPresence(tokenInfo, socialMetrics),
      websiteQuality: this.assessWebsiteQuality(tokenInfo, websiteAnalysis),
      teamDoxxed: this.assessTeamDoxxing(websiteAnalysis),
    };

    const score = this.calculateWeightedScore(factors);
    const level = this.determineAuthenticityLevel(score);
    const checks = this.generateChecks(liquidityLocked, tokenInfo, websiteAnalysis);

    return {
      score: clamp(score, 0, 1),
      level,
      factors,
      checks,
    };
  }

  /**
   * Assess liquidity locking status
   */
  private assessLiquidityLock(
    liquidityLocked?: { locked: boolean; durationDays: number; percentage: number }
  ): number {
    if (!liquidityLocked) {
      return 0.3; // Unknown
    }

    if (!liquidityLocked.locked) {
      return 0.1; // Not locked - high risk
    }

    let score = 0.5;

    // Bonus for lock duration
    if (liquidityLocked.durationDays >= 365) {
      score += 0.3;
    } else if (liquidityLocked.durationDays >= 180) {
      score += 0.2;
    } else if (liquidityLocked.durationDays >= 90) {
      score += 0.1;
    }

    // Bonus for high lock percentage
    if (liquidityLocked.percentage >= 0.95) {
      score += 0.2;
    } else if (liquidityLocked.percentage >= 0.8) {
      score += 0.1;
    }

    return clamp(score, 0, 1);
  }

  /**
   * Assess contract verification
   */
  private assessContractVerification(metrics: TokenMetrics): number {
    // This would require on-chain verification
    // For now, use heuristics

    let score = 0.5;

    // Higher score for tokens with more transaction history
    const totalTxns = metrics.buys24h + metrics.sells24h;
    if (totalTxns > 1000) {
      score += 0.2;
    } else if (totalTxns > 500) {
      score += 0.1;
    }

    // Higher score for established tokens
    if (metrics.ageHours > 24) {
      score += 0.2;
    } else if (metrics.ageHours > 6) {
      score += 0.1;
    }

    // Lower score for very new, low-volume tokens
    if (metrics.ageMinutes < 30 && totalTxns < 100) {
      score -= 0.2;
    }

    return clamp(score, 0, 1);
  }

  /**
   * Assess social media presence
   */
  private assessSocialPresence(
    tokenInfo?: DexScreenerToken['info'],
    socialMetrics?: SocialMetrics
  ): number {
    let score = 0.3;

    // Check for social links in token info
    const socials = tokenInfo?.socials || [];
    const hasTwitter = socials.some(s => s.type === 'twitter' || s.url.includes('twitter.com'));
    const hasTelegram = socials.some(s => s.type === 'telegram' || s.url.includes('t.me'));
    const hasDiscord = socials.some(s => s.type === 'discord' || s.url.includes('discord'));

    if (hasTwitter) score += 0.15;
    if (hasTelegram) score += 0.1;
    if (hasDiscord) score += 0.1;

    // Evaluate social metrics if available
    if (socialMetrics) {
      if (socialMetrics.twitter) {
        if (socialMetrics.twitter.followers >= 10000) {
          score += 0.15;
        } else if (socialMetrics.twitter.followers >= 1000) {
          score += 0.1;
        }

        if (socialMetrics.twitter.verified) {
          score += 0.1;
        }

        score += socialMetrics.twitter.activityScore * 0.1;
      }

      if (socialMetrics.telegram) {
        if (socialMetrics.telegram.members >= 5000) {
          score += 0.1;
        } else if (socialMetrics.telegram.members >= 1000) {
          score += 0.05;
        }
      }
    }

    return clamp(score, 0, 1);
  }

  /**
   * Assess website quality
   */
  private assessWebsiteQuality(
    tokenInfo?: DexScreenerToken['info'],
    websiteAnalysis?: WebsiteAnalysis
  ): number {
    let score = 0.2;

    // Check for website in token info
    const websites = tokenInfo?.websites || [];
    const hasWebsite = websites.length > 0;

    if (hasWebsite) {
      score += 0.2;
    }

    // Evaluate website analysis if available
    if (websiteAnalysis) {
      if (websiteAnalysis.hasWebsite) {
        score += 0.1;
      }

      // Quality based on sections
      const sectionCount = websiteAnalysis.sections.length;
      if (sectionCount >= 5) {
        score += 0.2;
      } else if (sectionCount >= 3) {
        score += 0.1;
      }

      // Bonus for important sections
      if (websiteAnalysis.hasWhitepaper) score += 0.1;
      if (websiteAnalysis.hasRoadmap) score += 0.1;
      if (websiteAnalysis.hasTeamInfo) score += 0.1;

      // Quality score
      score += websiteAnalysis.qualityScore * 0.2;
    }

    return clamp(score, 0, 1);
  }

  /**
   * Assess team doxxing
   */
  private assessTeamDoxxing(websiteAnalysis?: WebsiteAnalysis): number {
    if (!websiteAnalysis) {
      return 0.3;
    }

    let score = 0.2;

    if (websiteAnalysis.hasTeamInfo) {
      score += 0.4;
    }

    // Check for detailed team section
    const hasDetailedTeam = websiteAnalysis.sections.some(s => 
      s.toLowerCase().includes('team') || 
      s.toLowerCase().includes('about')
    );

    if (hasDetailedTeam) {
      score += 0.2;
    }

    // LinkedIn profiles would add more score
    const hasLinkedIn = websiteAnalysis.sections.some(s =>
      s.toLowerCase().includes('linkedin')
    );

    if (hasLinkedIn) {
      score += 0.2;
    }

    return clamp(score, 0, 1);
  }

  /**
   * Calculate weighted authenticity score
   */
  private calculateWeightedScore(factors: AuthenticityAssessment['factors']): number {
    const weights = this.config.weights;

    return (
      factors.liquidityLocked * weights.liquidity_locked +
      factors.contractVerified * weights.contract_verified +
      factors.socialPresence * weights.social_presence +
      factors.websiteQuality * weights.website_quality +
      factors.teamDoxxed * weights.team_doxxed
    );
  }

  /**
   * Determine authenticity level
   */
  private determineAuthenticityLevel(score: number): AuthenticityAssessment['level'] {
    if (score >= this.config.thresholds.high_authenticity) {
      return 'EXCELLENT';
    }
    if (score >= this.config.thresholds.medium_authenticity) {
      return 'HIGH';
    }
    if (score >= this.config.thresholds.low_authenticity) {
      return 'MEDIUM';
    }
    return 'LOW';
  }

  /**
   * Generate check results
   */
  private generateChecks(
    liquidityLocked?: { locked: boolean; durationDays: number; percentage: number },
    tokenInfo?: DexScreenerToken['info'],
    websiteAnalysis?: WebsiteAnalysis
  ): AuthenticityAssessment['checks'] {
    const socials = tokenInfo?.socials || [];
    const hasTwitter = socials.some(s => s.type === 'twitter' || s.url.includes('twitter.com'));
    const websites = tokenInfo?.websites || [];

    return {
      hasLockedLiquidity: liquidityLocked?.locked || false,
      isContractVerified: true, // Placeholder - would need on-chain check
      hasSocialLinks: hasTwitter || socials.length > 0,
      hasWebsite: websites.length > 0 || (websiteAnalysis?.hasWebsite || false),
      lockDurationDays: liquidityLocked?.durationDays || 0,
    };
  }

  /**
   * Quick authenticity check for filtering
   */
  public quickCheck(
    metrics: TokenMetrics,
    tokenInfo?: DexScreenerToken['info']
  ): boolean {
    const assessment = this.assess(metrics, tokenInfo);
    return assessment.score >= this.config.thresholds.low_authenticity;
  }
}

// Export singleton instance
export const authenticityEngine = new AuthenticityEngine();
