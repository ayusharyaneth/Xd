/**
 * Developer Reputation Engine
 * 
 * Analyzes developer history and reputation based on:
 * - Previous project success rate
 * - Rug pull history
 * - Project longevity
 * - Community engagement
 */

import { DeveloperReputation, TokenMetrics } from '../types';
import { getStrategy } from '../config';
import { Logger } from '../utils/logger';
import { clamp } from '../utils/helpers';

const logger = new Logger('DeveloperEngine');

export interface DeveloperProject {
  tokenAddress: string;
  name: string;
  symbol: string;
  launchDate: number;
  endDate?: number;
  status: 'ACTIVE' | 'RUGGED' | 'ABANDONED' | 'SUCCESSFUL';
  peakMarketCap: number;
  currentMarketCap?: number;
  communityScore: number;
}

export interface DeveloperHistory {
  developerAddress: string;
  projects: DeveloperProject[];
  totalProjects: number;
  successfulProjects: number;
  ruggedProjects: number;
  abandonedProjects: number;
  averageProjectLifespanDays: number;
  communityEngagementScore: number;
}

export class DeveloperEngine {
  private config = getStrategy().developer_engine;
  private historyCache: Map<string, DeveloperHistory> = new Map();

  /**
   * Assess developer reputation
   */
  public assess(
    metrics: TokenMetrics,
    developerAddress?: string,
    history?: DeveloperHistory
  ): DeveloperReputation {
    logger.debug(`Assessing developer reputation for ${metrics.symbol}`);

    // If no history provided, try to fetch or use heuristics
    if (!history && developerAddress) {
      history = this.getCachedHistory(developerAddress);
    }

    if (!history) {
      return this.assessFromHeuristics(metrics);
    }

    const score = this.calculateReputationScore(history);
    const level = this.determineReputationLevel(score, history);
    const flags = this.generateFlags(history);

    return {
      score: clamp(score, 0, 1),
      level,
      history: {
        totalProjects: history.totalProjects,
        successfulProjects: history.successfulProjects,
        rugPulls: history.ruggedProjects,
        averageProjectLifespanDays: history.averageProjectLifespanDays,
      },
      flags,
    };
  }

  /**
   * Assess from heuristics when no history available
   */
  private assessFromHeuristics(metrics: TokenMetrics): DeveloperReputation {
    let score = 0.5;
    const flags: string[] = [];

    // New tokens get lower initial score
    if (metrics.ageHours < 1) {
      score -= 0.1;
      flags.push('Very new project - limited history');
    }

    // Check for suspicious patterns
    const buySellRatio = metrics.buys24h / Math.max(metrics.sells24h, 1);
    if (buySellRatio > 20) {
      score -= 0.1;
      flags.push('Unusual buy/sell ratio');
    }

    // Low initial liquidity is suspicious
    if (metrics.liquidityUsd < 10000) {
      score -= 0.1;
      flags.push('Low initial liquidity');
    }

    // Good volume and holders increase score
    if (metrics.volume24h > 100000) {
      score += 0.1;
    }

    const totalHolders = metrics.buys24h + metrics.sells24h;
    if (totalHolders > 500) {
      score += 0.1;
    }

    return {
      score: clamp(score, 0, 1),
      level: 'UNKNOWN',
      history: {
        totalProjects: 0,
        successfulProjects: 0,
        rugPulls: 0,
        averageProjectLifespanDays: 0,
      },
      flags,
    };
  }

  /**
   * Calculate reputation score from history
   */
  private calculateReputationScore(history: DeveloperHistory): number {
    const weights = this.config.weights;
    let score = 0.5;

    // Success rate factor
    if (history.totalProjects >= this.config.historical_analysis.min_projects_to_analyze) {
      const successRate = history.successfulProjects / history.totalProjects;
      score += successRate * weights.previous_success_rate;
    }

    // Rug history factor (penalty)
    if (history.totalProjects > 0) {
      const rugRate = history.ruggedProjects / history.totalProjects;
      score -= rugRate * weights.rug_history * 2; // Double penalty for rugs
    }

    // Project longevity factor
    if (history.averageProjectLifespanDays > 30) {
      score += 0.1 * weights.project_longevity;
    } else if (history.averageProjectLifespanDays < 7 && history.totalProjects > 2) {
      score -= 0.1 * weights.project_longevity;
    }

    // Community engagement factor
    score += history.communityEngagementScore * weights.community_engagement;

    return clamp(score, 0, 1);
  }

  /**
   * Determine reputation level
   */
  private determineReputationLevel(
    score: number, 
    history: DeveloperHistory
  ): DeveloperReputation['level'] {
    // Check for blacklisting conditions
    if (history.ruggedProjects >= 3) {
      return 'BLACKLIST';
    }

    if (history.totalProjects >= 3) {
      const rugRate = history.ruggedProjects / history.totalProjects;
      if (rugRate > 0.5) {
        return 'BLACKLIST';
      }
    }

    if (score <= this.config.thresholds.blacklist_reputation) {
      return 'BLACKLIST';
    }

    if (score <= this.config.thresholds.suspicious_reputation) {
      return 'SUSPICIOUS';
    }

    if (score >= this.config.thresholds.excellent_reputation) {
      return 'EXCELLENT';
    }

    if (score >= this.config.thresholds.good_reputation) {
      return 'GOOD';
    }

    return 'UNKNOWN';
  }

  /**
   * Generate warning flags
   */
  private generateFlags(history: DeveloperHistory): string[] {
    const flags: string[] = [];

    if (history.ruggedProjects > 0) {
      flags.push(`Has ${history.ruggedProjects} rug pull(s) in history`);
    }

    if (history.abandonedProjects > 2) {
      flags.push(`Has ${history.abandonedProjects} abandoned project(s)`);
    }

    if (history.averageProjectLifespanDays < 14 && history.totalProjects > 2) {
      flags.push('Short average project lifespan');
    }

    if (history.totalProjects > 10) {
      flags.push('High project frequency - potential serial launcher');
    }

    if (history.communityEngagementScore < 0.3) {
      flags.push('Low community engagement in past projects');
    }

    return flags;
  }

  /**
   * Cache developer history
   */
  public cacheHistory(history: DeveloperHistory): void {
    this.historyCache.set(history.developerAddress, history);
    logger.debug(`Cached history for developer: ${history.developerAddress}`);
  }

  /**
   * Get cached history
   */
  public getCachedHistory(developerAddress: string): DeveloperHistory | undefined {
    return this.historyCache.get(developerAddress);
  }

  /**
   * Clear history cache
   */
  public clearCache(): void {
    this.historyCache.clear();
    logger.info('Developer history cache cleared');
  }

  /**
   * Analyze project status based on metrics
   */
  public analyzeProjectStatus(
    launchDate: number,
    metrics: TokenMetrics
  ): DeveloperProject['status'] {
    const ageDays = (Date.now() - launchDate) / (1000 * 60 * 60 * 24);

    // Check for rug indicators
    if (metrics.liquidityUsd < 1000 && metrics.volume24h < 100) {
      return 'RUGGED';
    }

    // Check for abandonment
    if (ageDays > 30 && metrics.volume24h < 1000 && metrics.priceChange24h < -0.9) {
      return 'ABANDONED';
    }

    // Check for success
    if (metrics.marketCap > 1000000 && metrics.volume24h > 50000) {
      return 'SUCCESSFUL';
    }

    return 'ACTIVE';
  }

  /**
   * Quick reputation check for filtering
   */
  public quickCheck(
    metrics: TokenMetrics,
    developerAddress?: string
  ): boolean {
    const reputation = this.assess(metrics, developerAddress);
    return reputation.level !== 'BLACKLIST' && reputation.level !== 'SUSPICIOUS';
  }
}

// Export singleton instance
export const developerEngine = new DeveloperEngine();
