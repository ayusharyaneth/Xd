/**
 * Exit Assistant Engine
 * 
 * Detects exit conditions based on:
 * - Liquidity drop percentage
 * - Whale exit detection
 * - Creator selling signals
 * - Volume decay
 * - Rising rug probability
 */

import { TokenMetrics, ExitSignal, RiskAssessment, WhaleActivity } from '../types';
import { getStrategy } from '../config';
import { Logger } from '../utils/logger';
import { clamp } from '../utils/helpers';

const logger = new Logger('ExitEngine');

export interface ExitContext {
  entryPrice?: number;
  highestPriceSinceEntry?: number;
  currentProfit?: number;
  initialLiquidity?: number;
  initialVolume24h?: number;
  creatorWallet?: string;
}

export class ExitEngine {
  private config = getStrategy().exit_assistant;
  private cooldowns: Map<string, number> = new Map();

  /**
   * Analyze exit conditions
   */
  public analyze(
    metrics: TokenMetrics,
    risk: RiskAssessment,
    whale: WhaleActivity,
    context?: ExitContext
  ): ExitSignal {
    logger.debug(`Analyzing exit conditions for ${metrics.symbol}`);

    // Check cooldown
    if (this.isInCooldown(metrics.address)) {
      return this.createNoExitSignal();
    }

    const triggers = {
      liquidityDrop: this.detectLiquidityDrop(metrics, context),
      whaleExit: this.detectWhaleExit(whale),
      creatorSelling: this.detectCreatorSelling(metrics, context),
      volumeDecay: this.detectVolumeDecay(metrics, context),
      rugProbability: this.detectRugProbability(risk),
    };

    const shouldExit = Object.values(triggers).some(t => t);
    
    if (!shouldExit) {
      return this.createNoExitSignal();
    }

    const urgency = this.determineUrgency(triggers, risk, context);
    const reasons = this.generateExitReasons(triggers);
    const metrics_data = this.calculateExitMetrics(metrics, context, triggers);
    const recommendedAction = this.determineRecommendedAction(urgency, triggers);

    // Record cooldown
    this.recordCooldown(metrics.address);

    return {
      shouldExit: true,
      urgency,
      reasons,
      triggers,
      metrics: metrics_data,
      recommendedAction,
    };
  }

  /**
   * Detect significant liquidity drop
   */
  private detectLiquidityDrop(
    metrics: TokenMetrics,
    context?: ExitContext
  ): boolean {
    if (!context?.initialLiquidity) {
      // No baseline, use relative check
      return false;
    }

    const dropPercent = (context.initialLiquidity - metrics.liquidityUsd) / context.initialLiquidity;
    return dropPercent >= this.config.triggers.liquidity_drop_percentage;
  }

  /**
   * Detect whale exit
   */
  private detectWhaleExit(whale: WhaleActivity): boolean {
    if (!whale.detected) {
      return false;
    }

    // Significant net outflow
    if (whale.summary.netWhaleFlow < -50000) {
      return true;
    }

    // More sells than buys from whales
    if (whale.summary.totalWhaleSells > whale.summary.totalWhaleBuys * 2) {
      return true;
    }

    return false;
  }

  /**
   * Detect creator selling
   */
  private detectCreatorSelling(
    metrics: TokenMetrics,
    context?: ExitContext
  ): boolean {
    if (!context?.creatorWallet) {
      return false;
    }

    // This would require on-chain analysis
    // Placeholder implementation
    return false;
  }

  /**
   * Detect volume decay
   */
  private detectVolumeDecay(
    metrics: TokenMetrics,
    context?: ExitContext
  ): boolean {
    if (!context?.initialVolume24h) {
      return false;
    }

    const decayPercent = (context.initialVolume24h - metrics.volume24h) / context.initialVolume24h;
    return decayPercent >= this.config.triggers.volume_decay_percentage;
  }

  /**
   * Detect rising rug probability
   */
  private detectRugProbability(risk: RiskAssessment): boolean {
    return risk.score >= this.config.triggers.rug_probability_threshold;
  }

  /**
   * Determine exit urgency
   */
  private determineUrgency(
    triggers: ExitSignal['triggers'],
    risk: RiskAssessment,
    context?: ExitContext
  ): ExitSignal['urgency'] {
    let urgencyScore = 0;

    // Rug probability is highest urgency
    if (triggers.rugProbability) {
      urgencyScore += 3;
    }

    // Liquidity drop is high urgency
    if (triggers.liquidityDrop) {
      urgencyScore += 2;
    }

    // Whale exit is medium-high urgency
    if (triggers.whaleExit) {
      urgencyScore += 2;
    }

    // Creator selling is high urgency
    if (triggers.creatorSelling) {
      urgencyScore += 3;
    }

    // Volume decay is medium urgency
    if (triggers.volumeDecay) {
      urgencyScore += 1;
    }

    // Consider current profit/loss
    if (context?.currentProfit !== undefined) {
      if (context.currentProfit < -this.config.thresholds.max_loss_before_force_exit) {
        urgencyScore += 2;
      }
    }

    // Map score to urgency level
    if (urgencyScore >= 5) {
      return 'IMMEDIATE';
    }
    if (urgencyScore >= 3) {
      return 'HIGH';
    }
    if (urgencyScore >= 2) {
      return 'MEDIUM';
    }
    return 'LOW';
  }

  /**
   * Generate exit reasons
   */
  private generateExitReasons(triggers: ExitSignal['triggers']): string[] {
    const reasons: string[] = [];

    if (triggers.rugProbability) {
      reasons.push('High rug pull probability detected');
    }

    if (triggers.liquidityDrop) {
      reasons.push('Significant liquidity withdrawal');
    }

    if (triggers.whaleExit) {
      reasons.push('Major whale exit detected');
    }

    if (triggers.creatorSelling) {
      reasons.push('Creator wallet selling');
    }

    if (triggers.volumeDecay) {
      reasons.push('Volume decay indicating loss of interest');
    }

    return reasons;
  }

  /**
   * Calculate exit metrics
   */
  private calculateExitMetrics(
    metrics: TokenMetrics,
    context?: ExitContext,
    triggers?: ExitSignal['triggers']
  ): ExitSignal['metrics'] {
    const liquidityDropPercent = context?.initialLiquidity
      ? (context.initialLiquidity - metrics.liquidityUsd) / context.initialLiquidity
      : 0;

    const volumeDecayPercent = context?.initialVolume24h
      ? (context.initialVolume24h - metrics.volume24h) / context.initialVolume24h
      : 0;

    // Estimate rug probability based on triggers
    let rugProbabilityScore = 0;
    if (triggers?.rugProbability) rugProbabilityScore += 0.5;
    if (triggers?.liquidityDrop) rugProbabilityScore += 0.2;
    if (triggers?.creatorSelling) rugProbabilityScore += 0.2;
    if (triggers?.whaleExit) rugProbabilityScore += 0.1;

    // Estimate loss if exit not taken
    const estimatedLossPercent = rugProbabilityScore > 0.5 ? -0.5 : -0.2;

    return {
      liquidityDropPercent,
      volumeDecayPercent,
      rugProbabilityScore: clamp(rugProbabilityScore, 0, 1),
      estimatedLossPercent,
    };
  }

  /**
   * Determine recommended action
   */
  private determineRecommendedAction(
    urgency: ExitSignal['urgency'],
    triggers: ExitSignal['triggers']
  ): string {
    switch (urgency) {
      case 'IMMEDIATE':
        return 'SELL IMMEDIATELY - Critical risk detected';
      
      case 'HIGH':
        if (triggers.rugProbability) {
          return 'URGENT EXIT - High probability of rug pull';
        }
        return 'STRONG CONSIDERATION - Multiple exit signals present';
      
      case 'MEDIUM':
        return 'CONSIDER EXIT - Monitor closely and prepare to exit';
      
      case 'LOW':
        return 'WATCH CLOSELY - Early warning signs detected';
      
      default:
        return 'HOLD - No immediate action required';
    }
  }

  /**
   * Check if exit signal is in cooldown
   */
  private isInCooldown(tokenAddress: string): boolean {
    const lastAlert = this.cooldowns.get(tokenAddress);
    if (!lastAlert) return false;

    const cooldownMs = this.config.cooldown_seconds * 1000;
    return Date.now() - lastAlert < cooldownMs;
  }

  /**
   * Record exit cooldown
   */
  private recordCooldown(tokenAddress: string): void {
    this.cooldowns.set(tokenAddress, Date.now());
  }

  /**
   * Create no-exit signal
   */
  private createNoExitSignal(): ExitSignal {
    return {
      shouldExit: false,
      urgency: 'LOW',
      reasons: [],
      triggers: {
        liquidityDrop: false,
        whaleExit: false,
        creatorSelling: false,
        volumeDecay: false,
        rugProbability: false,
      },
      metrics: {
        liquidityDropPercent: 0,
        volumeDecayPercent: 0,
        rugProbabilityScore: 0,
        estimatedLossPercent: 0,
      },
      recommendedAction: 'HOLD - No exit signals detected',
    };
  }

  /**
   * Calculate trailing stop exit
   */
  public checkTrailingStop(
    currentPrice: number,
    highestPrice: number,
    entryPrice?: number
  ): { triggered: boolean; drawdownPercent: number } {
    const drawdownPercent = (highestPrice - currentPrice) / highestPrice;
    const threshold = this.config.thresholds.trailing_stop_percentage;

    return {
      triggered: drawdownPercent >= threshold,
      drawdownPercent,
    };
  }

  /**
   * Check profit target
   */
  public checkProfitTarget(
    currentProfit: number
  ): { triggered: boolean; message: string } {
    const target = this.config.thresholds.min_profit_to_consider_exit;
    
    return {
      triggered: currentProfit >= target,
      message: currentProfit >= target 
        ? `Profit target reached: ${(currentProfit * 100).toFixed(1)}%`
        : 'Profit target not yet reached',
    };
  }

  /**
   * Check stop loss
   */
  public checkStopLoss(
    currentProfit: number
  ): { triggered: boolean; message: string } {
    const maxLoss = this.config.thresholds.max_loss_before_force_exit;
    
    return {
      triggered: currentProfit <= -maxLoss,
      message: currentProfit <= -maxLoss
        ? `Stop loss triggered: ${(currentProfit * 100).toFixed(1)}%`
        : 'Within acceptable loss range',
    };
  }

  /**
   * Cleanup old cooldowns
   */
  public cleanup(): void {
    const cooldownMs = this.config.cooldown_seconds * 1000 * 2;
    const now = Date.now();
    
    for (const [address, timestamp] of this.cooldowns.entries()) {
      if (now - timestamp > cooldownMs) {
        this.cooldowns.delete(address);
      }
    }
  }
}

// Export singleton instance
export const exitEngine = new ExitEngine();
