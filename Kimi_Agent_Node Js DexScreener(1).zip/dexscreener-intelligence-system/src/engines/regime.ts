/**
 * Market Regime Analyzer
 * 
 * Tracks market conditions and classifies regime:
 * - BULL_LAUNCH_SEASON
 * - NORMAL
 * - HIGH_RUG_ACTIVITY
 * - LOW_ACTIVITY
 * 
 * Dynamically adjusts system parameters
 */

import { MarketRegime, MarketRegimeType, TokenAlert } from '../types';
import { getStrategy } from '../config';
import { Logger } from '../utils/logger';
import { clamp, calculateSMA } from '../utils/helpers';

const logger = new Logger('RegimeAnalyzer');

export interface MarketMetrics {
  timestamp: number;
  rugCount: number;
  totalTokens: number;
  survivalTimes: number[];
  launchCount: number;
  authenticityScores: number[];
  whaleParticipation: number[];
  volumeUsd: number;
}

export class RegimeAnalyzer {
  private config = getStrategy().market_regime;
  private metricsHistory: MarketMetrics[] = [];
  private currentRegime: MarketRegime;
  private regimeSince: number;

  constructor() {
    this.currentRegime = this.createDefaultRegime();
    this.regimeSince = Date.now();
  }

  /**
   * Analyze current market conditions and update regime
   */
  public analyze(alerts: TokenAlert[]): MarketRegime {
    logger.debug('Analyzing market regime');

    // Collect metrics from recent alerts
    const metrics = this.collectMetrics(alerts);
    this.metricsHistory.push(metrics);

    // Keep only last 24 hours of data
    this.pruneOldMetrics();

    // Calculate aggregate metrics
    const aggregate = this.calculateAggregateMetrics();

    // Classify regime
    const newRegime = this.classifyRegime(aggregate);

    // Check for regime change
    if (newRegime !== this.currentRegime.currentRegime) {
      logger.info(`Market regime changed: ${this.currentRegime.currentRegime} -> ${newRegime}`);
      this.regimeSince = Date.now();
    }

    // Calculate adaptations
    const adaptations = this.calculateAdaptations(newRegime);

    this.currentRegime = {
      currentRegime: newRegime,
      confidence: aggregate.confidence,
      metrics: aggregate,
      adaptations,
      since: this.regimeSince,
    };

    return this.currentRegime;
  }

  /**
   * Collect metrics from alerts
   */
  private collectMetrics(alerts: TokenAlert[]): MarketMetrics {
    const rugCount = alerts.filter(a => a.risk.level === 'CRITICAL').length;
    const authenticityScores = alerts.map(a => a.authenticity.score);
    const whaleParticipation = alerts.filter(a => a.whale.detected).length / Math.max(alerts.length, 1);

    return {
      timestamp: Date.now(),
      rugCount,
      totalTokens: alerts.length,
      survivalTimes: [], // Would need historical tracking
      launchCount: alerts.length,
      authenticityScores,
      whaleParticipation: [whaleParticipation],
      volumeUsd: alerts.reduce((sum, a) => sum + a.token.volume24h, 0),
    };
  }

  /**
   * Prune metrics older than 24 hours
   */
  private pruneOldMetrics(): void {
    const cutoff = Date.now() - 24 * 60 * 60 * 1000;
    this.metricsHistory = this.metricsHistory.filter(m => m.timestamp >= cutoff);
  }

  /**
   * Calculate aggregate metrics
   */
  private calculateAggregateMetrics(): MarketRegime['metrics'] & { confidence: number } {
    if (this.metricsHistory.length === 0) {
      return {
        rugRate24h: 0,
        averageSurvivalTimeHours: 24,
        launchFrequency: 0,
        averageAuthenticity: 0.5,
        whaleParticipationRate: 0.5,
        confidence: 0.5,
      };
    }

    const totalTokens = this.metricsHistory.reduce((sum, m) => sum + m.totalTokens, 0);
    const totalRugs = this.metricsHistory.reduce((sum, m) => sum + m.rugCount, 0);
    const rugRate24h = totalTokens > 0 ? totalRugs / totalTokens : 0;

    const allAuthenticity = this.metricsHistory.flatMap(m => m.authenticityScores);
    const averageAuthenticity = allAuthenticity.length > 0
      ? allAuthenticity.reduce((a, b) => a + b, 0) / allAuthenticity.length
      : 0.5;

    const allWhaleParticipation = this.metricsHistory.flatMap(m => m.whaleParticipation);
    const whaleParticipationRate = allWhaleParticipation.length > 0
      ? allWhaleParticipation.reduce((a, b) => a + b, 0) / allWhaleParticipation.length
      : 0.5;

    const launchFrequency = this.metricsHistory.reduce((sum, m) => sum + m.launchCount, 0);

    // Confidence based on data volume
    const confidence = clamp(totalTokens / 100, 0, 1);

    return {
      rugRate24h,
      averageSurvivalTimeHours: this.config.indicators.avg_survival_time_hours,
      launchFrequency,
      averageAuthenticity,
      whaleParticipationRate,
      confidence,
    };
  }

  /**
   * Classify market regime
   */
  private classifyRegime(aggregate: MarketRegime['metrics'] & { confidence: number }): MarketRegimeType {
    const thresholds = this.config.indicators;

    // Check for low activity
    if (aggregate.launchFrequency <= this.config.regimes.LOW_ACTIVITY.launch_frequency_max) {
      return 'LOW_ACTIVITY';
    }

    // Check for high rug activity
    if (aggregate.rugRate24h >= thresholds.rug_rate_24h_threshold_high) {
      return 'HIGH_RUG_ACTIVITY';
    }

    // Check for bull launch season
    if (aggregate.rugRate24h <= this.config.regimes.BULL_LAUNCH_SEASON.rug_rate_max &&
        aggregate.whaleParticipationRate >= this.config.regimes.BULL_LAUNCH_SEASON.whale_participation_min) {
      return 'BULL_LAUNCH_SEASON';
    }

    // Default to normal
    return 'NORMAL';
  }

  /**
   * Calculate parameter adaptations for current regime
   */
  private calculateAdaptations(regime: MarketRegimeType): MarketRegime['adaptations'] {
    const adaptations = this.config.adaptations;

    switch (regime) {
      case 'BULL_LAUNCH_SEASON':
        return {
          filterMultiplier: adaptations.BULL_LAUNCH_SEASON.filter_multiplier,
          riskToleranceAdjustment: adaptations.BULL_LAUNCH_SEASON.risk_tolerance_boost,
          rankingAggressiveness: adaptations.BULL_LAUNCH_SEASON.ranking_aggressiveness,
        };

      case 'HIGH_RUG_ACTIVITY':
        return {
          filterMultiplier: adaptations.HIGH_RUG_ACTIVITY.filter_multiplier,
          riskToleranceAdjustment: -adaptations.HIGH_RUG_ACTIVITY.risk_tolerance_reduction,
          rankingAggressiveness: adaptations.HIGH_RUG_ACTIVITY.ranking_conservatism,
        };

      case 'LOW_ACTIVITY':
        return {
          filterMultiplier: 0.8,
          riskToleranceAdjustment: -0.1,
          rankingAggressiveness: 0.9,
        };

      case 'NORMAL':
      default:
        return {
          filterMultiplier: 1.0,
          riskToleranceAdjustment: 0,
          rankingAggressiveness: 1.0,
        };
    }
  }

  /**
   * Get current regime
   */
  public getCurrentRegime(): MarketRegime {
    return this.currentRegime;
  }

  /**
   * Apply regime adaptations to a score
   */
  public applyAdaptations(score: number, type: 'filter' | 'risk' | 'ranking'): number {
    const adaptations = this.currentRegime.adaptations;

    switch (type) {
      case 'filter':
        return score * adaptations.filterMultiplier;
      case 'risk':
        return clamp(score + adaptations.riskToleranceAdjustment, 0, 1);
      case 'ranking':
        return score * adaptations.rankingAggressiveness;
      default:
        return score;
    }
  }

  /**
   * Get regime description
   */
  public getRegimeDescription(regime: MarketRegimeType): string {
    switch (regime) {
      case 'BULL_LAUNCH_SEASON':
        return 'Bull Launch Season - High success rate, whale participation elevated';
      case 'NORMAL':
        return 'Normal Market - Standard operating conditions';
      case 'HIGH_RUG_ACTIVITY':
        return 'High Rug Activity - Elevated risk, proceed with caution';
      case 'LOW_ACTIVITY':
        return 'Low Activity - Reduced token launches, selective approach';
      default:
        return 'Unknown regime';
    }
  }

  /**
   * Get recommendations for current regime
   */
  public getRecommendations(): string[] {
    const recommendations: string[] = [];

    switch (this.currentRegime.currentRegime) {
      case 'BULL_LAUNCH_SEASON':
        recommendations.push('Increase position sizes moderately');
        recommendations.push('Pay attention to whale signals');
        recommendations.push('Shorter hold periods may be optimal');
        break;

      case 'HIGH_RUG_ACTIVITY':
        recommendations.push('Reduce position sizes');
        recommendations.push('Tighten stop losses');
        recommendations.push('Focus on high-authenticity tokens only');
        recommendations.push('Consider staying in stablecoins');
        break;

      case 'LOW_ACTIVITY':
        recommendations.push('Be selective with entries');
        recommendations.push('Wait for high-probability setups');
        recommendations.push('Reduce monitoring frequency');
        break;

      case 'NORMAL':
        recommendations.push('Follow standard strategy');
        recommendations.push('Maintain diversified approach');
        break;
    }

    return recommendations;
  }

  /**
   * Create default regime
   */
  private createDefaultRegime(): MarketRegime {
    return {
      currentRegime: 'NORMAL',
      confidence: 1,
      metrics: {
        rugRate24h: 0,
        averageSurvivalTimeHours: 24,
        launchFrequency: 0,
        averageAuthenticity: 0.5,
        whaleParticipationRate: 0.5,
      },
      adaptations: {
        filterMultiplier: 1.0,
        riskToleranceAdjustment: 0,
        rankingAggressiveness: 1.0,
      },
      since: Date.now(),
    };
  }

  /**
   * Get historical metrics
   */
  public getHistory(): MarketMetrics[] {
    return [...this.metricsHistory];
  }

  /**
   * Clear history
   */
  public clearHistory(): void {
    this.metricsHistory = [];
    logger.info('Market metrics history cleared');
  }
}

// Export singleton instance
export const regimeAnalyzer = new RegimeAnalyzer();
