/**
 * Risk Engine
 * 
 * Analyzes token risk based on multiple factors:
 * - Liquidity concentration
 * - Holder distribution
 * - Price volatility
 * - Contract risk indicators
 * - Developer risk signals
 */

import { TokenMetrics, RiskAssessment, HolderDistribution, LiquidityAnalysis } from '../types';
import { getStrategy } from '../config';
import { Logger } from '../utils/logger';
import { calculateVolatility, calculateConcentrationRisk, normalize, clamp } from '../utils/helpers';

const logger = new Logger('RiskEngine');

export class RiskEngine {
  private config = getStrategy().risk_engine;

  /**
   * Perform comprehensive risk assessment
   */
  public assess(
    metrics: TokenMetrics,
    holders?: HolderDistribution,
    liquidity?: LiquidityAnalysis
  ): RiskAssessment {
    logger.debug(`Assessing risk for ${metrics.symbol}`);

    const factors = {
      liquidityConcentration: this.assessLiquidityConcentration(liquidity),
      holderDistribution: this.assessHolderDistribution(holders),
      priceVolatility: this.assessPriceVolatility(metrics),
      contractRisk: this.assessContractRisk(metrics),
      developerRisk: this.assessDeveloperRisk(metrics),
    };

    // Calculate weighted risk score
    const score = this.calculateWeightedScore(factors);
    const level = this.determineRiskLevel(score);
    const warnings = this.generateWarnings(factors, metrics, holders, liquidity);

    return {
      score: clamp(score, 0, 1),
      level,
      factors,
      warnings,
    };
  }

  /**
   * Assess liquidity concentration risk
   */
  private assessLiquidityConcentration(liquidity?: LiquidityAnalysis): number {
    if (!liquidity) {
      return 0.5; // Unknown risk
    }

    let risk = 0;

    // High risk if liquidity is not locked
    if (liquidity.lockedPercentage < 0.5) {
      risk += 0.3;
    }

    // High risk if owner controls too much liquidity
    if (liquidity.ownerPercentage > this.config.indicators.max_liquidity_owner_percentage) {
      risk += 0.3;
    }

    // Risk from LP token concentration
    if (liquidity.lpTokenDistribution.topHolderPercentage > 0.5) {
      risk += 0.2;
    }

    // Risk from short lock duration
    if (liquidity.lockDurationDays < 30) {
      risk += 0.2;
    }

    return clamp(risk, 0, 1);
  }

  /**
   * Assess holder distribution risk
   */
  private assessHolderDistribution(holders?: HolderDistribution): number {
    if (!holders) {
      return 0.5; // Unknown risk
    }

    let risk = 0;

    // Concentration risk
    const concentrationRisk = calculateConcentrationRisk(
      holders.top10Percentage,
      holders.totalHolders
    );
    risk += concentrationRisk * 0.4;

    // Risk from low holder count
    if (holders.totalHolders < 100) {
      risk += 0.3;
    }

    // Risk from negative growth
    if (holders.growthRate1h < 0) {
      risk += 0.2;
    }

    // Risk from high seller ratio
    const sellRatio = holders.uniqueSellers1h / Math.max(holders.uniqueBuyers1h, 1);
    if (sellRatio > 1.5) {
      risk += 0.1;
    }

    return clamp(risk, 0, 1);
  }

  /**
   * Assess price volatility risk
   */
  private assessPriceVolatility(metrics: TokenMetrics): number {
    let risk = 0;

    // Risk from extreme short-term price changes
    const priceChanges = [
      metrics.priceChange5m,
      metrics.priceChange1h,
      metrics.priceChange24h,
    ].filter(c => c !== undefined);

    // Check for massive dumps
    const maxDump = Math.min(...priceChanges, 0);
    if (maxDump < this.config.indicators.max_price_dump_5m) {
      risk += 0.4;
    }

    // Check for extreme volatility
    const volatility = calculateVolatility(priceChanges.map(c => 1 + c));
    if (volatility > this.config.indicators.max_volatility_index) {
      risk += 0.3;
    }

    // Risk from rapid price increase (potential pump)
    const maxPump = Math.max(...priceChanges, 0);
    if (maxPump > 1.0) { // > 100% increase
      risk += 0.2;
    }

    // Risk from inconsistent price action
    const hasReversal = priceChanges.some(c => c > 0) && priceChanges.some(c => c < 0);
    if (hasReversal && volatility > 0.2) {
      risk += 0.1;
    }

    return clamp(risk, 0, 1);
  }

  /**
   * Assess contract risk
   */
  private assessContractRisk(metrics: TokenMetrics): number {
    let risk = 0;

    // Risk from low liquidity relative to market cap
    const liquidityRatio = metrics.liquidityUsd / Math.max(metrics.marketCap, 1);
    if (liquidityRatio < 0.1) {
      risk += 0.4;
    }

    // Risk from low volume relative to market cap
    const volumeRatio = metrics.volume24h / Math.max(metrics.marketCap, 1);
    if (volumeRatio < 0.05) {
      risk += 0.3;
    }

    // Risk from very new token
    if (metrics.ageMinutes < 10) {
      risk += 0.2;
    }

    // Risk from low transaction count
    const totalTxns = metrics.buys24h + metrics.sells24h;
    if (totalTxns < 50) {
      risk += 0.1;
    }

    return clamp(risk, 0, 1);
  }

  /**
   * Assess developer risk
   */
  private assessDeveloperRisk(metrics: TokenMetrics): number {
    // This is a placeholder - actual implementation would require
    // on-chain analysis of developer wallet history
    
    let risk = 0;

    // Risk from very recent creation
    if (metrics.ageMinutes < 30) {
      risk += 0.3;
    }

    // Risk from suspicious volume pattern
    const buySellRatio = metrics.buys24h / Math.max(metrics.sells24h, 1);
    if (buySellRatio > 10 || buySellRatio < 0.1) {
      risk += 0.3;
    }

    // Risk from low initial liquidity
    if (metrics.liquidityUsd < 50000) {
      risk += 0.2;
    }

    return clamp(risk, 0, 1);
  }

  /**
   * Calculate weighted risk score
   */
  private calculateWeightedScore(factors: RiskAssessment['factors']): number {
    const weights = this.config.weights;
    
    return (
      factors.liquidityConcentration * weights.liquidity_concentration +
      factors.holderDistribution * weights.holder_distribution +
      factors.priceVolatility * weights.price_volatility +
      factors.contractRisk * weights.contract_risk +
      factors.developerRisk * weights.developer_risk
    );
  }

  /**
   * Determine risk level from score
   */
  private determineRiskLevel(score: number): RiskAssessment['level'] {
    if (score >= this.config.thresholds.high_risk_score) {
      return 'CRITICAL';
    }
    if (score >= this.config.thresholds.medium_risk_score) {
      return 'HIGH';
    }
    if (score >= this.config.thresholds.low_risk_score) {
      return 'MEDIUM';
    }
    return 'LOW';
  }

  /**
   * Generate risk warnings
   */
  private generateWarnings(
    factors: RiskAssessment['factors'],
    metrics: TokenMetrics,
    holders?: HolderDistribution,
    liquidity?: LiquidityAnalysis
  ): string[] {
    const warnings: string[] = [];

    if (factors.liquidityConcentration > 0.6) {
      warnings.push('High liquidity concentration risk');
    }

    if (factors.holderDistribution > 0.6) {
      warnings.push('Poor holder distribution');
    }

    if (factors.priceVolatility > 0.6) {
      warnings.push('Extreme price volatility detected');
    }

    if (factors.contractRisk > 0.6) {
      warnings.push('Contract risk indicators present');
    }

    if (factors.developerRisk > 0.6) {
      warnings.push('Developer risk signals detected');
    }

    if (holders && holders.top10Percentage > 0.7) {
      warnings.push(`Top 10 holders control ${(holders.top10Percentage * 100).toFixed(1)}%`);
    }

    if (liquidity && liquidity.lockedPercentage < 0.3) {
      warnings.push('Low liquidity lock percentage');
    }

    if (metrics.priceChange5m < -0.3) {
      warnings.push('Significant price drop in last 5 minutes');
    }

    return warnings;
  }

  /**
   * Quick risk check for filtering
   */
  public quickCheck(metrics: TokenMetrics): boolean {
    const score = this.assess(metrics);
    return score.level !== 'CRITICAL' && score.score < this.config.thresholds.high_risk_score;
  }
}

// Export singleton instance
export const riskEngine = new RiskEngine();
