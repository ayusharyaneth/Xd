/**
 * Whale Detection Engine
 * 
 * Detects whale activity based on:
 * - Large trade sizes
 * - Wallet portfolio value
 * - Historical trading volume
 * - Exit behavior patterns
 */

import { TokenMetrics, WhaleActivity, WhaleTransaction } from '../types';
import { getStrategy } from '../config';
import { Logger } from '../utils/logger';
import { clamp } from '../utils/helpers';

const logger = new Logger('WhaleEngine');

export interface WalletInfo {
  address: string;
  portfolioValue: number;
  historicalVolume: number;
  trades: WhaleTransaction[];
}

export class WhaleEngine {
  private config = getStrategy().whale_detection;
  private walletCache: Map<string, WalletInfo> = new Map();
  private recentAlerts: Map<string, number> = new Map();

  /**
   * Detect whale activity for a token
   */
  public detect(
    metrics: TokenMetrics,
    trades?: WhaleTransaction[],
    walletInfos?: WalletInfo[]
  ): WhaleActivity {
    logger.debug(`Detecting whale activity for ${metrics.symbol}`);

    if (!trades || trades.length === 0) {
      return this.createEmptyActivity();
    }

    // Filter whale trades
    const whaleTrades = this.filterWhaleTrades(trades);
    
    if (whaleTrades.length === 0) {
      return this.createEmptyActivity();
    }

    // Analyze whale behavior
    const analyzedTrades = this.analyzeWhaleTrades(whaleTrades, walletInfos);
    
    // Determine badge level
    const badge = this.determineBadgeLevel(analyzedTrades);
    
    // Calculate confidence
    const confidence = this.calculateConfidence(analyzedTrades, metrics);
    
    // Generate summary
    const summary = this.generateSummary(analyzedTrades);

    return {
      detected: true,
      badge,
      activities: analyzedTrades,
      confidence,
      summary,
    };
  }

  /**
   * Filter trades to find whale transactions
   */
  private filterWhaleTrades(trades: WhaleTransaction[]): WhaleTransaction[] {
    const threshold = this.config.thresholds.trade_size_usd;
    
    return trades.filter(trade => {
      // Check trade size
      if (trade.amountUsd >= threshold) {
        return true;
      }
      
      // Check if wallet is known whale
      const walletInfo = this.walletCache.get(trade.wallet);
      if (walletInfo) {
        if (walletInfo.portfolioValue >= this.config.thresholds.wallet_portfolio_usd) {
          return true;
        }
        if (walletInfo.historicalVolume >= this.config.thresholds.wallet_historical_volume_usd) {
          return true;
        }
      }
      
      return false;
    });
  }

  /**
   * Analyze whale trades and assign badges
   */
  private analyzeWhaleTrades(
    trades: WhaleTransaction[],
    walletInfos?: WalletInfo[]
  ): WhaleTransaction[] {
    return trades.map(trade => {
      const walletInfo = walletInfos?.find(w => w.address === trade.wallet) ||
                        this.walletCache.get(trade.wallet);

      let badge: WhaleTransaction['badge'] = 'NONE';

      // Determine badge based on trade size
      if (trade.amountUsd >= this.config.badges.mega_whale_usd) {
        badge = 'MEGA';
      } else if (trade.amountUsd >= this.config.badges.large_whale_usd) {
        badge = 'LARGE';
      } else if (trade.amountUsd >= this.config.badges.medium_whale_usd) {
        badge = 'MEDIUM';
      }

      // Upgrade badge if wallet portfolio is large
      if (walletInfo) {
        if (walletInfo.portfolioValue >= this.config.badges.mega_whale_usd * 2) {
          badge = 'MEGA';
        } else if (walletInfo.portfolioValue >= this.config.badges.large_whale_usd * 2 && badge !== 'MEGA') {
          badge = 'LARGE';
        }
      }

      return {
        ...trade,
        badge,
        portfolioValue: walletInfo?.portfolioValue,
      };
    });
  }

  /**
   * Determine overall badge level for the activity
   */
  private determineBadgeLevel(trades: WhaleTransaction[]): WhaleActivity['badge'] {
    if (trades.some(t => t.badge === 'MEGA')) {
      return 'MEGA';
    }
    if (trades.some(t => t.badge === 'LARGE')) {
      return 'LARGE';
    }
    if (trades.some(t => t.badge === 'MEDIUM')) {
      return 'MEDIUM';
    }
    return 'NONE';
  }

  /**
   * Calculate detection confidence
   */
  private calculateConfidence(
    trades: WhaleTransaction[],
    metrics: TokenMetrics
  ): number {
    let confidence = 0.5;

    // More trades = higher confidence
    if (trades.length >= 10) {
      confidence += 0.2;
    } else if (trades.length >= 5) {
      confidence += 0.1;
    }

    // Higher total volume = higher confidence
    const totalVolume = trades.reduce((sum, t) => sum + t.amountUsd, 0);
    const volumeRatio = totalVolume / Math.max(metrics.volume24h, 1);
    
    if (volumeRatio > 0.3) {
      confidence += 0.2;
    } else if (volumeRatio > 0.1) {
      confidence += 0.1;
    }

    // Known whale wallets increase confidence
    const knownWhales = trades.filter(t => this.walletCache.has(t.wallet)).length;
    if (knownWhales > 0) {
      confidence += Math.min(knownWhales * 0.05, 0.2);
    }

    return clamp(confidence, 0, 1);
  }

  /**
   * Generate activity summary
   */
  private generateSummary(trades: WhaleTransaction[]): WhaleActivity['summary'] {
    const buys = trades.filter(t => t.type === 'BUY');
    const sells = trades.filter(t => t.type === 'SELL');

    const totalWhaleBuys = buys.length;
    const totalWhaleSells = sells.length;
    
    const buyVolume = buys.reduce((sum, t) => sum + t.amountUsd, 0);
    const sellVolume = sells.reduce((sum, t) => sum + t.amountUsd, 0);
    const netWhaleFlow = buyVolume - sellVolume;

    const uniqueWallets = new Set(trades.map(t => t.wallet)).size;

    return {
      totalWhaleBuys,
      totalWhaleSells,
      netWhaleFlow,
      uniqueWhales: uniqueWallets,
    };
  }

  /**
   * Detect whale exit behavior
   */
  public detectWhaleExit(
    tokenAddress: string,
    currentTrades: WhaleTransaction[],
    historicalTrades?: WhaleTransaction[]
  ): {
    exiting: boolean;
    confidence: number;
    exitingWallets: string[];
  } {
    if (!historicalTrades || historicalTrades.length === 0) {
      return { exiting: false, confidence: 0, exitingWallets: [] };
    }

    const exitingWallets: string[] = [];
    let totalConfidence = 0;

    // Group trades by wallet
    const walletHistory = this.groupTradesByWallet(historicalTrades);
    const walletCurrent = this.groupTradesByWallet(currentTrades);

    for (const [wallet, history] of walletHistory.entries()) {
      const current = walletCurrent.get(wallet) || [];
      
      const historyBuys = history.filter(t => t.type === 'BUY').length;
      const historySells = history.filter(t => t.type === 'SELL').length;
      
      const currentBuys = current.filter(t => t.type === 'BUY').length;
      const currentSells = current.filter(t => t.type === 'SELL').length;

      // Detect exit pattern: was buying, now selling
      if (historyBuys > historySells && currentSells > currentBuys * 2) {
        const exitRatio = currentSells / Math.max(currentBuys, 1);
        
        if (exitRatio > this.config.behavior.exit_detection_threshold) {
          exitingWallets.push(wallet);
          totalConfidence += Math.min(exitRatio / 2, 1);
        }
      }
    }

    const confidence = exitingWallets.length > 0 
      ? totalConfidence / exitingWallets.length 
      : 0;

    return {
      exiting: exitingWallets.length > 0,
      confidence: clamp(confidence, 0, 1),
      exitingWallets,
    };
  }

  /**
   * Detect whale accumulation pattern
   */
  public detectAccumulation(
    trades: WhaleTransaction[],
    minTrades: number = 3
  ): {
    accumulating: boolean;
    confidence: number;
    wallets: string[];
  } {
    const walletTrades = this.groupTradesByWallet(trades);
    const accumulatingWallets: string[] = [];
    let totalConfidence = 0;

    for (const [wallet, walletTradeList] of walletTrades.entries()) {
      if (walletTradeList.length < minTrades) continue;

      const buys = walletTradeList.filter(t => t.type === 'BUY');
      const sells = walletTradeList.filter(t => t.type === 'SELL');

      const buyVolume = buys.reduce((sum, t) => sum + t.amountUsd, 0);
      const sellVolume = sells.reduce((sum, t) => sum + t.amountUsd, 0);

      // Accumulation pattern: mostly buying, increasing volume
      if (buys.length > sells.length * 2 && buyVolume > sellVolume * 3) {
        const accumulationRatio = buyVolume / Math.max(sellVolume, 1);
        
        if (accumulationRatio > this.config.behavior.accumulation_detection_threshold) {
          accumulatingWallets.push(wallet);
          totalConfidence += Math.min(accumulationRatio / 3, 1);
        }
      }
    }

    const confidence = accumulatingWallets.length > 0
      ? totalConfidence / accumulatingWallets.length
      : 0;

    return {
      accumulating: accumulatingWallets.length > 0,
      confidence: clamp(confidence, 0, 1),
      wallets: accumulatingWallets,
    };
  }

  /**
   * Cache wallet information
   */
  public cacheWalletInfo(walletInfo: WalletInfo): void {
    this.walletCache.set(walletInfo.address, walletInfo);
    logger.debug(`Cached wallet info for: ${walletInfo.address}`);
  }

  /**
   * Get cached wallet info
   */
  public getWalletInfo(address: string): WalletInfo | undefined {
    return this.walletCache.get(address);
  }

  /**
   * Check if whale alert is in cooldown
   */
  public isInCooldown(tokenAddress: string): boolean {
    const lastAlert = this.recentAlerts.get(tokenAddress);
    if (!lastAlert) return false;

    const cooldownMs = getStrategy().system.cooldowns.whale_alert_seconds * 1000;
    return Date.now() - lastAlert < cooldownMs;
  }

  /**
   * Record whale alert
   */
  public recordAlert(tokenAddress: string): void {
    this.recentAlerts.set(tokenAddress, Date.now());
  }

  /**
   * Create empty activity object
   */
  private createEmptyActivity(): WhaleActivity {
    return {
      detected: false,
      badge: 'NONE',
      activities: [],
      confidence: 0,
      summary: {
        totalWhaleBuys: 0,
        totalWhaleSells: 0,
        netWhaleFlow: 0,
        uniqueWhales: 0,
      },
    };
  }

  /**
   * Group trades by wallet
   */
  private groupTradesByWallet(trades: WhaleTransaction[]): Map<string, WhaleTransaction[]> {
    const grouped = new Map<string, WhaleTransaction[]>();
    
    for (const trade of trades) {
      const existing = grouped.get(trade.wallet) || [];
      existing.push(trade);
      grouped.set(trade.wallet, existing);
    }
    
    return grouped;
  }

  /**
   * Clear old alerts (call periodically)
   */
  public cleanupOldAlerts(): void {
    const cooldownMs = getStrategy().system.cooldowns.whale_alert_seconds * 1000;
    const now = Date.now();
    
    for (const [address, timestamp] of this.recentAlerts.entries()) {
      if (now - timestamp > cooldownMs * 2) {
        this.recentAlerts.delete(address);
      }
    }
  }

  /**
   * Get whale statistics
   */
  public getStats(): {
    cachedWallets: number;
    recentAlerts: number;
  } {
    return {
      cachedWallets: this.walletCache.size,
      recentAlerts: this.recentAlerts.size,
    };
  }
}

// Export singleton instance
export const whaleEngine = new WhaleEngine();
