/**
 * Metrics System
 * 
 * Collects and exposes system metrics for monitoring
 * Optional Prometheus integration
 */

import { SystemMetrics } from '../types';
import { Logger } from '../utils/logger';

const logger = new Logger('Metrics');

export class MetricsCollector {
  private metrics: SystemMetrics[] = [];
  private currentMetrics: Partial<SystemMetrics> = {};
  private maxHistorySize: number = 1000;

  /**
   * Record a metric
   */
  public record(metric: Partial<SystemMetrics>): void {
    this.currentMetrics = { ...this.currentMetrics, ...metric };
  }

  /**
   * Flush current metrics to history
   */
  public flush(): void {
    if (Object.keys(this.currentMetrics).length === 0) return;

    const fullMetrics: SystemMetrics = {
      timestamp: Date.now(),
      tokensProcessed: this.currentMetrics.tokensProcessed || 0,
      tokensFiltered: this.currentMetrics.tokensFiltered || 0,
      alertsGenerated: this.currentMetrics.alertsGenerated || 0,
      alertsSent: this.currentMetrics.alertsSent || 0,
      alertsSuppressed: this.currentMetrics.alertsSuppressed || 0,
      engineLatencies: this.currentMetrics.engineLatencies || {
        risk: 0,
        authenticity: 0,
        developer: 0,
        buyQuality: 0,
        whale: 0,
        probability: 0,
        ranking: 0,
      },
      activeWatchSessions: this.currentMetrics.activeWatchSessions || 0,
      watchUpdatesSent: this.currentMetrics.watchUpdatesSent || 0,
      memoryUsage: this.currentMetrics.memoryUsage || 0,
      cpuUsage: this.currentMetrics.cpuUsage || 0,
      eventLoopLag: this.currentMetrics.eventLoopLag || 0,
    };

    this.metrics.push(fullMetrics);

    // Trim history if needed
    if (this.metrics.length > this.maxHistorySize) {
      this.metrics = this.metrics.slice(-this.maxHistorySize);
    }

    // Reset current metrics
    this.currentMetrics = {};
  }

  /**
   * Get metrics history
   */
  public getHistory(): SystemMetrics[] {
    return [...this.metrics];
  }

  /**
   * Get latest metrics
   */
  public getLatest(): SystemMetrics | undefined {
    return this.metrics[this.metrics.length - 1];
  }

  /**
   * Get average metrics over time window
   */
  public getAverages(minutes: number): Partial<SystemMetrics> {
    const cutoff = Date.now() - minutes * 60000;
    const recent = this.metrics.filter(m => m.timestamp >= cutoff);

    if (recent.length === 0) return {};

    const avg = (vals: number[]) => vals.reduce((a, b) => a + b, 0) / vals.length;

    return {
      tokensProcessed: avg(recent.map(m => m.tokensProcessed)),
      tokensFiltered: avg(recent.map(m => m.tokensFiltered)),
      alertsGenerated: avg(recent.map(m => m.alertsGenerated)),
      alertsSent: avg(recent.map(m => m.alertsSent)),
      alertsSuppressed: avg(recent.map(m => m.alertsSuppressed)),
      activeWatchSessions: avg(recent.map(m => m.activeWatchSessions)),
      watchUpdatesSent: avg(recent.map(m => m.watchUpdatesSent)),
      memoryUsage: avg(recent.map(m => m.memoryUsage)),
      cpuUsage: avg(recent.map(m => m.cpuUsage)),
      eventLoopLag: avg(recent.map(m => m.eventLoopLag)),
    };
  }

  /**
   * Clear metrics history
   */
  public clear(): void {
    this.metrics = [];
    this.currentMetrics = {};
    logger.info('Metrics history cleared');
  }

  /**
   * Get metrics in Prometheus format
   */
  public getPrometheusFormat(): string {
    const latest = this.getLatest();
    if (!latest) return '';

    const lines: string[] = [];

    // Helper to add metric
    const addMetric = (name: string, value: number, help?: string) => {
      if (help) lines.push(`# HELP ${name} ${help}`);
      lines.push(`# TYPE ${name} gauge`);
      lines.push(`${name} ${value}`);
    };

    addMetric(
      'dexintel_tokens_processed_total',
      latest.tokensProcessed,
      'Total number of tokens processed'
    );

    addMetric(
      'dexintel_alerts_generated_total',
      latest.alertsGenerated,
      'Total number of alerts generated'
    );

    addMetric(
      'dexintel_alerts_sent_total',
      latest.alertsSent,
      'Total number of alerts sent'
    );

    addMetric(
      'dexintel_watch_sessions_active',
      latest.activeWatchSessions,
      'Number of active watch sessions'
    );

    addMetric(
      'dexintel_memory_usage_bytes',
      latest.memoryUsage,
      'Memory usage in bytes'
    );

    return lines.join('\n');
  }
}

// Export singleton instance
export const metricsCollector = new MetricsCollector();
