/**
 * Health Monitor
 * 
 * Monitors system health and provides:
 * - /ping command response
 * - Health check endpoint
 * - Status reporting
 * - Anomaly detection
 */

import { SystemHealth, HealthCheckResult } from '../types';
import { getStrategy, getEnv } from '../config';
import { Logger } from '../utils/logger';
import { dexScreenerClient } from '../api/dexscreener';
import { selfDefenseManager } from './selfDefense';
import { regimeAnalyzer } from '../engines/regime';
import { watchManager } from '../watch/manager';

const logger = new Logger('HealthMonitor');

export interface ComponentStatus {
  name: string;
  healthy: boolean;
  latency: number;
  lastCheck: number;
  error?: string;
}

export class HealthMonitor {
  private config = getStrategy().health_monitor;
  private componentStatus: Map<string, ComponentStatus> = new Map();
  private checkInterval?: NodeJS.Timeout;
  private startTime: number = Date.now();

  constructor() {
    this.initializeComponents();
  }

  /**
   * Initialize component status tracking
   */
  private initializeComponents(): void {
    this.componentStatus.set('dexApi', {
      name: 'DexScreener API',
      healthy: true,
      latency: 0,
      lastCheck: 0,
    });

    this.componentStatus.set('signalBot', {
      name: 'Signal Bot',
      healthy: true,
      latency: 0,
      lastCheck: 0,
    });

    this.componentStatus.set('alertBot', {
      name: 'Alert Bot',
      healthy: true,
      latency: 0,
      lastCheck: 0,
    });

    this.componentStatus.set('database', {
      name: 'Database',
      healthy: true,
      latency: 0,
      lastCheck: 0,
    });
  }

  /**
   * Start health monitoring
   */
  public start(): void {
    if (this.checkInterval) return;

    logger.info('Starting health monitoring');
    
    this.checkInterval = setInterval(
      () => this.performCheck(),
      this.config.ping.check_interval_seconds * 1000
    );
  }

  /**
   * Stop health monitoring
   */
  public stop(): void {
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
      this.checkInterval = undefined;
      logger.info('Health monitoring stopped');
    }
  }

  /**
   * Perform health check
   */
  private async performCheck(): Promise<void> {
    try {
      // Check DexScreener API
      await this.checkDexApi();

      // Check bots (would need actual bot health checks)
      await this.checkBots();

      // Log health status
      const health = this.getHealth();
      if (health.status !== 'HEALTHY') {
        logger.warn(`System health: ${health.status}`);
      }
    } catch (error) {
      logger.error('Error in health check:', error);
    }
  }

  /**
   * Check DexScreener API health
   */
  private async checkDexApi(): Promise<void> {
    const start = Date.now();
    
    try {
      const health = await dexScreenerClient.healthCheck();
      
      this.componentStatus.set('dexApi', {
        name: 'DexScreener API',
        healthy: health.healthy,
        latency: health.latency,
        lastCheck: Date.now(),
        error: health.error,
      });
    } catch (error) {
      this.componentStatus.set('dexApi', {
        name: 'DexScreener API',
        healthy: false,
        latency: Date.now() - start,
        lastCheck: Date.now(),
        error: (error as Error).message,
      });
    }
  }

  /**
   * Check bot health
   */
  private async checkBots(): Promise<void> {
    // Placeholder - would check actual bot connectivity
    this.componentStatus.set('signalBot', {
      name: 'Signal Bot',
      healthy: true,
      latency: 0,
      lastCheck: Date.now(),
    });

    this.componentStatus.set('alertBot', {
      name: 'Alert Bot',
      healthy: true,
      latency: 0,
      lastCheck: Date.now(),
    });
  }

  /**
   * Get system health
   */
  public getHealth(): SystemHealth {
    const components = this.getComponentHealth();
    
    // Calculate overall status
    let status: SystemHealth['status'] = 'HEALTHY';
    
    if (selfDefenseManager.isInSafeMode()) {
      status = 'SAFE_MODE';
    } else {
      const unhealthyCount = Object.values(components).filter(c => !c).length;
      if (unhealthyCount >= 2) {
        status = 'UNHEALTHY';
      } else if (unhealthyCount === 1) {
        status = 'DEGRADED';
      }
    }

    // Calculate latencies
    const apiStatus = this.componentStatus.get('dexApi');
    const latency = {
      api: apiStatus?.latency || 0,
      rpc: 0, // Would need RPC client
      overall: apiStatus?.latency || 0,
    };

    // Calculate error rates
    const errorRates = {
      api: dexScreenerClient.getErrorRate(),
      rpc: 0,
      overall: dexScreenerClient.getErrorRate(),
    };

    // Get resource usage
    const memUsage = process.memoryUsage();
    const resources = {
      memoryUsagePercent: (memUsage.heapUsed / memUsage.heapTotal) * 100,
      cpuUsagePercent: 0, // Would need CPU measurement
      uptimeSeconds: Math.floor((Date.now() - this.startTime) / 1000),
    };

    return {
      status,
      timestamp: Date.now(),
      latency,
      errorRates,
      resources,
      components,
      safeMode: selfDefenseManager.isInSafeMode(),
      safeModeSince: selfDefenseManager.getStatus().activatedAt,
      safeModeReason: selfDefenseManager.getStatus().reason,
    };
  }

  /**
   * Get component health status
   */
  private getComponentHealth(): SystemHealth['components'] {
    return {
      dexApi: this.componentStatus.get('dexApi')?.healthy || false,
      signalBot: this.componentStatus.get('signalBot')?.healthy || false,
      alertBot: this.componentStatus.get('alertBot')?.healthy || false,
      database: this.componentStatus.get('database')?.healthy || false,
    };
  }

  /**
   * Get detailed health check result
   */
  public async getDetailedHealthCheck(): Promise<HealthCheckResult> {
    const checks: HealthCheckResult['checks'] = [];

    // Check DexScreener API
    const apiStart = Date.now();
    try {
      await dexScreenerClient.healthCheck();
      checks.push({
        name: 'DexScreener API',
        passed: true,
        responseTime: Date.now() - apiStart,
      });
    } catch (error) {
      checks.push({
        name: 'DexScreener API',
        passed: false,
        responseTime: Date.now() - apiStart,
        error: (error as Error).message,
      });
    }

    // Check memory
    const memUsage = process.memoryUsage();
    const memPercent = (memUsage.heapUsed / memUsage.heapTotal) * 100;
    checks.push({
      name: 'Memory Usage',
      passed: memPercent < 90,
      responseTime: 0,
      error: memPercent >= 90 ? `Memory usage at ${memPercent.toFixed(1)}%` : undefined,
    });

    // Check safe mode
    checks.push({
      name: 'Safe Mode',
      passed: !selfDefenseManager.isInSafeMode(),
      responseTime: 0,
      error: selfDefenseManager.isInSafeMode() ? 'System in safe mode' : undefined,
    });

    const allPassed = checks.every(c => c.passed);
    const anyFailed = checks.some(c => !c.passed);

    return {
      healthy: allPassed,
      degraded: !allPassed && !anyFailed,
      checks,
    };
  }

  /**
   * Get /ping response data
   */
  public getPingResponse(): {
    status: string;
    latency: number;
    regime: string;
    safeMode: boolean;
    errorRate: number;
    activeWatches: number;
    uptime: string;
    version: string;
  } {
    const health = this.getHealth();
    const regime = regimeAnalyzer.getCurrentRegime();

    return {
      status: health.status,
      latency: health.latency.overall,
      regime: regime.currentRegime,
      safeMode: health.safeMode,
      errorRate: health.errorRates.overall,
      activeWatches: watchManager.getActiveSessionCount(),
      uptime: this.formatUptime(health.resources.uptimeSeconds),
      version: '1.0.0',
    };
  }

  /**
   * Format uptime for display
   */
  private formatUptime(seconds: number): string {
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;

    if (days > 0) {
      return `${days}d ${hours}h ${minutes}m`;
    }
    if (hours > 0) {
      return `${hours}h ${minutes}m ${secs}s`;
    }
    return `${minutes}m ${secs}s`;
  }

  /**
   * Get component status
   */
  public getComponentStatus(name: string): ComponentStatus | undefined {
    return this.componentStatus.get(name);
  }

  /**
   * Update component status
   */
  public updateComponentStatus(name: string, status: Partial<ComponentStatus>): void {
    const current = this.componentStatus.get(name);
    if (current) {
      this.componentStatus.set(name, { ...current, ...status });
    }
  }

  /**
   * Get all component statuses
   */
  public getAllComponentStatuses(): ComponentStatus[] {
    return Array.from(this.componentStatus.values());
  }

  /**
   * Check if system is healthy
   */
  public isHealthy(): boolean {
    return this.getHealth().status === 'HEALTHY';
  }

  /**
   * Get error summary
   */
  public getErrorSummary(): {
    totalErrors: number;
    recentErrors: string[];
  } {
    const recentErrors: string[] = [];
    
    for (const [name, status] of this.componentStatus.entries()) {
      if (!status.healthy && status.error) {
        recentErrors.push(`${name}: ${status.error}`);
      }
    }

    return {
      totalErrors: recentErrors.length,
      recentErrors,
    };
  }
}

// Export singleton instance
export const healthMonitor = new HealthMonitor();
