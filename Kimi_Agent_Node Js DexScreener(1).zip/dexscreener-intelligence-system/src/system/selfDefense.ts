/**
 * Self-Defense Manager
 * 
 * Monitors system health and activates safe mode when:
 * - API error rate exceeds threshold
 * - RPC error rate exceeds threshold
 * - Latency exceeds threshold
 * - Memory usage exceeds threshold
 * - CPU usage exceeds threshold
 */

import { SelfDefenseStatus, SystemHealth } from '../types';
import { getStrategy } from '../config';
import { Logger } from '../utils/logger';
import { dexScreenerClient } from '../api/dexscreener';

const logger = new Logger('SelfDefense');

export interface SystemMetrics {
  timestamp: number;
  apiErrorRate: number;
  rpcErrorRate: number;
  averageLatency: number;
  memoryUsage: number;
  cpuUsage: number;
  requestQueueDepth: number;
}

export class SelfDefenseManager {
  private config = getStrategy().self_defense;
  private status: SelfDefenseStatus;
  private metricsHistory: SystemMetrics[] = [];
  private checkInterval?: NodeJS.Timeout;
  private consecutiveHealthyChecks: number = 0;

  constructor() {
    this.status = this.createDefaultStatus();
  }

  /**
   * Start monitoring
   */
  public start(): void {
    if (this.checkInterval) {
      return;
    }

    logger.info('Starting self-defense monitoring');
    
    this.checkInterval = setInterval(
      () => this.check(),
      this.config.monitoring.check_interval_seconds * 1000
    );
  }

  /**
   * Stop monitoring
   */
  public stop(): void {
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
      this.checkInterval = undefined;
      logger.info('Self-defense monitoring stopped');
    }
  }

  /**
   * Perform health check
   */
  private async check(): Promise<void> {
    try {
      const metrics = await this.collectMetrics();
      this.metricsHistory.push(metrics);

      // Keep only recent history
      this.pruneOldMetrics();

      // Check thresholds
      const violations = this.checkThresholds(metrics);

      if (violations.length > 0) {
        this.consecutiveHealthyChecks = 0;
        
        if (!this.status.active) {
          this.activateSafeMode(violations, metrics);
        }
      } else {
        this.consecutiveHealthyChecks++;
        
        if (this.status.active && this.shouldDeactivate()) {
          this.deactivateSafeMode();
        }
      }

      this.updateStatusMetrics(metrics);
    } catch (error) {
      logger.error('Error in self-defense check:', error);
    }
  }

  /**
   * Collect system metrics
   */
  private async collectMetrics(): Promise<SystemMetrics> {
    const memUsage = process.memoryUsage();
    const memoryUsagePercent = (memUsage.heapUsed / memUsage.heapTotal) * 100;

    // Get API health
    const apiHealth = await dexScreenerClient.healthCheck();
    const apiErrorRate = dexScreenerClient.getErrorRate();

    return {
      timestamp: Date.now(),
      apiErrorRate,
      rpcErrorRate: 0, // Would need RPC client
      averageLatency: apiHealth.latency,
      memoryUsage: memoryUsagePercent,
      cpuUsage: 0, // Would need CPU measurement
      requestQueueDepth: 0, // Would need queue tracking
    };
  }

  /**
   * Prune old metrics
   */
  private pruneOldMetrics(): void {
    const maxAge = 60 * 60 * 1000; // 1 hour
    const cutoff = Date.now() - maxAge;
    this.metricsHistory = this.metricsHistory.filter(m => m.timestamp >= cutoff);
  }

  /**
   * Check thresholds for violations
   */
  private checkThresholds(metrics: SystemMetrics): string[] {
    const violations: string[] = [];
    const thresholds = this.config.thresholds;

    if (metrics.apiErrorRate > thresholds.api_error_rate_max) {
      violations.push(`API error rate ${(metrics.apiErrorRate * 100).toFixed(1)}% exceeds threshold`);
    }

    if (metrics.rpcErrorRate > thresholds.rpc_error_rate_max) {
      violations.push(`RPC error rate ${(metrics.rpcErrorRate * 100).toFixed(1)}% exceeds threshold`);
    }

    if (metrics.averageLatency > thresholds.latency_ms_max) {
      violations.push(`Latency ${metrics.averageLatency}ms exceeds threshold`);
    }

    if (metrics.memoryUsage > thresholds.memory_usage_percent_max) {
      violations.push(`Memory usage ${metrics.memoryUsage.toFixed(1)}% exceeds threshold`);
    }

    if (metrics.cpuUsage > thresholds.cpu_usage_percent_max) {
      violations.push(`CPU usage ${metrics.cpuUsage.toFixed(1)}% exceeds threshold`);
    }

    return violations;
  }

  /**
   * Activate safe mode
   */
  private activateSafeMode(violations: string[], metrics: SystemMetrics): void {
    logger.warn('Activating safe mode due to:', violations);

    this.status = {
      active: true,
      activatedAt: Date.now(),
      reason: violations.join('; '),
      metrics: {
        apiErrorRate: metrics.apiErrorRate,
        rpcErrorRate: metrics.rpcErrorRate,
        averageLatency: metrics.averageLatency,
        memoryUsage: metrics.memoryUsage,
        cpuUsage: metrics.cpuUsage,
      },
      actions: {
        pollingIntervalIncreased: true,
        nonCriticalAlertsSuppressed: true,
        concurrentRequestsReduced: true,
      },
    };

    // Notify via alert bot would happen here
  }

  /**
   * Deactivate safe mode
   */
  private deactivateSafeMode(): void {
    logger.info('Deactivating safe mode - system recovered');

    this.status = {
      ...this.status,
      active: false,
      reason: undefined,
      actions: {
        pollingIntervalIncreased: false,
        nonCriticalAlertsSuppressed: false,
        concurrentRequestsReduced: false,
      },
    };

    this.consecutiveHealthyChecks = 0;
  }

  /**
   * Check if safe mode should be deactivated
   */
  private shouldDeactivate(): boolean {
    if (!this.config.recovery.auto_recovery_enabled) {
      return false;
    }

    return this.consecutiveHealthyChecks >= this.config.recovery.consecutive_success_threshold;
  }

  /**
   * Update status metrics
   */
  private updateStatusMetrics(metrics: SystemMetrics): void {
    this.status.metrics = {
      apiErrorRate: metrics.apiErrorRate,
      rpcErrorRate: metrics.rpcErrorRate,
      averageLatency: metrics.averageLatency,
      memoryUsage: metrics.memoryUsage,
      cpuUsage: metrics.cpuUsage,
    };
  }

  /**
   * Get current status
   */
  public getStatus(): SelfDefenseStatus {
    return this.status;
  }

  /**
   * Check if in safe mode
   */
  public isInSafeMode(): boolean {
    return this.status.active;
  }

  /**
   * Get safe mode actions
   */
  public getSafeModeActions(): SelfDefenseStatus['actions'] {
    return this.status.actions;
  }

  /**
   * Get adjusted polling interval
   */
  public getAdjustedPollingInterval(baseInterval: number): number {
    if (!this.status.active) {
      return baseInterval;
    }

    return baseInterval * this.config.safe_mode.polling_interval_multiplier;
  }

  /**
   * Should suppress non-critical alerts
   */
  public shouldSuppressAlerts(): boolean {
    return this.status.active && this.config.safe_mode.suppress_non_critical_alerts;
  }

  /**
   * Get max concurrent requests
   */
  public getMaxConcurrentRequests(baseMax: number): number {
    if (!this.status.active || !this.config.safe_mode.reduce_concurrent_requests) {
      return baseMax;
    }

    return Math.max(1, Math.floor(baseMax / 2));
  }

  /**
   * Force activate safe mode (manual override)
   */
  public forceActivate(reason: string): void {
    logger.warn(`Safe mode force activated: ${reason}`);
    
    this.status = {
      ...this.status,
      active: true,
      activatedAt: Date.now(),
      reason: `MANUAL: ${reason}`,
      actions: {
        pollingIntervalIncreased: true,
        nonCriticalAlertsSuppressed: true,
        concurrentRequestsReduced: true,
      },
    };
  }

  /**
   * Force deactivate safe mode (manual override)
   */
  public forceDeactivate(): void {
    logger.info('Safe mode force deactivated');
    this.deactivateSafeMode();
  }

  /**
   * Create default status
   */
  private createDefaultStatus(): SelfDefenseStatus {
    return {
      active: false,
      metrics: {
        apiErrorRate: 0,
        rpcErrorRate: 0,
        averageLatency: 0,
        memoryUsage: 0,
        cpuUsage: 0,
      },
      actions: {
        pollingIntervalIncreased: false,
        nonCriticalAlertsSuppressed: false,
        concurrentRequestsReduced: false,
      },
    };
  }

  /**
   * Get metrics history
   */
  public getMetricsHistory(): SystemMetrics[] {
    return [...this.metricsHistory];
  }

  /**
   * Get system health summary
   */
  public getHealthSummary(): {
    status: 'HEALTHY' | 'DEGRADED' | 'CRITICAL';
    issues: string[];
  } {
    if (!this.metricsHistory.length) {
      return { status: 'HEALTHY', issues: [] };
    }

    const latest = this.metricsHistory[this.metricsHistory.length - 1];
    const issues: string[] = [];

    if (latest.apiErrorRate > 0.1) issues.push('Elevated API error rate');
    if (latest.averageLatency > 2000) issues.push('High latency');
    if (latest.memoryUsage > 80) issues.push('High memory usage');

    if (this.status.active) {
      return { status: 'CRITICAL', issues: [this.status.reason || 'Safe mode active', ...issues] };
    }

    if (issues.length > 0) {
      return { status: 'DEGRADED', issues };
    }

    return { status: 'HEALTHY', issues: [] };
  }
}

// Export singleton instance
export const selfDefenseManager = new SelfDefenseManager();
