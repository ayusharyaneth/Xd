/**
 * Watch Manager
 * 
 * Manages watch mode sessions:
 * - Create and track watch sessions
 * - Periodic updates
 * - Significant change detection
 * - Escalation alerts
 * - Expiration handling
 */

import { WatchSession, WatchUpdate, TokenMetrics, ExitSignal } from '../types';
import { getStrategy } from '../config';
import { Logger } from '../utils/logger';
import { generateId, clamp } from '../utils/helpers';
import { exitEngine } from '../engines/exit';

const logger = new Logger('WatchManager');

export interface WatchCallbacks {
  onSignificantChange?: (update: WatchUpdate) => void;
  onEscalation?: (update: WatchUpdate) => void;
  onExitSignal?: (update: WatchUpdate) => void;
  onExpired?: (session: WatchSession) => void;
}

export class WatchManager {
  private config = getStrategy().watch_mode;
  private sessions: Map<string, WatchSession> = new Map();
  private updateInterval?: NodeJS.Timeout;
  private callbacks: WatchCallbacks = {};

  /**
   * Set callbacks
   */
  public setCallbacks(callbacks: WatchCallbacks): void {
    this.callbacks = callbacks;
  }

  /**
   * Start watch manager
   */
  public start(): void {
    if (this.updateInterval) return;

    logger.info('Starting watch manager');
    
    this.updateInterval = setInterval(
      () => this.processUpdates(),
      this.config.update_interval_seconds * 1000
    );
  }

  /**
   * Stop watch manager
   */
  public stop(): void {
    if (this.updateInterval) {
      clearInterval(this.updateInterval);
      this.updateInterval = undefined;
      logger.info('Watch manager stopped');
    }
  }

  /**
   * Create new watch session
   */
  public createSession(
    tokenAddress: string,
    tokenSymbol: string,
    metrics: TokenMetrics,
    chatId: string,
    userId: string,
    durationMinutes?: number
  ): WatchSession {
    const id = generateId();
    const now = Date.now();
    const duration = durationMinutes || this.config.default_duration_minutes;
    const maxDuration = this.config.max_duration_minutes;
    const actualDuration = Math.min(duration, maxDuration);

    const session: WatchSession = {
      id,
      tokenAddress,
      tokenSymbol,
      startedAt: now,
      expiresAt: now + actualDuration * 60000,
      chatId,
      userId,
      
      baselinePrice: metrics.priceUsd,
      baselineVolume24h: metrics.volume24h,
      baselineLiquidity: metrics.liquidityUsd,
      baselineHolders: metrics.buys24h + metrics.sells24h,
      
      lastUpdateAt: now,
      lastPrice: metrics.priceUsd,
      highestPrice: metrics.priceUsd,
      lowestPrice: metrics.priceUsd,
      
      alertCount: 0,
      lastAlertAt: 0,
      
      status: 'ACTIVE',
    };

    this.sessions.set(id, session);
    logger.info(`Created watch session for ${tokenSymbol} (${id})`);

    return session;
  }

  /**
   * Get session by ID
   */
  public getSession(id: string): WatchSession | undefined {
    return this.sessions.get(id);
  }

  /**
   * Get session by token address
   */
  public getSessionByToken(tokenAddress: string): WatchSession | undefined {
    for (const session of this.sessions.values()) {
      if (session.tokenAddress === tokenAddress && session.status === 'ACTIVE') {
        return session;
      }
    }
    return undefined;
  }

  /**
   * End session
   */
  public endSession(id: string): boolean {
    const session = this.sessions.get(id);
    if (!session) return false;

    session.status = 'EXPIRED';
    logger.info(`Ended watch session for ${session.tokenSymbol} (${id})`);
    
    return true;
  }

  /**
   * Process updates for all active sessions
   */
  private async processUpdates(): Promise<void> {
    const now = Date.now();

    for (const [id, session] of this.sessions.entries()) {
      // Check expiration
      if (now > session.expiresAt) {
        session.status = 'EXPIRED';
        this.callbacks.onExpired?.(session);
        continue;
      }

      // Skip non-active sessions
      if (session.status !== 'ACTIVE') {
        continue;
      }

      // Process would fetch current metrics and check for changes
      // This is a placeholder - actual implementation would need metric fetching
    }
  }

  /**
   * Process update for a session with new metrics
   */
  public processMetricUpdate(sessionId: string, metrics: TokenMetrics): WatchUpdate | null {
    const session = this.sessions.get(sessionId);
    if (!session || session.status !== 'ACTIVE') {
      return null;
    }

    // Calculate changes
    const changes = {
      priceChangePercent: (metrics.priceUsd - session.baselinePrice) / session.baselinePrice,
      volumeChangePercent: (metrics.volume24h - session.baselineVolume24h) / Math.max(session.baselineVolume24h, 1),
      liquidityChangePercent: (metrics.liquidityUsd - session.baselineLiquidity) / Math.max(session.baselineLiquidity, 1),
      holderChangePercent: ((metrics.buys24h + metrics.sells24h) - session.baselineHolders) / Math.max(session.baselineHolders, 1),
    };

    // Update session tracking
    session.lastUpdateAt = Date.now();
    session.lastPrice = metrics.priceUsd;
    session.highestPrice = Math.max(session.highestPrice, metrics.priceUsd);
    session.lowestPrice = Math.min(session.lowestPrice, metrics.priceUsd);

    // Check for significant changes
    const significant = this.isSignificantChange(changes);

    // Check for escalation
    const escalation = this.isEscalation(session, changes);

    // Check for exit signals
    const exitSignal = this.checkExitSignals(session, metrics, changes);

    const update: WatchUpdate = {
      session,
      currentMetrics: metrics,
      changes,
      significant,
      escalation,
      exitSignal: exitSignal || undefined,
    };

    // Trigger callbacks
    if (significant) {
      session.alertCount++;
      session.lastAlertAt = Date.now();
      this.callbacks.onSignificantChange?.(update);
    }

    if (escalation) {
      this.callbacks.onEscalation?.(update);
    }

    if (exitSignal?.shouldExit) {
      session.status = 'EXIT_SIGNALLED';
      this.callbacks.onExitSignal?.(update);
    }

    return update;
  }

  /**
   * Check if changes are significant
   */
  private isSignificantChange(changes: WatchUpdate['changes']): boolean {
    const thresholds = this.config.significant_change_thresholds;

    return (
      Math.abs(changes.priceChangePercent) >= thresholds.price_change_percent ||
      Math.abs(changes.volumeChangePercent) >= thresholds.volume_change_percent ||
      Math.abs(changes.liquidityChangePercent) >= thresholds.liquidity_change_percent ||
      Math.abs(changes.holderChangePercent) >= thresholds.holder_change_percent
    );
  }

  /**
   * Check for escalation conditions
   */
  private isEscalation(
    session: WatchSession,
    changes: WatchUpdate['changes']
  ): boolean {
    const escalation = this.config.escalation;

    // Profit target reached
    if (changes.priceChangePercent >= escalation.profit_target_percent) {
      return true;
    }

    // Stop loss triggered
    if (changes.priceChangePercent <= escalation.stop_loss_percent) {
      return true;
    }

    // Significant drawdown from peak
    const drawdown = (session.highestPrice - session.lastPrice) / session.highestPrice;
    if (drawdown >= escalation.stop_loss_percent * -1) {
      return true;
    }

    return false;
  }

  /**
   * Check for exit signals
   */
  private checkExitSignals(
    session: WatchSession,
    metrics: TokenMetrics,
    changes: WatchUpdate['changes']
  ): ExitSignal | null {
    // Check stop loss
    const stopLoss = exitEngine.checkStopLoss(changes.priceChangePercent);
    if (stopLoss.triggered) {
      return {
        shouldExit: true,
        urgency: 'HIGH',
        reasons: [stopLoss.message],
        triggers: {
          liquidityDrop: false,
          whaleExit: false,
          creatorSelling: false,
          volumeDecay: false,
          rugProbability: false,
        },
        metrics: {
          liquidityDropPercent: changes.liquidityChangePercent,
          volumeDecayPercent: changes.volumeChangePercent,
          rugProbabilityScore: 0,
          estimatedLossPercent: changes.priceChangePercent,
        },
        recommendedAction: 'EXIT - Stop loss triggered',
      };
    }

    // Check profit target
    const profitTarget = exitEngine.checkProfitTarget(changes.priceChangePercent);
    if (profitTarget.triggered) {
      return {
        shouldExit: true,
        urgency: 'MEDIUM',
        reasons: [profitTarget.message],
        triggers: {
          liquidityDrop: false,
          whaleExit: false,
          creatorSelling: false,
          volumeDecay: false,
          rugProbability: false,
        },
        metrics: {
          liquidityDropPercent: changes.liquidityChangePercent,
          volumeDecayPercent: changes.volumeChangePercent,
          rugProbabilityScore: 0,
          estimatedLossPercent: 0,
        },
        recommendedAction: 'CONSIDER EXIT - Profit target reached',
      };
    }

    return null;
  }

  /**
   * Get all active sessions
   */
  public getActiveSessions(): WatchSession[] {
    return Array.from(this.sessions.values()).filter(s => s.status === 'ACTIVE');
  }

  /**
   * Get all sessions
   */
  public getAllSessions(): WatchSession[] {
    return Array.from(this.sessions.values());
  }

  /**
   * Get active session count
   */
  public getActiveSessionCount(): number {
    return this.getActiveSessions().length;
  }

  /**
   * Get session count by status
   */
  public getSessionCountByStatus(): Record<WatchSession['status'], number> {
    const counts: Record<WatchSession['status'], number> = {
      ACTIVE: 0,
      PAUSED: 0,
      EXPIRED: 0,
      EXIT_SIGNALLED: 0,
    };

    for (const session of this.sessions.values()) {
      counts[session.status]++;
    }

    return counts;
  }

  /**
   * Pause session
   */
  public pauseSession(id: string): boolean {
    const session = this.sessions.get(id);
    if (!session || session.status !== 'ACTIVE') return false;

    session.status = 'PAUSED';
    logger.info(`Paused watch session for ${session.tokenSymbol} (${id})`);
    return true;
  }

  /**
   * Resume session
   */
  public resumeSession(id: string): boolean {
    const session = this.sessions.get(id);
    if (!session || session.status !== 'PAUSED') return false;

    session.status = 'ACTIVE';
    logger.info(`Resumed watch session for ${session.tokenSymbol} (${id})`);
    return true;
  }

  /**
   * Extend session duration
   */
  public extendSession(id: string, additionalMinutes: number): boolean {
    const session = this.sessions.get(id);
    if (!session) return false;

    const maxDuration = this.config.max_duration_minutes * 60000;
    const currentDuration = session.expiresAt - session.startedAt;
    const newDuration = Math.min(currentDuration + additionalMinutes * 60000, maxDuration);
    
    session.expiresAt = session.startedAt + newDuration;
    logger.info(`Extended watch session for ${session.tokenSymbol} (${id})`);
    return true;
  }

  /**
   * Cleanup expired sessions
   */
  public cleanup(): void {
    const now = Date.now();
    let cleaned = 0;

    for (const [id, session] of this.sessions.entries()) {
      // Remove sessions expired for more than 1 hour
      if (session.status === 'EXPIRED' && now - session.expiresAt > 3600000) {
        this.sessions.delete(id);
        cleaned++;
      }
    }

    if (cleaned > 0) {
      logger.info(`Cleaned up ${cleaned} expired watch sessions`);
    }
  }

  /**
   * Get session statistics
   */
  public getStatistics(): {
    totalSessions: number;
    activeSessions: number;
    expiredSessions: number;
    pausedSessions: number;
    exitSignalledSessions: number;
    totalAlertsSent: number;
  } {
    const byStatus = this.getSessionCountByStatus();
    
    return {
      totalSessions: this.sessions.size,
      activeSessions: byStatus.ACTIVE,
      expiredSessions: byStatus.EXPIRED,
      pausedSessions: byStatus.PAUSED,
      exitSignalledSessions: byStatus.EXIT_SIGNALLED,
      totalAlertsSent: Array.from(this.sessions.values()).reduce((sum, s) => sum + s.alertCount, 0),
    };
  }
}

// Export singleton instance
export const watchManager = new WatchManager();
