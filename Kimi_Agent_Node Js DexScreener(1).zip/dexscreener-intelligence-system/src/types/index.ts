/**
 * Core Type Definitions
 * 
 * Defines all data structures used throughout the intelligence system
 */

// ========================================================
// DEXSCREENER API TYPES
// ========================================================

export interface DexScreenerToken {
  chainId: string;
  dexId: string;
  url: string;
  pairAddress: string;
  baseToken: {
    address: string;
    name: string;
    symbol: string;
  };
  quoteToken: {
    address: string;
    name: string;
    symbol: string;
  };
  priceNative: string;
  priceUsd: string;
  txns: {
    m5: { buys: number; sells: number };
    h1: { buys: number; sells: number };
    h6: { buys: number; sells: number };
    h24: { buys: number; sells: number };
  };
  volume: {
    m5: number;
    h1: number;
    h6: number;
    h24: number;
  };
  priceChange: {
    m5: number;
    h1: number;
    h6: number;
    h24: number;
  };
  liquidityUsd: number;
  fdv: number;
  marketCap: number;
  pairCreatedAt: number;
  info?: {
    imageUrl?: string;
    websites?: { label: string; url: string }[];
    socials?: { type: string; url: string }[];
  };
}

export interface DexScreenerResponse {
  schemaVersion: string;
  pairs: DexScreenerToken[];
}

// ========================================================
// TOKEN ANALYSIS TYPES
// ========================================================

export interface TokenMetrics {
  address: string;
  symbol: string;
  name: string;
  chainId: string;
  
  // Price metrics
  priceUsd: number;
  priceChange5m: number;
  priceChange1h: number;
  priceChange24h: number;
  
  // Volume metrics
  volume5m: number;
  volume1h: number;
  volume24h: number;
  
  // Liquidity metrics
  liquidityUsd: number;
  marketCap: number;
  fdv: number;
  
  // Transaction metrics
  buys5m: number;
  sells5m: number;
  buys1h: number;
  sells1h: number;
  buys24h: number;
  sells24h: number;
  
  // Time metrics
  pairCreatedAt: number;
  ageMinutes: number;
  ageHours: number;
}

export interface HolderDistribution {
  totalHolders: number;
  top10Percentage: number;
  top50Percentage: number;
  growthRate1h: number;
  growthRate24h: number;
  uniqueBuyers1h: number;
  uniqueSellers1h: number;
}

export interface LiquidityAnalysis {
  totalLiquidityUsd: number;
  lockedLiquidityUsd: number;
  lockedPercentage: number;
  lockDurationDays: number;
  ownerPercentage: number;
  lpTokenDistribution: {
    topHolderPercentage: number;
    top5HoldersPercentage: number;
  };
}

// ========================================================
// ENGINE OUTPUT TYPES
// ========================================================

export interface RiskAssessment {
  score: number; // 0-1, higher = more risky
  level: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  factors: {
    liquidityConcentration: number;
    holderDistribution: number;
    priceVolatility: number;
    contractRisk: number;
    developerRisk: number;
  };
  warnings: string[];
}

export interface AuthenticityAssessment {
  score: number; // 0-1, higher = more authentic
  level: 'LOW' | 'MEDIUM' | 'HIGH' | 'EXCELLENT';
  factors: {
    liquidityLocked: number;
    contractVerified: number;
    socialPresence: number;
    websiteQuality: number;
    teamDoxxed: number;
  };
  checks: {
    hasLockedLiquidity: boolean;
    isContractVerified: boolean;
    hasSocialLinks: boolean;
    hasWebsite: boolean;
    lockDurationDays: number;
  };
}

export interface DeveloperReputation {
  score: number; // 0-1, higher = better reputation
  level: 'BLACKLIST' | 'SUSPICIOUS' | 'UNKNOWN' | 'GOOD' | 'EXCELLENT';
  history: {
    totalProjects: number;
    successfulProjects: number;
    rugPulls: number;
    averageProjectLifespanDays: number;
  };
  flags: string[];
}

export interface BuyQualityAssessment {
  score: number; // 0-1, higher = better buy quality
  level: 'POOR' | 'FAIR' | 'GOOD' | 'EXCELLENT';
  metrics: {
    buySellRatio: number;
    uniqueBuyersGrowth: number;
    tradeSizeDistribution: number;
    transactionConsistency: number;
  };
  patterns: {
    hasOrganicGrowth: boolean;
    hasWhaleAccumulation: boolean;
    hasBotActivity: boolean;
    hasPumpPattern: boolean;
  };
}

export interface WhaleActivity {
  detected: boolean;
  badge: 'NONE' | 'MEDIUM' | 'LARGE' | 'MEGA';
  activities: WhaleTransaction[];
  confidence: number;
  summary: {
    totalWhaleBuys: number;
    totalWhaleSells: number;
    netWhaleFlow: number;
    uniqueWhales: number;
  };
}

export interface WhaleTransaction {
  wallet: string;
  type: 'BUY' | 'SELL';
  amountUsd: number;
  timestamp: number;
  badge: 'NONE' | 'MEDIUM' | 'LARGE' | 'MEGA';
  portfolioValue?: number;
}

export interface ProbabilityAssessment {
  score: number; // 0-1, probability of success
  confidence: number; // 0-1, confidence in the prediction
  level: 'LOW' | 'MEDIUM' | 'HIGH' | 'VERY_HIGH';
  factors: {
    riskAdjusted: number;
    authenticityBoost: number;
    developerBoost: number;
    qualityBoost: number;
    whaleConfidence: number;
    timingScore: number;
  };
  timeframe: {
    shortTerm: number; // 0-1
    mediumTerm: number; // 0-1
    longTerm: number; // 0-1
  };
}

export interface ExitSignal {
  shouldExit: boolean;
  urgency: 'LOW' | 'MEDIUM' | 'HIGH' | 'IMMEDIATE';
  reasons: string[];
  triggers: {
    liquidityDrop: boolean;
    whaleExit: boolean;
    creatorSelling: boolean;
    volumeDecay: boolean;
    rugProbability: boolean;
  };
  metrics: {
    liquidityDropPercent: number;
    volumeDecayPercent: number;
    rugProbabilityScore: number;
    estimatedLossPercent: number;
  };
  recommendedAction: string;
}

export interface TokenRanking {
  rank: number;
  compositeScore: number;
  components: {
    probabilityScore: number;
    riskAdjustedReturn: number;
    momentumScore: number;
    whaleConfidence: number;
    timeSensitivity: number;
  };
  decision: 'ALERT' | 'SUPPRESS' | 'WATCH';
  suppressionReason?: string;
}

// ========================================================
// MARKET REGIME TYPES
// ========================================================

export type MarketRegimeType = 
  | 'BULL_LAUNCH_SEASON' 
  | 'NORMAL' 
  | 'HIGH_RUG_ACTIVITY' 
  | 'LOW_ACTIVITY';

export interface MarketRegime {
  currentRegime: MarketRegimeType;
  confidence: number;
  metrics: {
    rugRate24h: number;
    averageSurvivalTimeHours: number;
    launchFrequency: number;
    averageAuthenticity: number;
    whaleParticipationRate: number;
  };
  adaptations: {
    filterMultiplier: number;
    riskToleranceAdjustment: number;
    rankingAggressiveness: number;
  };
  since: number;
}

// ========================================================
// WATCH MODE TYPES
// ========================================================

export interface WatchSession {
  id: string;
  tokenAddress: string;
  tokenSymbol: string;
  startedAt: number;
  expiresAt: number;
  chatId: string;
  userId: string;
  
  // Baseline metrics
  baselinePrice: number;
  baselineVolume24h: number;
  baselineLiquidity: number;
  baselineHolders: number;
  
  // Current state
  lastUpdateAt: number;
  lastPrice: number;
  highestPrice: number;
  lowestPrice: number;
  
  // Alerts sent
  alertCount: number;
  lastAlertAt: number;
  
  // Status
  status: 'ACTIVE' | 'PAUSED' | 'EXPIRED' | 'EXIT_SIGNALLED';
}

export interface WatchUpdate {
  session: WatchSession;
  currentMetrics: TokenMetrics;
  changes: {
    priceChangePercent: number;
    volumeChangePercent: number;
    liquidityChangePercent: number;
    holderChangePercent: number;
  };
  significant: boolean;
  escalation: boolean;
  exitSignal?: ExitSignal;
}

// ========================================================
// ALERT TYPES
// ========================================================

export interface TokenAlert {
  id: string;
  timestamp: number;
  token: TokenMetrics;
  
  // Engine outputs
  risk: RiskAssessment;
  authenticity: AuthenticityAssessment;
  developer: DeveloperReputation;
  buyQuality: BuyQualityAssessment;
  whale: WhaleActivity;
  probability: ProbabilityAssessment;
  ranking: TokenRanking;
  
  // Market context
  regime: MarketRegime;
  
  // Alert metadata
  priority: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  sent: boolean;
  suppressed: boolean;
  suppressionReason?: string;
}

export interface ExitAlert {
  id: string;
  timestamp: number;
  originalAlertId: string;
  token: TokenMetrics;
  exitSignal: ExitSignal;
  currentPrice: number;
  priceChangeSinceAlert: number;
  sent: boolean;
}

// ========================================================
// SYSTEM HEALTH TYPES
// ========================================================

export interface SystemHealth {
  status: 'HEALTHY' | 'DEGRADED' | 'UNHEALTHY' | 'SAFE_MODE';
  timestamp: number;
  
  // Latency metrics
  latency: {
    api: number;
    rpc: number;
    overall: number;
  };
  
  // Error rates
  errorRates: {
    api: number;
    rpc: number;
    overall: number;
  };
  
  // Resource usage
  resources: {
    memoryUsagePercent: number;
    cpuUsagePercent: number;
    uptimeSeconds: number;
  };
  
  // Component status
  components: {
    dexApi: boolean;
    signalBot: boolean;
    alertBot: boolean;
    database: boolean;
  };
  
  // Safe mode
  safeMode: boolean;
  safeModeSince?: number;
  safeModeReason?: string;
}

export interface HealthCheckResult {
  healthy: boolean;
  degraded: boolean;
  checks: {
    name: string;
    passed: boolean;
    responseTime: number;
    error?: string;
  }[];
}

// ========================================================
// SELF-DEFENSE TYPES
// ========================================================

export interface SelfDefenseStatus {
  active: boolean;
  activatedAt?: number;
  reason?: string;
  
  metrics: {
    apiErrorRate: number;
    rpcErrorRate: number;
    averageLatency: number;
    memoryUsage: number;
    cpuUsage: number;
  };
  
  actions: {
    pollingIntervalIncreased: boolean;
    nonCriticalAlertsSuppressed: boolean;
    concurrentRequestsReduced: boolean;
  };
}

// ========================================================
// TELEGRAM INTERACTION TYPES
// ========================================================

export interface TelegramCallbackData {
  action: 'refresh' | 'watch' | 'unwatch' | 'exit' | 'ping';
  tokenAddress: string;
  userId: string;
  timestamp: number;
}

export interface BotCommand {
  command: string;
  description: string;
  handler: (msg: any, match: any) => Promise<void>;
}

export interface AlertMessage {
  text: string;
  options: {
    parse_mode?: string;
    reply_markup?: {
      inline_keyboard: Array<Array<{
        text: string;
        callback_data: string;
      }>>;
    };
  };
}

// ========================================================
// METRICS TYPES
// ========================================================

export interface SystemMetrics {
  timestamp: number;
  
  // Token processing
  tokensProcessed: number;
  tokensFiltered: number;
  alertsGenerated: number;
  alertsSent: number;
  alertsSuppressed: number;
  
  // Engine performance
  engineLatencies: {
    risk: number;
    authenticity: number;
    developer: number;
    buyQuality: number;
    whale: number;
    probability: number;
    ranking: number;
  };
  
  // Watch mode
  activeWatchSessions: number;
  watchUpdatesSent: number;
  
  // System
  memoryUsage: number;
  cpuUsage: number;
  eventLoopLag: number;
}

// ========================================================
// UTILITY TYPES
// ========================================================

export interface TimeWindow {
  start: number;
  end: number;
  duration: number;
}

export interface CachedData<T> {
  data: T;
  cachedAt: number;
  expiresAt: number;
  ttl: number;
}

export interface Result<T, E = Error> {
  success: boolean;
  data?: T;
  error?: E;
}

export interface PaginatedResult<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
  hasMore: boolean;
}
