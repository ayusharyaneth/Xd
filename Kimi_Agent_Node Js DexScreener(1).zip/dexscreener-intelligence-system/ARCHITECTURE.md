# System Architecture

## Overview

The DexScreener Intelligence System is a production-grade, event-driven architecture designed for real-time cryptocurrency token analysis. The system follows clean architecture principles with clear separation of concerns.

## Design Principles

1. **Single Responsibility** - Each engine and component has a specific purpose
2. **Open/Closed** - Engines are open for extension, closed for modification
3. **Dependency Inversion** - High-level modules depend on abstractions
4. **Configuration-Driven** - All thresholds and weights are externalized
5. **Fail-Safe** - System degrades gracefully under stress

## Component Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           PRESENTATION LAYER                                 │
│  ┌─────────────────────┐    ┌─────────────────────┐                         │
│  │    Signal Bot       │    │    Alert Bot        │                         │
│  │  (User Interface)   │    │  (System Alerts)    │                         │
│  └──────────┬──────────┘    └──────────┬──────────┘                         │
└─────────────┼──────────────────────────┼────────────────────────────────────┘
              │                          │
              ▼                          ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                         APPLICATION LAYER                                    │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                    DexScreenerIntelligenceSystem                     │    │
│  │                    (Main Orchestrator)                               │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                    │                                         │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                      Watch Manager                                   │    │
│  │  - Session lifecycle management    - Significant change detection    │    │
│  │  - Escalation handling             - Exit signal processing          │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────────────────┘
              │
              ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                          DOMAIN LAYER (Engines)                              │
│                                                                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐    │
│  │ Risk Engine  │  │Authenticity  │  │  Developer   │  │ Buy Quality  │    │
│  │              │  │   Engine     │  │   Engine     │  │   Engine     │    │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘    │
│         │                 │                 │                 │              │
│  ┌──────┴───────┐  ┌──────┴───────┐  ┌──────┴───────┐  ┌──────┴───────┐    │
│  │ Whale Engine │  │Probability   │  │  Exit Engine │  │Ranking Engine│    │
│  │              │  │   Engine     │  │              │  │              │    │
│  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘    │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                    Market Regime Analyzer                            │    │
│  │  - Regime classification    - Dynamic parameter adaptation          │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────────────────┘
              │
              ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                      INFRASTRUCTURE LAYER                                    │
│                                                                              │
│  ┌─────────────────────┐  ┌─────────────────────┐  ┌─────────────────────┐  │
│  │   DexScreener API   │  │  Self-Defense Mgr   │  │   Health Monitor    │  │
│  │      Client         │  │                     │  │                     │  │
│  └─────────────────────┘  └─────────────────────┘  └─────────────────────┘  │
│                                                                              │
│  ┌─────────────────────┐  ┌─────────────────────┐  ┌─────────────────────┐  │
│  │   Metrics Collector │  │  Configuration Mgr  │  │   Cache Manager     │  │
│  │                     │  │                     │  │                     │  │
│  └─────────────────────┘  └─────────────────────┘  └─────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Data Flow

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│  DexScreener │────▶│   Filter    │────▶│   Engines   │────▶│   Ranking   │
│     API      │     │   Engine    │     │  (Parallel) │     │   Engine    │
└─────────────┘     └─────────────┘     └─────────────┘     └──────┬──────┘
                                                                    │
                                                                    ▼
┌─────────────┐     ┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│   Telegram  │◀────│  Format &   │◀────│   Regime    │◀────│   Buffer &  │
│    Users    │     │   Send      │     │   Adapt     │     │    Rank     │
└─────────────┘     └─────────────┘     └─────────────┘     └─────────────┘
```

## Engine Details

### Risk Engine

**Purpose**: Assess token risk across multiple dimensions

**Inputs**:
- Token metrics (price, volume, liquidity)
- Holder distribution
- Liquidity analysis

**Outputs**:
- Risk score (0-1)
- Risk level (LOW/MEDIUM/HIGH/CRITICAL)
- Warning list

**Algorithm**:
```
Risk Score = 
  LiquidityConcentration × 0.25 +
  HolderDistribution × 0.20 +
  PriceVolatility × 0.20 +
  ContractRisk × 0.20 +
  DeveloperRisk × 0.15
```

### Authenticity Engine

**Purpose**: Evaluate token legitimacy

**Factors**:
- Liquidity locking (30%)
- Contract verification (25%)
- Social presence (20%)
- Website quality (15%)
- Team doxxing (10%)

### Probability Engine

**Purpose**: Calculate success probability

**Formula**:
```
Probability = 
  RiskAdjusted × 0.20 +
  Authenticity × 0.20 +
  DeveloperRep × 0.15 +
  BuyQuality × 0.15 +
  WhaleConfidence × 0.15 +
  MarketTiming × 0.15
```

### Ranking Engine

**Purpose**: Rank and filter alerts

**Composite Score**:
```
Score =
  Probability × 0.30 +
  RiskAdjustedReturn × 0.25 +
  Momentum × 0.20 +
  WhaleConfidence × 0.15 +
  TimeSensitivity × 0.10
```

**Features**:
- Rolling window buffering
- Time decay (half-life: 30 min)
- Top N selection
- Suppression of lower-ranked alerts

## Market Regime Analysis

### Regime Types

| Regime | Rug Rate | Whale Part. | Adaptation |
|--------|----------|-------------|------------|
| BULL_LAUNCH_SEASON | <15% | >60% | +20% risk tolerance |
| NORMAL | <25% | >40% | Default |
| HIGH_RUG_ACTIVITY | >30% | <30% | -20% risk tolerance |
| LOW_ACTIVITY | N/A | N/A | Selective |

### Adaptation Parameters

```typescript
interface RegimeAdaptations {
  filterMultiplier: number;      // Adjust filter thresholds
  riskToleranceAdjustment: number; // Shift risk acceptance
  rankingAggressiveness: number;   // Adjust ranking weights
}
```

## Self-Defense System

### Monitored Metrics

- API error rate (>20% threshold)
- RPC error rate (>30% threshold)
- Latency (>5000ms threshold)
- Memory usage (>85% threshold)
- CPU usage (>90% threshold)

### Safe Mode Actions

1. Increase polling interval (2x)
2. Suppress non-critical alerts
3. Reduce concurrent requests
4. Notify Alert Bot
5. Auto-recovery after 5 consecutive healthy checks

## Watch Mode Architecture

### Session Lifecycle

```
CREATED → ACTIVE → [PAUSED] → [EXPIRED/EXIT_SIGNALLED]
```

### Update Triggers

- **Significant Change**: Price ±10%, Volume ±50%, Liquidity ±20%
- **Escalation**: Profit target +50%, Stop loss -20%
- **Exit Signal**: Any exit condition met

### Callback System

```typescript
interface WatchCallbacks {
  onSignificantChange: (update: WatchUpdate) => void;
  onEscalation: (update: WatchUpdate) => void;
  onExitSignal: (update: WatchUpdate) => void;
  onExpired: (session: WatchSession) => void;
}
```

## Configuration Model

### Hybrid Configuration

```
┌─────────────────┐     ┌─────────────────┐
│   strategy.yaml │     │      .env       │
│  (Thresholds &  │────▶│  (Secrets &     │
│    Weights)     │     │   Overrides)    │
└─────────────────┘     └─────────────────┘
           │                     │
           └──────────┬──────────┘
                      ▼
            ┌─────────────────┐
            │  Config Manager │
            │  (Merged Config)│
            └─────────────────┘
```

### Priority

1. Environment variables (highest)
2. strategy.yaml
3. Default values (lowest)

## Error Handling Strategy

### Levels

1. **Component Level**: Catch and log, continue operation
2. **Engine Level**: Return partial results with confidence reduction
3. **System Level**: Activate safe mode if thresholds exceeded
4. **Critical**: Shutdown gracefully

### Retry Policy

```typescript
interface RetryConfig {
  maxRetries: 3;
  baseDelayMs: 1000;
  backoffMultiplier: 2;
  maxDelayMs: 10000;
}
```

## Performance Considerations

### Caching Strategy

| Cache Type | TTL | Purpose |
|------------|-----|---------|
| Token Cache | 15s | API response caching |
| Analysis Cache | 60s | Engine result caching |
| Whale Cache | 120s | Whale data caching |

### Concurrency

- Max concurrent API requests: 5
- Engine parallelization: Enabled
- Request queue: FIFO with priority

### Memory Management

- Max heap size: 1GB (configurable)
- Periodic garbage collection hints
- Cache size limits with LRU eviction

## Security Architecture

### Secrets Management

- All secrets in `.env` file
- `.env` excluded from version control
- Environment-specific configurations

### API Security

- Rate limiting on DexScreener API
- Request timeouts (10s default)
- Retry with exponential backoff

### Telegram Security

- Separate bots for signals and alerts
- Chat ID validation
- Command authorization (admin users)

## Deployment Architecture

### Production Setup

```
┌─────────────────────────────────────────┐
│           Ubuntu VPS                    │
│  ┌─────────────────────────────────┐    │
│  │  PM2 Process Manager            │    │
│  │  ┌─────────────────────────┐    │    │
│  │  │  DexIntel Application   │    │    │
│  │  │  (Node.js/TypeScript)   │    │    │
│  │  └─────────────────────────┘    │    │
│  └─────────────────────────────────┘    │
│  ┌─────────────────────────────────┐    │
│  │  Log Rotation (pm2-logrotate)   │    │
│  └─────────────────────────────────┘    │
│  ┌─────────────────────────────────┐    │
│  │  Nginx (optional, for metrics)  │    │
│  └─────────────────────────────────┘    │
└─────────────────────────────────────────┘
```

### Monitoring Stack

- **PM2**: Process monitoring
- **Built-in metrics**: Memory, CPU, latency
- **Health endpoint**: `/ping` command
- **Optional**: Prometheus metrics export

## Scalability Considerations

### Horizontal Scaling

- Stateless design allows multiple instances
- Shared configuration via environment
- Independent processing per instance

### Vertical Scaling

- Increase memory for larger buffers
- More CPU cores for parallel engines
- Faster disk for log writing

## Future Enhancements

1. **Database Integration**: Persist alerts and history
2. **Machine Learning**: Train models on historical data
3. **Web Dashboard**: Visual analytics interface
4. **Multi-Exchange**: Support for additional DEXs
5. **Social Sentiment**: Integrate Twitter/Telegram sentiment

---

**Version**: 1.0.0  
**Last Updated**: 2024
