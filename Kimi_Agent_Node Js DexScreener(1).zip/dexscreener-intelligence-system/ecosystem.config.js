/**
 * PM2 Ecosystem Configuration
 * 
 * Production-grade process management for DexScreener Intelligence System
 */

module.exports = {
  apps: [{
    // Application name
    name: 'dexintel',
    
    // Entry point
    script: './dist/index.js',
    
    // Process configuration
    instances: 1,
    exec_mode: 'fork',
    
    // Auto-restart configuration
    autorestart: true,
    watch: false,
    
    // Memory management
    max_memory_restart: '1G',
    
    // Environment variables
    env: {
      NODE_ENV: 'production',
      LOG_LEVEL: 'info'
    },
    
    // Logging configuration
    log_file: './logs/combined.log',
    out_file: './logs/out.log',
    error_file: './logs/error.log',
    log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
    merge_logs: true,
    
    // Process lifecycle
    kill_timeout: 5000,
    listen_timeout: 10000,
    max_restarts: 10,
    min_uptime: '10s',
    
    // Error handling
    restart_delay: 4000,
    exp_backoff_restart_delay: 100,
    
    // Monitoring
    monitoring: true,
    
    // Source map support for TypeScript
    source_map_support: true,
    
    // Node.js arguments
    node_args: [
      '--max-old-space-size=1024',
      '--optimize-for-size'
    ]
  }],
  
  // Deployment configuration (optional)
  deploy: {
    production: {
      user: 'dexintel',
      host: ['your-vps-ip'],
      ref: 'origin/main',
      repo: 'git@github.com:yourusername/dexscreener-intelligence-system.git',
      path: '/var/www/dexintel',
      'post-deploy': 'npm install && npm run build && pm2 reload ecosystem.config.js --env production',
      'pre-setup': 'apt-get update && apt-get install -y git nodejs npm',
      'post-setup': 'ln -s /var/www/dexintel/source/strategy.yaml /var/www/dexintel/shared/strategy.yaml'
    }
  }
};
