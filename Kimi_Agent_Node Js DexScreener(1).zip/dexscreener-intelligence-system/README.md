# DexScreener Intelligence System

A production-grade, adaptive intelligence system for monitoring newly listed tokens on DexScreener. Features multi-engine analysis, whale detection, smart exit signals, market regime adaptation, and interactive Telegram integration.

## Table of Contents

- [Architecture Overview](#architecture-overview)
- [Features](#features)
- [Intelligence Engines](#intelligence-engines)
- [Installation](#installation)
- [Configuration](#configuration)
- [Deployment](#deployment)
- [Telegram Commands](#telegram-commands)
- [API Reference](#api-reference)
- [Security](#security)
- [Troubleshooting](#troubleshooting)

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                    DEXSCREENER INTELLIGENCE SYSTEM              │
├─────────────────────────────────────────────────────────────────┤
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐             │
│  │  DexScreener│  │    RPC      │  │   Telegram  │  External   │
│  │    API      │  │  (Optional) │  │     API     │  Services   │
│  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘             │
├─────────┼────────────────┼────────────────┼────────────────────┤
│         ▼                ▼                ▼                    │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                    API CLIENT LAYER                      │   │
│  └─────────────────────────────────────────────────────────┘   │
│         ▼                                                      │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                   INTELLIGENCE ENGINES                   │   │
│  │  ┌────────┐ ┌────────────┐ ┌──────────┐ ┌──────────┐   │   │
│  │  │  Risk  │ │Authenticity│ │Developer │ │BuyQuality│   │   │
│  │  └───┬────┘ └─────┬──────┘ └────┬─────┘ └────┬─────┘   │   │
│  │      └─────────────┴─────────────┴────────────┘         │   │
│  │                         ▼                               │   │
│  │  ┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐           │   │
│  │  │  Whale │ │Probability│ │  Exit  │ │Ranking │           │   │
│  │  └────────┘ └────────┘ └────────┘ └────────┘           │   │
│  └─────────────────────────────────────────────────────────┘   │
│         ▼                                                      │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │              MARKET REGIME ANALYZER                      │   │
│  └─────────────────────────────────────────────────────────┘   │
│         ▼                                                      │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │  ┌────────────┐  ┌────────────┐  ┌────────────┐        │   │
│  │  │Watch Manager│  │Self-Defense│  │Health Monitor│        │   │
│  │  └────────────┘  └────────────┘  └────────────┘        │   │
│  └─────────────────────────────────────────────────────────┘   │
│         ▼                                                      │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                   TELEGRAM BOTS                          │   │
│  │  ┌─────────────┐        ┌─────────────┐                 │   │
│  │  │  Signal Bot │        │  Alert Bot  │                 │   │
│  │  │  (Alerts)   │        │  (System)   │                 │   │
│  │  └─────────────┘        └─────────────┘                 │   │
│  └─────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
```

## Features

### Core Capabilities

- **Real-time Token Monitoring**: Continuously scans DexScreener for newly listed tokens
- **Multi-Engine Analysis**: 9 specialized engines analyze different aspects of each token
- **Whale Detection**: Identifies large wallet activity and accumulation/exit patterns
- **Smart Exit Assistant**: Detects exit conditions before major losses
- **Alert Ranking**: Buffers and ranks alerts to prevent spam
- **Market Regime Adaptation**: Dynamically adjusts strategy based on market conditions
- **Watch Mode**: Interactive token monitoring with periodic updates
- **Self-Defense Protection**: Monitors system health and activates safe mode when needed
- **Dual Telegram Bots**: Separate bots for signals and system alerts

### Intelligence Engines

| Engine | Purpose | Output |
|--------|---------|--------|
| Risk Engine | Assess token risk | Risk score (0-1), risk level, warnings |
| Authenticity Engine | Evaluate token legitimacy | Authenticity score, verification checks |
| Developer Engine | Analyze developer reputation | Reputation score, history, flags |
| Buy Quality Engine | Assess buying patterns | Quality score, pattern detection |
| Whale Engine | Detect whale activity | Whale badge, activity summary |
| Probability Engine | Calculate success probability | Probability score, confidence, projections |
| Exit Engine | Detect exit conditions | Exit signals with urgency levels |
| Ranking Engine | Rank and filter alerts | Composite score, decision |
| Regime Analyzer | Classify market conditions | Market regime, adaptations |

## Installation

### Prerequisites

- Node.js 18+ (LTS recommended)
- npm or yarn
- Telegram Bot Tokens (2 bots)
- Ubuntu VPS (recommended for production)

### Local Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/dexscreener-intelligence-system.git
cd dexscreener-intelligence-system

# Install dependencies
npm install

# Copy environment template
cp .env.example .env

# Edit configuration
nano .env

# Build the project
npm run build

# Start the system
npm start
```

### Development Mode

```bash
# Run in development mode with hot reload
npm run dev
```

## Configuration

### Environment Variables (.env)

```env
# Telegram Bot Configuration
SIGNAL_BOT_TOKEN=your_signal_bot_token_here
ALERT_BOT_TOKEN=your_alert_bot_token_here
SIGNAL_CHAT_ID=your_signal_chat_id
ALERT_CHAT_ID=your_alert_chat_id

# API Configuration
DEXSCREENER_API_URL=https://api.dexscreener.com/latest/dex/tokens
DEXSCREENER_RATE_LIMIT_MS=1000

# System Configuration
NODE_ENV=production
LOG_LEVEL=info
STRATEGY_CONFIG_PATH=./strategy.yaml

# Feature Flags
WHALE_DETECTION_ENABLED=true
EXIT_ASSISTANT_ENABLED=true
SELF_DEFENSE_ENABLED=true
MARKET_REGIME_ANALYSIS_ENABLED=true
```

### Strategy Configuration (strategy.yaml)

The `strategy.yaml` file contains all thresholds, weights, and parameters. Key sections:

#### Filtering Thresholds
```yaml
filters:
  liquidity:
    min_usd: 10000      # Minimum liquidity
    max_usd: 10000000   # Maximum liquidity
  market_cap:
    min_usd: 50000
    max_usd: 500000000
  age:
    max_token_age_hours: 72
    min_token_age_minutes: 5
```

#### Engine Weights
```yaml
probability_engine:
  weights:
    risk_score: 0.20
    authenticity_score: 0.20
    developer_score: 0.15
    buy_quality_score: 0.15
    whale_confidence: 0.15
    market_timing: 0.15
```

#### Market Regime Adaptations
```yaml
market_regime:
  adaptations:
    BULL_LAUNCH_SEASON:
      filter_multiplier: 1.2
      risk_tolerance_boost: 0.10
      ranking_aggressiveness: 1.3
```

## Deployment

### Ubuntu VPS Setup

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js 18
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install PM2 globally
sudo npm install -g pm2

# Create app directory
mkdir -p /var/www/dexintel
cd /var/www/dexintel

# Clone and setup
git clone <your-repo> .
npm install
npm run build

# Setup environment
nano .env

# Start with PM2
pm2 start dist/index.js --name dexintel
pm2 save
pm2 startup
```

### PM2 Configuration (ecosystem.config.js)

```javascript
module.exports = {
  apps: [{
    name: 'dexintel',
    script: './dist/index.js',
    instances: 1,
    exec_mode: 'fork',
    autorestart: true,
    watch: false,
    max_memory_restart: '1G',
    env: {
      NODE_ENV: 'production',
      LOG_LEVEL: 'info'
    },
    log_file: './logs/combined.log',
    out_file: './logs/out.log',
    error_file: './logs/error.log',
    log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
    merge_logs: true,
    kill_timeout: 5000,
    listen_timeout: 10000,
    max_restarts: 10,
    min_uptime: '10s'
  }]
};
```

### Log Rotation

```bash
# Setup PM2 log rotation
pm2 install pm2-logrotate

# Configure
pm2 set pm2-logrotate:max_size 100M
pm2 set pm2-logrotate:retain 10
pm2 set pm2-logrotate:compress true
pm2 set pm2-logrotate:dateFormat YYYY-MM-DD_HH-mm-ss
```

## Telegram Commands

### Signal Bot Commands

| Command | Description |
|---------|-------------|
| `/ping` | Check system health and status |
| `/status` | Get detailed system status |
| `/regime` | View current market regime analysis |
| `/watches` | List active watch sessions |
| `/help` | Show help message |

### Alert Interactions

- **🔄 Refresh** - Get updated token analysis
- **👁 Watch** - Start watching token for changes

## Intelligence Engine Explanations

### Risk Engine

The Risk Engine assesses token risk across 5 dimensions:

1. **Liquidity Concentration** - Measures how concentrated liquidity is among few holders
2. **Holder Distribution** - Analyzes the distribution of token holders
3. **Price Volatility** - Evaluates price stability and volatility patterns
4. **Contract Risk** - Assesses smart contract risk indicators
5. **Developer Risk** - Evaluates developer-related risk signals

**Output**: Risk score (0-1), risk level (LOW/MEDIUM/HIGH/CRITICAL), warnings

### Authenticity Engine

Evaluates token legitimacy based on:

- Liquidity locking status and duration
- Contract verification
- Social media presence (Twitter, Telegram, Discord)
- Website quality and sections
- Team doxxing status

**Output**: Authenticity score (0-1), verification checks

### Exit Assistant

Detects exit conditions:

- **Liquidity Drop** - Significant liquidity withdrawal (>30%)
- **Whale Exit** - Major whale selling detected
- **Creator Selling** - Developer wallet selling
- **Volume Decay** - Trading volume decline (>50%)
- **Rug Probability** - High risk score threshold exceeded

**Output**: Exit signal with urgency (LOW/MEDIUM/HIGH/IMMEDIATE)

### Ranking Engine

Ranks tokens using composite scoring:

```
Composite Score = 
  Probability Score × 0.30 +
  Risk-Adjusted Return × 0.25 +
  Momentum Score × 0.20 +
  Whale Confidence × 0.15 +
  Time Sensitivity × 0.10
```

**Features**:
- Rolling window buffering
- Top N selection
- Suppression of lower-ranked alerts
- Time decay for older signals

### Market Regime Analyzer

Classifies market into 4 regimes:

| Regime | Characteristics | Adaptation |
|--------|----------------|------------|
| BULL_LAUNCH_SEASON | Low rug rate, high whale participation | Increase risk tolerance |
| NORMAL | Standard conditions | Default parameters |
| HIGH_RUG_ACTIVITY | Elevated rug rate, low survival | Reduce risk tolerance |
| LOW_ACTIVITY | Few launches, low volume | Selective approach |

## Watch Mode

Watch mode provides continuous monitoring of specific tokens:

### Features

- **Periodic Updates** - Configurable update interval (default: 5 minutes)
- **Significant Change Detection** - Alerts on price/volume/liquidity changes
- **Escalation Alerts** - Profit target or stop loss triggers
- **Auto-Exit** - Optional automatic exit on signals
- **Session Expiration** - Automatic cleanup after duration

### Callback Data Format

```
refresh:<token_address>
watch:<token_address>:<token_symbol>
unwatch:<session_id>
```

## Self-Defense Mode

Monitors system health and activates safe mode when thresholds exceeded:

### Monitored Metrics

- API error rate (>20%)
- RPC error rate (>30%)
- Latency (>5000ms)
- Memory usage (>85%)
- CPU usage (>90%)

### Safe Mode Actions

- Increase polling interval (2x)
- Suppress non-critical alerts
- Reduce concurrent requests
- Notify Alert Bot

### Recovery

- Auto-recovery when metrics improve
- Consecutive healthy checks required (default: 5)

## Health Monitor (/ping)

The `/ping` command returns:

```json
{
  "status": "HEALTHY",
  "latency": 150,
  "regime": "NORMAL",
  "safeMode": false,
  "errorRate": 0.02,
  "activeWatches": 5,
  "uptime": "2d 14h 32m",
  "version": "1.0.0"
}
```

### Status Levels

- **HEALTHY** - All systems operational
- **DEGRADED** - Minor issues detected
- **UNHEALTHY** - Significant problems
- **SAFE_MODE** - Self-defense activated

## Security Considerations

### Environment Variables

- Never commit `.env` to version control
- Use strong, unique bot tokens
- Restrict chat IDs to authorized users

### Telegram Bot Security

- Use separate bots for signals and alerts
- Enable privacy mode on bots
- Restrict bot commands to specific chats

### System Security

- Run as non-root user
- Use firewall (ufw) to restrict ports
- Keep Node.js and dependencies updated
- Monitor logs for suspicious activity

### Recommended Firewall Rules

```bash
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow ssh
sudo ufw allow 9090/tcp  # Metrics port (if enabled)
sudo ufw enable
```

## Troubleshooting

### Common Issues

#### Bot Not Responding

```bash
# Check bot status
pm2 status

# View logs
pm2 logs dexintel

# Test bot connection
curl -s "https://api.telegram.org/bot<TOKEN>/getMe"
```

#### High Memory Usage

```bash
# Check memory usage
pm2 monit

# Restart if needed
pm2 restart dexintel

# Adjust max memory in ecosystem.config.js
max_memory_restart: '2G'
```

#### API Rate Limiting

- Increase `DEXSCREENER_RATE_LIMIT_MS` in .env
- Check for excessive polling
- Verify no other apps using same API key

#### Safe Mode Activation

Check logs for:
```
Self-Defense: Activating safe mode due to...
```

Common causes:
- DexScreener API issues
- Network connectivity problems
- High system load

### Log Locations

```
logs/
├── combined.log    # All logs
├── out.log         # stdout
├── error.log       # stderr
└── pm2/           # PM2 logs
```

### Debug Mode

```bash
# Enable debug logging
LOG_LEVEL=debug npm start
```

## API Reference

### DexScreenerClient

```typescript
// Fetch new pairs
const tokens = await dexScreenerClient.getNewPairs();

// Get token by address
const token = await dexScreenerClient.getTokenByAddress(chainId, address);

// Search tokens
const results = await dexScreenerClient.searchTokens('query');
```

### Watch Manager

```typescript
// Create watch session
const session = watchManager.createSession(
  tokenAddress,
  tokenSymbol,
  metrics,
  chatId,
  userId,
  durationMinutes
);

// Get active sessions
const sessions = watchManager.getActiveSessions();
```

## License

MIT License - See LICENSE file for details

## Contributing

Contributions welcome! Please:

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Open a Pull Request

## Support

For support, please:

1. Check this README and troubleshooting section
2. Review logs for error messages
3. Open an issue on GitHub

## Disclaimer

This system is for educational and research purposes only. Cryptocurrency trading carries significant risk. Always do your own research and never invest more than you can afford to lose.

---

**Version**: 1.0.0  
**Last Updated**: 2024
