# Deployment Guide

Complete guide for deploying DexScreener Intelligence System on Ubuntu VPS.

## Table of Contents

- [Prerequisites](#prerequisites)
- [Server Setup](#server-setup)
- [Application Deployment](#application-deployment)
- [PM2 Configuration](#pm2-configuration)
- [Log Rotation](#log-rotation)
- [SSL/TLS (Optional)](#ssltls-optional)
- [Monitoring](#monitoring)
- [Backup](#backup)
- [Updates](#updates)
- [Troubleshooting](#troubleshooting)

## Prerequisites

### Required

- Ubuntu 20.04+ VPS (2GB RAM minimum, 4GB recommended)
- Domain name (optional, for metrics endpoint)
- Telegram Bot Tokens (2 bots)
- SSH access to server

### Recommended VPS Providers

- DigitalOcean
- Linode
- Vultr
- AWS EC2
- Hetzner

## Server Setup

### 1. Initial Server Setup

```bash
# Login as root
ssh root@your-server-ip

# Create user
adduser dexintel
usermod -aG sudo dexintel

# Setup firewall
ufw default deny incoming
ufw default allow outgoing
ufw allow ssh
ufw allow 9090/tcp  # Metrics port
ufw enable

# Switch to new user
su - dexintel
```

### 2. Install Node.js

```bash
# Install Node.js 18 LTS
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Verify installation
node --version  # Should show v18.x.x
npm --version
```

### 3. Install PM2

```bash
# Install PM2 globally
sudo npm install -g pm2

# Setup PM2 startup script
pm2 startup systemd

# Run the command output by pm2 startup
sudo env PATH=$PATH:/usr/bin pm2 startup systemd -u dexintel --hp /home/dexintel
```

### 4. Install Git

```bash
sudo apt-get update
sudo apt-get install -y git
```

## Application Deployment

### 1. Create Application Directory

```bash
sudo mkdir -p /var/www/dexintel
sudo chown dexintel:dexintel /var/www/dexintel
cd /var/www/dexintel
```

### 2. Clone Repository

```bash
# Clone your repository
git clone https://github.com/yourusername/dexscreener-intelligence-system.git .

# Or use SSH for private repos
git clone git@github.com:yourusername/dexscreener-intelligence-system.git .
```

### 3. Install Dependencies

```bash
cd /var/www/dexintel
npm install
```

### 4. Build Application

```bash
# Compile TypeScript
npm run build

# Verify build
ls -la dist/
```

### 5. Configure Environment

```bash
# Create .env file
nano /var/www/dexintel/.env
```

Add your configuration:

```env
# Telegram Bot Configuration
SIGNAL_BOT_TOKEN=your_signal_bot_token_here
ALERT_BOT_TOKEN=your_alert_bot_token_here
SIGNAL_CHAT_ID=your_signal_chat_id
ALERT_CHAT_ID=your_alert_chat_id

# API Configuration
DEXSCREENER_API_URL=https://api.dexscreener.com/latest/dex/tokens
DEXSCREENER_RATE_LIMIT_MS=1000

# System Configuration
NODE_ENV=production
LOG_LEVEL=info
STRATEGY_CONFIG_PATH=./strategy.yaml

# Feature Flags
WHALE_DETECTION_ENABLED=true
EXIT_ASSISTANT_ENABLED=true
SELF_DEFENSE_ENABLED=true
MARKET_REGIME_ANALYSIS_ENABLED=true
```

### 6. Configure Strategy

```bash
# Review and customize strategy
nano /var/www/dexintel/strategy.yaml
```

### 7. Create Log Directory

```bash
mkdir -p /var/www/dexintel/logs
```

## PM2 Configuration

### 1. Copy PM2 Config

```bash
# The ecosystem.config.js is already in the project root
# Review and customize if needed
nano /var/www/dexintel/ecosystem.config.js
```

### 2. Start Application

```bash
cd /var/www/dexintel
pm2 start ecosystem.config.js
```

### 3. Save PM2 Configuration

```bash
# Save current process list
pm2 save

# The startup script was already created during setup
# If not, run:
# pm2 startup systemd
```

### 4. Verify Status

```bash
# Check application status
pm2 status

# View logs
pm2 logs dexintel

# Monitor in real-time
pm2 monit
```

## Log Rotation

### 1. Install PM2 Log Rotate

```bash
pm2 install pm2-logrotate
```

### 2. Configure Log Rotation

```bash
# Set max log size (100MB)
pm2 set pm2-logrotate:max_size 100M

# Keep 10 rotated logs
pm2 set pm2-logrotate:retain 10

# Compress rotated logs
pm2 set pm2-logrotate:compress true

# Date format for rotated logs
pm2 set pm2-logrotate:dateFormat YYYY-MM-DD_HH-mm-ss

# Rotate interval (optional)
pm2 set pm2-logrotate:rotateInterval '0 0 * * *'
```

### 3. Verify Configuration

```bash
pm2 conf pm2-logrotate
```

## SSL/TLS (Optional)

If exposing metrics endpoint publicly:

### 1. Install Nginx

```bash
sudo apt-get install -y nginx
```

### 2. Obtain SSL Certificate

```bash
sudo apt-get install -y certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com
```

### 3. Configure Nginx

```bash
sudo nano /etc/nginx/sites-available/dexintel
```

```nginx
server {
    listen 443 ssl;
    server_name your-domain.com;

    ssl_certificate /etc/letsencrypt/live/your-domain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/your-domain.com/privkey.pem;

    location /metrics {
        proxy_pass http://localhost:9090;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        
        # Optional: Add basic auth
        auth_basic "Metrics";
        auth_basic_user_file /etc/nginx/.htpasswd;
    }
}
```

```bash
sudo ln -s /etc/nginx/sites-available/dexintel /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

## Monitoring

### PM2 Monitoring

```bash
# Real-time monitoring
pm2 monit

# List processes
pm2 list

# Show process details
pm2 show dexintel

# View logs
pm2 logs dexintel
pm2 logs dexintel --lines 100
```

### System Monitoring

```bash
# Install htop
sudo apt-get install -y htop

# Monitor system resources
htop

# Check disk usage
df -h

# Check memory
free -h
```

### Health Checks

```bash
# Test Telegram bot
curl -s "https://api.telegram.org/bot<TOKEN>/getMe"

# Test DexScreener API
curl -s "https://api.dexscreener.com/latest/dex/search?q=SOL" | head -c 200
```

## Backup

### 1. Configuration Backup

```bash
# Create backup script
nano /var/www/dexintel/backup.sh
```

```bash
#!/bin/bash
BACKUP_DIR="/home/dexintel/backups"
DATE=$(date +%Y%m%d_%H%M%S)

mkdir -p $BACKUP_DIR

# Backup configuration
tar -czf $BACKUP_DIR/dexintel_config_$DATE.tar.gz \
  /var/www/dexintel/.env \
  /var/www/dexintel/strategy.yaml \
  /var/www/dexintel/ecosystem.config.js

# Keep only last 10 backups
ls -t $BACKUP_DIR/dexintel_config_*.tar.gz | tail -n +11 | xargs -r rm

echo "Backup completed: $BACKUP_DIR/dexintel_config_$DATE.tar.gz"
```

```bash
chmod +x /var/www/dexintel/backup.sh
```

### 2. Automated Backups

```bash
# Add to crontab
crontab -e

# Add line for daily backup at 2 AM
0 2 * * * /var/www/dexintel/backup.sh >> /var/log/dexintel-backup.log 2>&1
```

## Updates

### 1. Update Application

```bash
cd /var/www/dexintel

# Pull latest changes
git pull origin main

# Install new dependencies
npm install

# Rebuild
npm run build

# Restart with PM2
pm2 restart dexintel

# Verify
pm2 status
```

### 2. Update Node.js

```bash
# Update NodeSource repository
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Verify
node --version

# Restart application
pm2 restart dexintel
```

### 3. Update System Packages

```bash
sudo apt-get update
sudo apt-get upgrade -y

# Restart if kernel updated
sudo reboot
```

## Troubleshooting

### Application Won't Start

```bash
# Check logs
pm2 logs dexintel --lines 50

# Verify build
ls -la dist/

# Check environment
nano .env

# Test manually
cd /var/www/dexintel
node dist/index.js
```

### High Memory Usage

```bash
# Check memory usage
pm2 monit

# Restart application
pm2 restart dexintel

# Check for memory leaks
pm2 logs dexintel | grep -i "memory\|heap"

# Increase memory limit in ecosystem.config.js
max_memory_restart: '2G'
```

### Bot Not Responding

```bash
# Check bot token
curl -s "https://api.telegram.org/bot<TOKEN>/getMe"

# Verify chat ID
curl -s "https://api.telegram.org/bot<TOKEN>/getUpdates"

# Check logs
pm2 logs dexintel | grep -i "bot\|telegram"
```

### API Rate Limiting

```bash
# Check logs for rate limit errors
pm2 logs dexintel | grep -i "rate\|limit\|429"

# Increase rate limit delay
nano .env
# DEXSCREENER_RATE_LIMIT_MS=2000

# Restart
pm2 restart dexintel
```

### Database Connection Issues (if using DB)

```bash
# Check connection
ping your-db-host

# Verify credentials
nano .env

# Check firewall
sudo ufw status
```

### Safe Mode Issues

```bash
# Check why safe mode activated
pm2 logs dexintel | grep -i "safe.mode\|self.defense"

# Check system resources
free -h
df -h

# Manual recovery
pm2 restart dexintel
```

## Security Checklist

- [ ] Change default SSH port (optional)
- [ ] Disable root login via SSH
- [ ] Use SSH keys instead of passwords
- [ ] Enable UFW firewall
- [ ] Keep system updated
- [ ] Use strong bot tokens
- [ ] Restrict chat IDs
- [ ] Enable log rotation
- [ ] Setup automated backups
- [ ] Monitor system resources
- [ ] Review logs regularly

## Performance Tuning

### 1. Node.js Optimization

```bash
# In ecosystem.config.js
node_args: [
  '--max-old-space-size=2048',
  '--optimize-for-size',
  '--gc-interval=100'
]
```

### 2. PM2 Optimization

```bash
# Increase instances if CPU-bound
instances: 'max',
exec_mode: 'cluster',
```

### 3. System Optimization

```bash
# Increase file descriptor limits
ulimit -n 65535

# Add to /etc/security/limits.conf
dexintel soft nofile 65535
dexintel hard nofile 65535
```

## Quick Reference

### PM2 Commands

```bash
pm2 start ecosystem.config.js    # Start application
pm2 stop dexintel                # Stop application
pm2 restart dexintel             # Restart application
pm2 reload dexintel              # Zero-downtime reload
pm2 delete dexintel              # Remove from PM2
pm2 logs dexintel                # View logs
pm2 monit                        # Real-time monitoring
pm2 status                       # List processes
pm2 save                         # Save process list
pm2 startup                      # Generate startup script
```

### System Commands

```bash
sudo systemctl status pm2-dexintel   # Check PM2 service
sudo journalctl -u pm2-dexintel      # View PM2 logs
sudo ufw status                      # Check firewall
sudo netstat -tlnp                   # Check listening ports
```

---

**Last Updated**: 2024  
**Version**: 1.0.0
